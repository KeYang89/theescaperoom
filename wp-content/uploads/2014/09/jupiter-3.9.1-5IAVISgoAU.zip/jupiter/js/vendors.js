(function (a, b, c) {
        "use strict";
        var d = a.document,
                e = a.Modernizr,
                f = function (a) {
                        return a.charAt(0).toUpperCase() + a.slice(1)
                },
                g = "Moz Webkit O Ms".split(" "),
                h = function (a) {
                        var b = d.documentElement.style,
                                c;
                        if (typeof b[a] == "string") return a;
                        a = f(a);
                        for (var e = 0, h = g.length; e < h; e++) {
                                c = g[e] + a;
                                if (typeof b[c] == "string") return c
                        }
                },
                i = h("transform"),
                j = h("transitionProperty"),
                k = {
                        csstransforms: function () {
                                return !!i
                        },
                        csstransforms3d: function () {
                                var a = !! h("perspective");
                                if (a) {
                                        var c = " -o- -moz- -ms- -webkit- -khtml- ".split(" "),
                                                d = "@media (" + c.join("transform-3d),(") + "modernizr)",
                                                e = b("<style>" + d + "{#modernizr{height:3px}}" + "</style>").appendTo("head"),
                                                f = b('<div id="modernizr" />').appendTo("html");
                                        a = f.height() === 3, f.remove(), e.remove()
                                }
                                return a
                        },
                        csstransitions: function () {
                                return !!j
                        }
                },
                l;
        if (e) for (l in k) e.hasOwnProperty(l) || e.addTest(l, k[l]);
        else {
                e = a.Modernizr = {
                        _version: "1.6ish: miniModernizr for Isotope"
                };
                var m = " ",
                        n;
                for (l in k) n = k[l](), e[l] = n, m += " " + (n ? "" : "no-") + l;
                b("html").addClass(m)
        }
        if (e.csstransforms) {
                var o = e.csstransforms3d ? {
                        translate: function (a) {
                                return "translate3d(" + a[0] + "px, " + a[1] + "px, 0) "
                        },
                        scale: function (a) {
                                return "scale3d(" + a + ", " + a + ", 1) "
                        }
                } : {
                        translate: function (a) {
                                return "translate(" + a[0] + "px, " + a[1] + "px) "
                        },
                        scale: function (a) {
                                return "scale(" + a + ") "
                        }
                },
                        p = function (a, c, d) {
                                var e = b.data(a, "isoTransform") || {},
                                        f = {},
                                        g, h = {},
                                        j;
                                f[c] = d, b.extend(e, f);
                                for (g in e) j = e[g], h[g] = o[g](j);
                                var k = h.translate || "",
                                        l = h.scale || "",
                                        m = k + l;
                                b.data(a, "isoTransform", e), a.style[i] = m
                        };
                b.cssNumber.scale = !0, b.cssHooks.scale = {
                        set: function (a, b) {
                                p(a, "scale", b)
                        },
                        get: function (a, c) {
                                var d = b.data(a, "isoTransform");
                                return d && d.scale ? d.scale : 1
                        }
                }, b.fx.step.scale = function (a) {
                        b.cssHooks.scale.set(a.elem, a.now + a.unit)
                }, b.cssNumber.translate = !0, b.cssHooks.translate = {
                        set: function (a, b) {
                                p(a, "translate", b)
                        },
                        get: function (a, c) {
                                var d = b.data(a, "isoTransform");
                                return d && d.translate ? d.translate : [0, 0]
                        }
                }
        }
        var q, r;
        e.csstransitions && (q = {
                WebkitTransitionProperty: "webkitTransitionEnd",
                MozTransitionProperty: "transitionend",
                OTransitionProperty: "oTransitionEnd otransitionend",
                transitionProperty: "transitionend"
        }[j], r = h("transitionDuration"));
        var s = b.event,
                t = b.event.handle ? "handle" : "dispatch",
                u;
        s.special.smartresize = {
                setup: function () {
                        b(this).bind("resize", s.special.smartresize.handler)
                },
                teardown: function () {
                        b(this).unbind("resize", s.special.smartresize.handler)
                },
                handler: function (a, b) {
                        var c = this,
                                d = arguments;
                        a.type = "smartresize", u && clearTimeout(u), u = setTimeout(function () {
                                s[t].apply(c, d)
                        }, b === "execAsap" ? 0 : 100)
                }
        }, b.fn.smartresize = function (a) {
                return a ? this.bind("smartresize", a) : this.trigger("smartresize", ["execAsap"])
        }, b.Isotope = function (a, c, d) {
                this.element = b(c), this._create(a), this._init(d)
        };
        var v = ["width", "height"],
                w = b(a);
        b.Isotope.settings = {
                resizable: !0,
                layoutMode: "masonry",
                containerClass: "isotope",
                itemClass: "isotope-item",
                hiddenClass: "isotope-hidden",
                hiddenStyle: {
                        opacity: 0,
                        scale: .001
                },
                visibleStyle: {
                        opacity: 1,
                        scale: 1
                },
                containerStyle: {
                        position: "relative",
                        overflow: "hidden"
                },
                animationEngine: "best-available",
                animationOptions: {
                        queue: !1,
                        duration: 800
                },
                sortBy: "original-order",
                sortAscending: !0,
                resizesContainer: !0,
                transformsEnabled: !0,
                itemPositionDataEnabled: !1
        }, b.Isotope.prototype = {
                _create: function (a) {
                        this.options = b.extend({}, b.Isotope.settings, a), this.styleQueue = [], this.elemCount = 0;
                        var c = this.element[0].style;
                        this.originalStyle = {};
                        var d = v.slice(0);
                        for (var e in this.options.containerStyle) d.push(e);
                        for (var f = 0, g = d.length; f < g; f++) e = d[f], this.originalStyle[e] = c[e] || "";
                        this.element.css(this.options.containerStyle), this._updateAnimationEngine(), this._updateUsingTransforms();
                        var h = {
                                "original-order": function (a, b) {
                                        return b.elemCount++, b.elemCount
                                },
                                random: function () {
                                        return Math.random()
                                }
                        };
                        this.options.getSortData = b.extend(this.options.getSortData, h), this.reloadItems(), this.offset = {
                                left: parseInt(this.element.css("padding-left") || 0, 10),
                                top: parseInt(this.element.css("padding-top") || 0, 10)
                        };
                        var i = this;
                        setTimeout(function () {
                                i.element.addClass(i.options.containerClass)
                        }, 0), this.options.resizable && w.bind("smartresize.isotope", function () {
                                i.resize()
                        }), this.element.delegate("." + this.options.hiddenClass, "click", function () {
                                return !1
                        })
                },
                _getAtoms: function (a) {
                        var b = this.options.itemSelector,
                                c = b ? a.filter(b).add(a.find(b)) : a,
                                d = {
                                        position: "absolute"
                                };
                        return c = c.filter(function (a, b) {
                                return b.nodeType === 1
                        }), this.usingTransforms && (d.left = 0, d.top = 0), c.css(d).addClass(this.options.itemClass), this.updateSortData(c, !0), c
                },
                _init: function (a) {
                        this.$filteredAtoms = this._filter(this.$allAtoms), this._sort(), this.reLayout(a)
                },
                option: function (a) {
                        if (b.isPlainObject(a)) {
                                this.options = b.extend(!0, this.options, a);
                                var c;
                                for (var d in a) c = "_update" + f(d), this[c] && this[c]()
                        }
                },
                _updateAnimationEngine: function () {
                        var a = this.options.animationEngine.toLowerCase().replace(/[ _\-]/g, ""),
                                b;
                        switch (a) {
                        case "css":
                        case "none":
                                b = !1;
                                break;
                        case "jquery":
                                b = !0;
                                break;
                        default:
                                b = !e.csstransitions
                        }
                        this.isUsingJQueryAnimation = b, this._updateUsingTransforms()
                },
                _updateTransformsEnabled: function () {
                        this._updateUsingTransforms()
                },
                _updateUsingTransforms: function () {
                        var a = this.usingTransforms = this.options.transformsEnabled && e.csstransforms && e.csstransitions && !this.isUsingJQueryAnimation;
                        a || (delete this.options.hiddenStyle.scale, delete this.options.visibleStyle.scale), this.getPositionStyles = a ? this._translate : this._positionAbs
                },
                _filter: function (a) {
                        var b = this.options.filter === "" ? "*" : this.options.filter;
                        if (!b) return a;
                        var c = this.options.hiddenClass,
                                d = "." + c,
                                e = a.filter(d),
                                f = e;
                        if (b !== "*") {
                                f = e.filter(b);
                                var g = a.not(d).not(b).addClass(c);
                                this.styleQueue.push({
                                        $el: g,
                                        style: this.options.hiddenStyle
                                })
                        }
                        return this.styleQueue.push({
                                $el: f,
                                style: this.options.visibleStyle
                        }), f.removeClass(c), a.filter(b)
                },
                updateSortData: function (a, c) {
                        var d = this,
                                e = this.options.getSortData,
                                f, g;
                        a.each(function () {
                                f = b(this), g = {};
                                for (var a in e)!c && a === "original-order" ? g[a] = b.data(this, "isotope-sort-data")[a] : g[a] = e[a](f, d);
                                b.data(this, "isotope-sort-data", g)
                        })
                },
                _sort: function () {
                        var a = this.options.sortBy,
                                b = this._getSorter,
                                c = this.options.sortAscending ? 1 : -1,
                                d = function (d, e) {
                                        var f = b(d, a),
                                                g = b(e, a);
                                        return f === g && a !== "original-order" && (f = b(d, "original-order"), g = b(e, "original-order")), (f > g ? 1 : f < g ? -1 : 0) * c
                                };
                        this.$filteredAtoms.sort(d)
                },
                _getSorter: function (a, c) {
                        return b.data(a, "isotope-sort-data")[c]
                },
                _translate: function (a, b) {
                        return {
                                translate: [a, b]
                        }
                },
                _positionAbs: function (a, b) {
                        return {
                                left: a,
                                top: b
                        }
                },
                _pushPosition: function (a, b, c) {
                        b = Math.round(b + this.offset.left), c = Math.round(c + this.offset.top);
                        var d = this.getPositionStyles(b, c);
                        this.styleQueue.push({
                                $el: a,
                                style: d
                        }), this.options.itemPositionDataEnabled && a.data("isotope-item-position", {
                                x: b,
                                y: c
                        })
                },
                layout: function (a, b) {
                        var c = this.options.layoutMode;
                        this["_" + c + "Layout"](a);
                        if (this.options.resizesContainer) {
                                var d = this["_" + c + "GetContainerSize"]();
                                this.styleQueue.push({
                                        $el: this.element,
                                        style: d
                                })
                        }
                        this._processStyleQueue(a, b), this.isLaidOut = !0
                },
                _processStyleQueue: function (a, c) {
                        var d = this.isLaidOut ? this.isUsingJQueryAnimation ? "animate" : "css" : "css",
                                f = this.options.animationOptions,
                                g = this.options.onLayout,
                                h, i, j, k;
                        i = function (a, b) {
                                b.$el[d](b.style, f)
                        };
                        if (this._isInserting && this.isUsingJQueryAnimation) i = function (a, b) {
                                h = b.$el.hasClass("no-transition") ? "css" : d, b.$el[h](b.style, f)
                        };
                        else if (c || g || f.complete) {
                                var l = !1,
                                        m = [c, g, f.complete],
                                        n = this;
                                j = !0, k = function () {
                                        if (l) return;
                                        var b;
                                        for (var c = 0, d = m.length; c < d; c++) b = m[c], typeof b == "function" && b.call(n.element, a, n);
                                        l = !0
                                };
                                if (this.isUsingJQueryAnimation && d === "animate") f.complete = k, j = !1;
                                else if (e.csstransitions) {
                                        var o = 0,
                                                p = this.styleQueue[0],
                                                s = p && p.$el,
                                                t;
                                        while (!s || !s.length) {
                                                t = this.styleQueue[o++];
                                                if (!t) return;
                                                s = t.$el
                                        }
                                        var u = parseFloat(getComputedStyle(s[0])[r]);
                                        u > 0 && (i = function (a, b) {
                                                b.$el[d](b.style, f).one(q, k)
                                        }, j = !1)
                                }
                        }
                        b.each(this.styleQueue, i), j && k(), this.styleQueue = []
                },
                resize: function () {
                        this["_" + this.options.layoutMode + "ResizeChanged"]() && this.reLayout()
                },
                reLayout: function (a) {
                        this["_" + this.options.layoutMode + "Reset"](), this.layout(this.$filteredAtoms, a)
                },
                addItems: function (a, b) {
                        var c = this._getAtoms(a);
                        this.$allAtoms = this.$allAtoms.add(c), b && b(c)
                },
                insert: function (a, b) {
                        this.element.append(a);
                        var c = this;
                        this.addItems(a, function (a) {
                                var d = c._filter(a);
                                c._addHideAppended(d), c._sort(), c.reLayout(), c._revealAppended(d, b)
                        })
                },
                appended: function (a, b) {
                        var c = this;
                        this.addItems(a, function (a) {
                                c._addHideAppended(a), c.layout(a), c._revealAppended(a, b)
                        })
                },
                _addHideAppended: function (a) {
                        this.$filteredAtoms = this.$filteredAtoms.add(a), a.addClass("no-transition"), this._isInserting = !0, this.styleQueue.push({
                                $el: a,
                                style: this.options.hiddenStyle
                        })
                },
                _revealAppended: function (a, b) {
                        var c = this;
                        setTimeout(function () {
                                a.removeClass("no-transition"), c.styleQueue.push({
                                        $el: a,
                                        style: c.options.visibleStyle
                                }), c._isInserting = !1, c._processStyleQueue(a, b)
                        }, 10)
                },
                reloadItems: function () {
                        this.$allAtoms = this._getAtoms(this.element.children())
                },
                remove: function (a, b) {
                        this.$allAtoms = this.$allAtoms.not(a), this.$filteredAtoms = this.$filteredAtoms.not(a);
                        var c = this,
                                d = function () {
                                        a.remove(), b && b.call(c.element)
                                };
                        a.filter(":not(." + this.options.hiddenClass + ")").length ? (this.styleQueue.push({
                                $el: a,
                                style: this.options.hiddenStyle
                        }), this._sort(), this.reLayout(d)) : d()
                },
                shuffle: function (a) {
                        this.updateSortData(this.$allAtoms), this.options.sortBy = "random", this._sort(), this.reLayout(a)
                },
                destroy: function () {
                        var a = this.usingTransforms,
                                b = this.options;
                        this.$allAtoms.removeClass(b.hiddenClass + " " + b.itemClass).each(function () {
                                var b = this.style;
                                b.position = "", b.top = "", b.left = "", b.opacity = "", a && (b[i] = "")
                        });
                        var c = this.element[0].style;
                        for (var d in this.originalStyle) c[d] = this.originalStyle[d];
                        this.element.unbind(".isotope").undelegate("." + b.hiddenClass, "click").removeClass(b.containerClass).removeData("isotope"), w.unbind(".isotope")
                },
                _getSegments: function (a) {
                        var b = this.options.layoutMode,
                                c = a ? "rowHeight" : "columnWidth",
                                d = a ? "height" : "width",
                                e = a ? "rows" : "cols",
                                g = this.element[d](),
                                h, i = this.options[b] && this.options[b][c] || this.$filteredAtoms["outer" + f(d)](!0) || g;
                        h = Math.floor(g / i), h = Math.max(h, 1), this[b][e] = h, this[b][c] = i
                },
                _checkIfSegmentsChanged: function (a) {
                        var b = this.options.layoutMode,
                                c = a ? "rows" : "cols",
                                d = this[b][c];
                        return this._getSegments(a), this[b][c] !== d
                },
                _masonryReset: function () {
                        this.masonry = {}, this._getSegments();
                        var a = this.masonry.cols;
                        this.masonry.colYs = [];
                        while (a--) this.masonry.colYs.push(0)
                },
                _masonryLayout: function (a) {
                        var c = this,
                                d = c.masonry;
                        a.each(function () {
                                var a = b(this),
                                        e = Math.ceil(a.outerWidth(!0) / d.columnWidth);
                                e = Math.min(e, d.cols);
                                if (e === 1) c._masonryPlaceBrick(a, d.colYs);
                                else {
                                        var f = d.cols + 1 - e,
                                                g = [],
                                                h, i;
                                        for (i = 0; i < f; i++) h = d.colYs.slice(i, i + e), g[i] = Math.max.apply(Math, h);
                                        c._masonryPlaceBrick(a, g)
                                }
                        })
                },
                _masonryPlaceBrick: function (a, b) {
                        var c = Math.min.apply(Math, b),
                                d = 0;
                        for (var e = 0, f = b.length; e < f; e++)
                        if (b[e] === c) {
                                d = e;
                                break
                        }
                        var g = this.masonry.columnWidth * d,
                                h = c;
                        this._pushPosition(a, g, h);
                        var i = c + a.outerHeight(!0),
                                j = this.masonry.cols + 1 - f;
                        for (e = 0; e < j; e++) this.masonry.colYs[d + e] = i
                },
                _masonryGetContainerSize: function () {
                        var a = Math.max.apply(Math, this.masonry.colYs);
                        return {
                                height: a
                        }
                },
                _masonryResizeChanged: function () {
                        return this._checkIfSegmentsChanged()
                },
                _fitRowsReset: function () {
                        this.fitRows = {
                                x: 0,
                                y: 0,
                                height: 0
                        }
                },
                _fitRowsLayout: function (a) {
                        var c = this,
                                d = this.element.width(),
                                e = this.fitRows;
                        a.each(function () {
                                var a = b(this),
                                        f = a.outerWidth(!0),
                                        g = a.outerHeight(!0);
                                e.x !== 0 && f + e.x > d && (e.x = 0, e.y = e.height), c._pushPosition(a, e.x, e.y), e.height = Math.max(e.y + g, e.height), e.x += f
                        })
                },
                _fitRowsGetContainerSize: function () {
                        return {
                                height: this.fitRows.height
                        }
                },
                _fitRowsResizeChanged: function () {
                        return !0
                },
                _cellsByRowReset: function () {
                        this.cellsByRow = {
                                index: 0
                        }, this._getSegments(), this._getSegments(!0)
                },
                _cellsByRowLayout: function (a) {
                        var c = this,
                                d = this.cellsByRow;
                        a.each(function () {
                                var a = b(this),
                                        e = d.index % d.cols,
                                        f = Math.floor(d.index / d.cols),
                                        g = (e + .5) * d.columnWidth - a.outerWidth(!0) / 2,
                                        h = (f + .5) * d.rowHeight - a.outerHeight(!0) / 2;
                                c._pushPosition(a, g, h), d.index++
                        })
                },
                _cellsByRowGetContainerSize: function () {
                        return {
                                height: Math.ceil(this.$filteredAtoms.length / this.cellsByRow.cols) * this.cellsByRow.rowHeight + this.offset.top
                        }
                },
                _cellsByRowResizeChanged: function () {
                        return this._checkIfSegmentsChanged()
                },
                _straightDownReset: function () {
                        this.straightDown = {
                                y: 0
                        }
                },
                _straightDownLayout: function (a) {
                        var c = this;
                        a.each(function (a) {
                                var d = b(this);
                                c._pushPosition(d, 0, c.straightDown.y), c.straightDown.y += d.outerHeight(!0)
                        })
                },
                _straightDownGetContainerSize: function () {
                        return {
                                height: this.straightDown.y
                        }
                },
                _straightDownResizeChanged: function () {
                        return !0
                },
                _masonryHorizontalReset: function () {
                        this.masonryHorizontal = {}, this._getSegments(!0);
                        var a = this.masonryHorizontal.rows;
                        this.masonryHorizontal.rowXs = [];
                        while (a--) this.masonryHorizontal.rowXs.push(0)
                },
                _masonryHorizontalLayout: function (a) {
                        var c = this,
                                d = c.masonryHorizontal;
                        a.each(function () {
                                var a = b(this),
                                        e = Math.ceil(a.outerHeight(!0) / d.rowHeight);
                                e = Math.min(e, d.rows);
                                if (e === 1) c._masonryHorizontalPlaceBrick(a, d.rowXs);
                                else {
                                        var f = d.rows + 1 - e,
                                                g = [],
                                                h, i;
                                        for (i = 0; i < f; i++) h = d.rowXs.slice(i, i + e), g[i] = Math.max.apply(Math, h);
                                        c._masonryHorizontalPlaceBrick(a, g)
                                }
                        })
                },
                _masonryHorizontalPlaceBrick: function (a, b) {
                        var c = Math.min.apply(Math, b),
                                d = 0;
                        for (var e = 0, f = b.length; e < f; e++)
                        if (b[e] === c) {
                                d = e;
                                break
                        }
                        var g = c,
                                h = this.masonryHorizontal.rowHeight * d;
                        this._pushPosition(a, g, h);
                        var i = c + a.outerWidth(!0),
                                j = this.masonryHorizontal.rows + 1 - f;
                        for (e = 0; e < j; e++) this.masonryHorizontal.rowXs[d + e] = i
                },
                _masonryHorizontalGetContainerSize: function () {
                        var a = Math.max.apply(Math, this.masonryHorizontal.rowXs);
                        return {
                                width: a
                        }
                },
                _masonryHorizontalResizeChanged: function () {
                        return this._checkIfSegmentsChanged(!0)
                },
                _fitColumnsReset: function () {
                        this.fitColumns = {
                                x: 0,
                                y: 0,
                                width: 0
                        }
                },
                _fitColumnsLayout: function (a) {
                        var c = this,
                                d = this.element.height(),
                                e = this.fitColumns;
                        a.each(function () {
                                var a = b(this),
                                        f = a.outerWidth(!0),
                                        g = a.outerHeight(!0);
                                e.y !== 0 && g + e.y > d && (e.x = e.width, e.y = 0), c._pushPosition(a, e.x, e.y), e.width = Math.max(e.x + f, e.width), e.y += g
                        })
                },
                _fitColumnsGetContainerSize: function () {
                        return {
                                width: this.fitColumns.width
                        }
                },
                _fitColumnsResizeChanged: function () {
                        return !0
                },
                _cellsByColumnReset: function () {
                        this.cellsByColumn = {
                                index: 0
                        }, this._getSegments(), this._getSegments(!0)
                },
                _cellsByColumnLayout: function (a) {
                        var c = this,
                                d = this.cellsByColumn;
                        a.each(function () {
                                var a = b(this),
                                        e = Math.floor(d.index / d.rows),
                                        f = d.index % d.rows,
                                        g = (e + .5) * d.columnWidth - a.outerWidth(!0) / 2,
                                        h = (f + .5) * d.rowHeight - a.outerHeight(!0) / 2;
                                c._pushPosition(a, g, h), d.index++
                        })
                },
                _cellsByColumnGetContainerSize: function () {
                        return {
                                width: Math.ceil(this.$filteredAtoms.length / this.cellsByColumn.rows) * this.cellsByColumn.columnWidth
                        }
                },
                _cellsByColumnResizeChanged: function () {
                        return this._checkIfSegmentsChanged(!0)
                },
                _straightAcrossReset: function () {
                        this.straightAcross = {
                                x: 0
                        }
                },
                _straightAcrossLayout: function (a) {
                        var c = this;
                        a.each(function (a) {
                                var d = b(this);
                                c._pushPosition(d, c.straightAcross.x, 0), c.straightAcross.x += d.outerWidth(!0)
                        })
                },
                _straightAcrossGetContainerSize: function () {
                        return {
                                width: this.straightAcross.x
                        }
                },
                _straightAcrossResizeChanged: function () {
                        return !0
                }
        }, b.fn.imagesLoaded = function (a) {
                function h() {
                        a.call(c, d)
                }

                function i(a) {
                        var c = a.target;
                        c.src !== f && b.inArray(c, g) === -1 && (g.push(c), --e <= 0 && (setTimeout(h), d.unbind(".imagesLoaded", i)))
                }
                var c = this,
                        d = c.find("img").add(c.filter("img")),
                        e = d.length,
                        f = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///ywAAAAAAQABAAACAUwAOw==",
                        g = [];
                return e || h(), d.bind("load.imagesLoaded error.imagesLoaded", i).each(function () {
                        var a = this.src;
                        this.src = f, this.src = a
                }), c
        };
        var x = function (b) {
                        a.console && a.console.error(b)
                };
        b.fn.isotope = function (a, c) {
                if (typeof a == "string") {
                        var d = Array.prototype.slice.call(arguments, 1);
                        this.each(function () {
                                var c = b.data(this, "isotope");
                                if (!c) {
                                        x("cannot call methods on isotope prior to initialization; attempted to call method '" + a + "'");
                                        return
                                }
                                if (!b.isFunction(c[a]) || a.charAt(0) === "_") {
                                        x("no such method '" + a + "' for isotope instance");
                                        return
                                }
                                c[a].apply(c, d)
                        })
                } else this.each(function () {
                        var d = b.data(this, "isotope");
                        d ? (d.option(a), d._init(c)) : b.data(this, "isotope", new b.Isotope(a, this, c))
                });
                return this
        }
})(window, jQuery);



/*
 * debouncedresize: special jQuery event that happens once after a window resize
 *
 * latest version and complete README available on Github:
 * https://github.com/louisremi/jquery-smartresize
 *
 * Copyright 2012 @louis_remi
 * Licensed under the MIT license.
 *
 * This saved you an hour of work?
 * Send me music http://www.amazon.co.uk/wishlist/HNTU0468LQON
 */
(function ($) {

        var $event = $.event,
                $special, resizeTimeout;

        $special = $event.special.debouncedresize = {
                setup: function () {
                        $(this).on("resize", $special.handler);
                },
                teardown: function () {
                        $(this).off("resize", $special.handler);
                },
                handler: function (event, execAsap) {
                        // Save the context
                        var context = this,
                                args = arguments,
                                dispatch = function () {
                                        // set correct event type
                                        event.type = "debouncedresize";
                                        $event.dispatch.apply(context, args);
                                };

                        if (resizeTimeout) {
                                clearTimeout(resizeTimeout);
                        }

                        execAsap ? dispatch() : resizeTimeout = setTimeout(dispatch, $special.threshold);
                },
                threshold: 150
        };

})(jQuery);


/*
Plugin: jQuery Parallax
Version 1.1.3
Author: Ian Lunn
Twitter: @IanLunn
Author URL: http://www.ianlunn.co.uk/
Plugin URL: http://www.ianlunn.co.uk/plugins/jquery-parallax/

Dual licensed under the MIT and GPL licenses:
http://www.opensource.org/licenses/mit-license.php
http://www.gnu.org/licenses/gpl.html
*/

(function ($) {
        var $window = $(window);
        var windowHeight = $window.height();

        $window.resize(function () {
                windowHeight = $window.height();
        });

        $.fn.parallax = function (xpos, speedFactor, outerHeight) {
                var $this = $(this);
                var getHeight;
                var firstTop;
                var paddingTop = 0;

                //get the starting position of each element to have parallax applied to it      
                $this.each(function () {
                        firstTop = $this.offset().top;
                });

                if (outerHeight) {
                        getHeight = function (jqo) {
                                return jqo.outerHeight(true);
                        };
                } else {
                        getHeight = function (jqo) {
                                return jqo.height();
                        };
                }

                // setup defaults if arguments aren't specified
                if (arguments.length < 1 || xpos === null) xpos = "50%";
                if (arguments.length < 2 || speedFactor === null) speedFactor = 0.1;
                if (arguments.length < 3 || outerHeight === null) outerHeight = true;

                // function to be called whenever the window is scrolled or resized


                function update() {
                        var pos = $window.scrollTop();

                        $this.each(function () {
                                var $element = $(this);
                                var top = $element.offset().top;
                                var height = getHeight($element);

                                // Check if totally above or totally below viewport
                                if (top + height < pos || top > pos + windowHeight) {
                                        return;
                                }

                                $this.css('backgroundPosition', xpos + " " + Math.round((firstTop - pos) * speedFactor) + "px");
                        });
                }

                $window.bind('scroll', update).resize(update);
                update();
        };
})(jQuery);


/*
 * DC Mega Menu - jQuery mega menu
 * Copyright (c) 2011 Design Chemical
 *
 */
(function ($) {

        //define the defaults for the plugin and how to call it 
        $.fn.dcMegaMenu = function (options) {
                //set default options  
                var defaults = {
                        classParent: 'dc-mega',
                        classContainer: 'sub-container',
                        classSubParent: 'mega-hdr',
                        classSubLink: 'mega-hdr',
                        classWidget: 'dc-extra',
                        rowItems: 6,
                        speed: 'fast',
                        effect: 'fade',
                        event: 'hover',
                        fullWidth: false,
                        onLoad: function () {},
                        beforeOpen: function () {},
                        beforeClose: function () {}
                };


                var options = $.extend(defaults, options);
                var $dcMegaMenuObj = this;

                //act upon the element that is passed into the design    
                return $dcMegaMenuObj.each(function (options) {

                        var clSubParent = defaults.classSubParent;
                        var clSubLink = defaults.classSubLink;
                        var clParent = defaults.classParent;
                        var clContainer = defaults.classContainer;
                        var clWidget = defaults.classWidget;
                        //console.log(jQuery(this).parents('.mk-header-nav-container').width());
                        megaSetup();

                        function megaOver() {
                                var subNav = $('.sub', this);
                                $(this).addClass('mega-hover');
                                if (defaults.effect === 'fade') {
                                        $(subNav).fadeIn(defaults.speed);
                                }
                                if (defaults.effect === 'slide') {
                                        $(subNav).show(defaults.speed);
                                }
                                // beforeOpen callback;
                                defaults.beforeOpen.call(this);
                        }

                        function megaAction(obj) {
                                var subNav = $('.sub', obj);
                                $(obj).addClass('mega-hover');
                                if (defaults.effect === 'fade') {
                                        $(subNav).fadeIn(defaults.speed);
                                }
                                if (defaults.effect === 'slide') {
                                        $(subNav).show(defaults.speed);
                                }
                                // beforeOpen callback;
                                defaults.beforeOpen.call(this);
                        }

                        function megaOut() {
                                var subNav = $('.sub', this);
                                $(this).removeClass('mega-hover');
                                $(subNav).hide();
                                // beforeClose callback;
                                defaults.beforeClose.call(this);
                        }

                        function megaActionClose(obj) {
                                var subNav = $('.sub', obj);
                                $(obj).removeClass('mega-hover');
                                $(subNav).hide();
                                // beforeClose callback;
                                defaults.beforeClose.call(this);
                        }

                        function megaReset() {
                                $('li', $dcMegaMenuObj).removeClass('mega-hover');
                                $('.sub', $dcMegaMenuObj).hide();
                        }

                        function megaSetup() {
                                //$arrow = '<span class="dc-mega-icon"></span>';
                                var clParentLi = clParent + '-li';
                                var menuWidth = $dcMegaMenuObj.outerWidth();
                                $('> li', $dcMegaMenuObj).each(function () {
                                        //Set Width of sub
                                        var $mainSub = $('> ul', this);
                                        var $primaryLink = $('> a', this);
                                        if ($mainSub.length) {
                                                //$primaryLink.addClass(clParent).append($arrow);
                                                $mainSub.addClass('sub').wrap('<div class="' + clContainer + '" />');

                                                var pos = $(this).position();
                                                pl = pos.left;

                                                // checks whether its a mega menu. editd by MK    
                                                if ($('ul.mk_mega_menu', $mainSub).length) {
                                                        $(this).addClass(clParentLi);
                                                        $('.' + clContainer, this).addClass('mega');
                                                        $('> li', $mainSub).each(function () {
                                                                if (!$(this).hasClass(clWidget)) {
                                                                        $(this).addClass('mega-unit');
                                                                        if ($('> ul', this).length) {
                                                                                $(this).addClass(clSubParent);
                                                                                $('> a', this).addClass(clSubParent + '-a');
                                                                        } else {
                                                                                $(this).addClass(clSubLink);
                                                                                $('> a', this).addClass(clSubLink + '-a');
                                                                        }
                                                                }
                                                        });

                                                        // Create Rows
                                                        var hdrs = $('.mega-unit', this);
                                                        rowSize = parseInt(defaults.rowItems);
                                                        for (var i = 0; i < hdrs.length; i += rowSize) {
                                                                hdrs.slice(i, i + rowSize).wrapAll('<div class="row" />');
                                                        }

                                                        // Get Sub Dimensions & Set Row Height
                                                        $mainSub.show();

                                                        // Get Position of Parent Item
                                                        var pw = $(this).width();
                                                        var pr = pl + pw;

                                                        // Check available right margin
                                                        var mr = menuWidth - pr;

                                                        // // Calc Width of Sub Menu
                                                        var subw = $mainSub.outerWidth();
                                                        var totw = $mainSub.parent('.' + clContainer).outerWidth();
                                                        var cpad = totw - subw;

                                                        if (defaults.fullWidth === true) {
                                                                var fw = menuWidth - cpad;
                                                                $mainSub.parent('.' + clContainer).css({
                                                                        width: mk_grid_width
                                                                });
                                                                $dcMegaMenuObj.addClass('full-width');
                                                        }
                                                        var iw = $('.mega-unit', $mainSub).outerWidth(true);
                                                        var rowItems = $('.row:eq(0) .mega-unit', $mainSub).length;
                                                        var inneriw = iw * rowItems;
                                                        var totiw = inneriw + cpad;

                                                        // Set mega header height
                                                        $('.row', this).each(function () {
                                                                $('.mega-unit:last', this).addClass('last');
                                                                var maxValue = undefined;
                                                                $('.mega-unit > a', this).each(function () {
                                                                        var val = parseInt($(this).height());
                                                                        if (maxValue === undefined || maxValue < val) {
                                                                                maxValue = val;
                                                                        }
                                                                });
                                                                $('.mega-unit > a', this).css('height', maxValue + 'px');
                                                                $(this).css('width', inneriw + 'px');
                                                        });

                                                        // Calc Required Left Margin incl additional required for right align
                                                        if (defaults.fullWidth === true) {
                                                                params = {
                                                                        left: 0
                                                                };
                                                        } else {

                                                                var ml = mr < ml ? ml + ml - mr : (totiw - pw) / 2;
                                                                var subLeft = pl - ml;

                                                                // If Left Position Is Negative Set To Left Margin
                                                                var params = {
                                                                        left: pl + 'px',
                                                                        marginLeft: -ml + 'px'
                                                                };

                                                                if (subLeft < 0) {
                                                                        params = {
                                                                                left: 0
                                                                        };
                                                                } else if (mr < ml) {
                                                                        params = {
                                                                                right: 0
                                                                        };
                                                                }
                                                        }
                                                        $('.' + clContainer, this).css(params);

                                                        // Calculate Row Height
                                                        $('.row', $mainSub).each(function () {
                                                                var rh = $(this).height();
                                                                $('.mega-unit', this).css({
                                                                        height: rh + 'px'
                                                                });
                                                                $(this).parent('.row').css({
                                                                        height: rh + 'px'
                                                                });
                                                        });
                                                        $mainSub.hide();

                                                } else {
                                                        $('.' + clContainer, this).addClass('non-mega').css('left', pl + 'px');
                                                }
                                                // MK edition
                                                if (!$('ul', $mainSub).hasClass('mk_mega_menu')) {
                                                        $('.' + clContainer, this).addClass('mk-nested-sub');
                                                        //console.log($('.mk-nested-sub > ul',this).width());
                                                        $mk_nested_ul = $('.mk-nested-sub > ul', this);
                                                        $mk_nested_width = $mk_nested_ul.width();

                                                        $mk_nested_ul.find('ul').css('left', $mk_nested_width + 'px');
                                                        $mk_nested_ul.find('li').each(function () {
                                                                var $nested_sub = $('> ul', this);
                                                                if ($nested_sub.length) {
                                                                        jQuery(this).append('<i class="mk-mega-icon mk-icon-angle-right"></i>');
                                                                }
                                                                jQuery(this).hover(function () {
                                                                        jQuery(this).find('> ul').stop(true, true).delay(100).fadeIn(100);
                                                                }, function () {
                                                                        jQuery(this).find('> ul').stop(true, true).delay(100).fadeOut(100);
                                                                });
                                                        });

                                                }
                                        }
                                });
                                // Set position of mega dropdown to bottom of main menu
                                var menuHeight = $('> li > a', $dcMegaMenuObj).outerHeight(true);
                                $('.' + clContainer, $dcMegaMenuObj).css({
                                        top: menuHeight + 'px'
                                }).css('z-index', '1000');

                                if (defaults.event == 'hover') {
                                        // HoverIntent Configuration
                                        var config = {
                                                sensitivity: 1,
                                                interval: 30,
                                                over: megaOver,
                                                timeout: 50,
                                                out: megaOut
                                        };
                                        $('li', $dcMegaMenuObj).hoverIntent(config);
                                }

                                if (defaults.event == 'click') {

                                        $('body').mouseup(function (e) {
                                                if (!$(e.target).parents('.mega-hover').length) {
                                                        megaReset();
                                                }
                                        });

                                        $('> li > a.' + clParent, $dcMegaMenuObj).click(function (e) {
                                                var $parentLi = $(this).parent();
                                                if ($parentLi.hasClass('mega-hover')) {
                                                        megaActionClose($parentLi);
                                                } else {
                                                        megaAction($parentLi);
                                                }
                                                e.preventDefault();
                                        });
                                }

                                // onLoad callback;
                                defaults.onLoad.call(this);
                        }
                });
        };
})(jQuery);




















/**
 * downCount: Simple Countdown clock with offset
 * Author: Sonny T. <hi@sonnyt.com>, sonnyt.com
 */

(function ($) {

    $.fn.downCount = function (options, callback) {
        var settings = $.extend({
                date: null,
                offset: null
            }, options);

        // Throw error if date is not set
        if (!settings.date) {
            $.error('Date is not defined.');
        }

        // Throw error if date is set incorectly
        if (!Date.parse(settings.date)) {
            $.error('Incorrect date format, it should look like this, 12/24/2012 12:00:00.');
        }

        // Save container
        var container = this;

        /**
         * Change client's local date to match offset timezone
         * @return {Object} Fixed Date object.
         */
        var currentDate = function () {
            // get client's current date
            var date = new Date();

            // turn date to utc
            var utc = date.getTime() + (date.getTimezoneOffset() * 60000);

            // set new Date object
            var new_date = new Date(utc + (3600000*settings.offset))

            return new_date;
        };

        /**
         * Main downCount function that calculates everything
         */
        function countdown () {
            var target_date = new Date(settings.date), // set target date
                current_date = currentDate(); // get fixed current date

            // difference of dates
            var difference = target_date - current_date;

            // if difference is negative than it's pass the target date
            if (difference < 0) {
                // stop timer
                clearInterval(interval);

                if (callback && typeof callback === 'function') callback();

                return;
            }

            // basic math variables
            var _second = 1000,
                _minute = _second * 60,
                _hour = _minute * 60,
                _day = _hour * 24;

            // calculate dates
            var days = Math.floor(difference / _day),
                hours = Math.floor((difference % _day) / _hour),
                minutes = Math.floor((difference % _hour) / _minute),
                seconds = Math.floor((difference % _minute) / _second);

                // fix dates so that it will show two digets
                days = (String(days).length >= 2) ? days : '0' + days;
                hours = (String(hours).length >= 2) ? hours : '0' + hours;
                minutes = (String(minutes).length >= 2) ? minutes : '0' + minutes;
                seconds = (String(seconds).length >= 2) ? seconds : '0' + seconds;

            // based on the date change the refrence wording
            var ref_days = (days === 1) ? 'day' : 'days',
                ref_hours = (hours === 1) ? 'hour' : 'hours',
                ref_minutes = (minutes === 1) ? 'minute' : 'minutes',
                ref_seconds = (seconds === 1) ? 'second' : 'seconds';

            // set to DOM
            container.find('.days').text(days);
            container.find('.hours').text(hours);
            container.find('.minutes').text(minutes);
            container.find('.seconds').text(seconds);

            container.find('.days_ref').text(ref_days);
            container.find('.hours_ref').text(ref_hours);
            container.find('.minutes_ref').text(ref_minutes);
            container.find('.seconds_ref').text(ref_seconds);
        };
        
        // start
        var interval = setInterval(countdown, 1000);
    };

})(jQuery);

















/**
 * Ajax Portfolio
 */
(function ($, window, document, undefined) {
        "use strict";
        var pluginName = "ajaxPortfolio",
                defaults = {
                        propertyName: "value"
                };

        function Plugin(element, options) {
                this.element = $(element);
                this.settings = $.extend({}, defaults, options);
                this.init();

        }
        Plugin.prototype = {
                init: function () {
                        var obj = this;
                        this.grid = this.element.find('.mk-portfolio-container'), 
                        this.items = this.grid.children();

                        if (this.items.length < 1) return false; //If no items was found then exit
                        this.ajaxDiv = this.element.find('div.ajax-container'), 
                        this.filter = this.element.find('#mk-filter-portfolio'), 
                        this.loader = this.element.find('.portfolio-loader'), 
                        this.triggers = this.items.find('.project-load'), 
                        this.closeBtn = this.ajaxDiv.find('.close-ajax'), 
                        this.nextBtn = this.ajaxDiv.find('.next-ajax'), 
                        this.prevBtn = this.ajaxDiv.find('.prev-ajax'), 
                        this.api = {}, 
                        this.id = null, 
                        this.win = $(window), 
                        this.current = 0, 
                        this.breakpointT = 989, 
                        this.breakpointP = 767, 
                        this.columns = this.grid.data('columns'), 
                        this.real_col = this.columns;
                        this.loader.fadeIn();
                        if (this.items.length == 1) {
                                this.nextBtn.remove();
                                this.prevBtn.remove();
                        }
                        this.grid.waitForImages(function () {
                                obj.loader.fadeOut();
                                obj.bind_handler();
                        });

                },

                bind_handler: function () {
                        var obj = this; // Temp instance of this object
                        // Bind the filters with isotope
                        obj.filter.find('a').click(function () {
                                obj.triggers.removeClass('active');
                                obj.grid.removeClass('grid-open');
                                obj.close_project();
                                obj.filter.find('a').removeClass('active_sort');
                                $(this).addClass('active_sort');
                                var selector = $(this).attr('data-filter');
                                obj.grid.isotope({
                                        filter: selector
                                });
                                return false;
                        });

                        obj.triggers.on('click', function () {

                                var clicked = $(this),
                                        clickedParent = clicked.parents('.mk-portfolio-item');

                                obj.current = clickedParent.index();

                                if (clicked.hasClass('active')) return false;

                                obj.close_project();

                                obj.triggers.removeClass('active');
                                clicked.addClass('active');
                                obj.grid.addClass('grid-open');
                                obj.loader.fadeIn();

                                obj.id = clicked.data('post-id');

                                obj.load_project();

                                return false;

                        });

                        obj.nextBtn.on('click', function () {
                                if (obj.current == obj.triggers.length - 1) {
                                        obj.triggers.eq(0).trigger('click');
                                        return false;
                                } else {
                                        obj.triggers.eq(obj.current + 1).trigger('click');
                                        return false;
                                }

                        });

                        obj.prevBtn.on('click', function () {
                                if (obj.current == 0) {
                                        obj.triggers.eq(obj.triggers.length - 1).trigger('click');
                                        return false;
                                } else {
                                        obj.triggers.eq(obj.current - 1).trigger('click');
                                        return false;
                                }

                        });

                        // Bind close button
                        obj.closeBtn.on('click', function () {
                                obj.close_project();
                                obj.triggers.removeClass('active');
                                obj.grid.removeClass('grid-open');
                                return false;
                        });


                },
                // Function to close the ajax container div
                close_project: function () {
                        var obj = this,
                                // Temp instance of this object
                                project = obj.ajaxDiv.find('.ajax_project'),
                                newH = project.actual('outerHeight');

                        obj.ajaxDiv.find('iframe').attr('src', '');


                        if (obj.ajaxDiv.height() > 0) {
                                obj.ajaxDiv.css('height', newH + 'px').transition({
                                        height: 0,
                                        opacity: 0
                                }, 600);
                        } else {
                                obj.ajaxDiv.transition({
                                        height: 0,
                                        opacity: 0
                                }, 600);
                        }
                },
                load_project: function () {
                        var obj = this;
                        $.post(ajaxurl, {
                                action: 'mk_ajax_portfolio',
                                id: obj.id
                        }, function (response) {
                                obj.ajaxDiv.find('.ajax_project').remove();
                                obj.ajaxDiv.append(response);
                                obj.project_factory();
                                mk_ajax_lightbox_init();
                                mk_click_events();
                                mk_theme_toggle_box();
                                setTimeout(function () {
                                        mk_flexslider_init();
                                }, 1000);;

                        });
                },
                project_factory: function () {
                        var obj = this,
                                project = this.ajaxDiv.find('.ajax_project');



                        project.waitForImages(function () {
                                $('html:not(:animated),body:not(:animated)').animate({
                                        scrollTop: obj.ajaxDiv.offset().top - 160
                                }, 700);
                                mk_flexslider_init();
                                obj.loader.fadeOut(function () {
                                        var newH = project.actual('outerHeight');
                                        obj.ajaxDiv.transition({
                                                opacity: 1,
                                                height: newH
                                        }, 400, function () {
                                                obj.ajaxDiv.css({
                                                        height: 'auto'
                                                });
                                        });
                                });

                        });

                },

        };
        $.fn[pluginName] = function (options) {
                return this.each(function () {
                        //if (!$.data(this, "plugin_" + pluginName)) {
                                $.data(this, "plugin_" + pluginName);
                                        
                                        new Plugin(this, options)
                        //}
                });
        };
})(jQuery, window, document);

























/**
 * hoverIntent r5 // 2007.03.27 // jQuery 1.1.2+
 * <http://cherne.net/brian/resources/jquery.hoverIntent.html>
 *
 * @param  f  onMouseOver function || An object with configuration options
 * @param  g  onMouseOut function  || Nothing (use configuration options object)
 * @author    Brian Cherne <brian@cherne.net>
 */
(function ($) {
        $.fn.hoverIntent = function (f, g) {
                var cfg = {
                        sensitivity: 7,
                        interval: 100,
                        timeout: 0
                };
                cfg = $.extend(cfg, g ? {
                        over: f,
                        out: g
                } : f);
                var cX, cY, pX, pY;
                var track = function (ev) {
                                cX = ev.pageX;
                                cY = ev.pageY;
                        };
                var compare = function (ev, ob) {
                                ob.hoverIntent_t = clearTimeout(ob.hoverIntent_t);
                                if ((Math.abs(pX - cX) + Math.abs(pY - cY)) < cfg.sensitivity) {
                                        $(ob).unbind("mousemove", track);
                                        ob.hoverIntent_s = 1;
                                        return cfg.over.apply(ob, [ev]);
                                } else {
                                        pX = cX;
                                        pY = cY;
                                        ob.hoverIntent_t = setTimeout(function () {
                                                compare(ev, ob);
                                        }, cfg.interval);
                                }
                        };
                var delay = function (ev, ob) {
                                ob.hoverIntent_t = clearTimeout(ob.hoverIntent_t);
                                ob.hoverIntent_s = 0;
                                return cfg.out.apply(ob, [ev]);
                        };
                var handleHover = function (e) {
                                var p = (e.type == "mouseover" ? e.fromElement : e.toElement) || e.relatedTarget;
                                while (p && p != this) {
                                        try {
                                                p = p.parentNode;
                                        } catch (e) {
                                                p = this;
                                        }
                                }
                                if (p == this) {
                                        return false;
                                }
                                var ev = jQuery.extend({}, e);
                                var ob = this;
                                if (ob.hoverIntent_t) {
                                        ob.hoverIntent_t = clearTimeout(ob.hoverIntent_t);
                                }
                                if (e.type == "mouseover") {
                                        pX = ev.pageX;
                                        pY = ev.pageY;
                                        $(ob).bind("mousemove", track);
                                        if (ob.hoverIntent_s != 1) {
                                                ob.hoverIntent_t = setTimeout(function () {
                                                        compare(ev, ob);
                                                }, cfg.interval);
                                        }
                                } else {
                                        $(ob).unbind("mousemove", track);
                                        if (ob.hoverIntent_s == 1) {
                                                ob.hoverIntent_t = setTimeout(function () {
                                                        delay(ev, ob);
                                                }, cfg.timeout);
                                        }
                                }
                        };
                return this.mouseover(handleHover).mouseout(handleHover);
        };
})(jQuery);




























/* Copyright 2012, Ben Lin (http://dreamerslab.com/)
 * Licensed under the MIT License (LICENSE.txt).
 *
 * Version: 1.0.15
 *
 * Requires: jQuery >= 1.2.3
 */
(function (a) {
        a.fn.addBack = a.fn.addBack || a.fn.andSelf;
        a.fn.extend({
                actual: function (b, l) {
                        if (!this[b]) {
                                throw '$.actual => The jQuery method "' + b + '" you called does not exist';
                        }
                        var f = {
                                absolute: false,
                                clone: false,
                                includeMargin: false
                        };
                        var i = a.extend(f, l);
                        var e = this.eq(0);
                        var h, j;
                        if (i.clone === true) {
                                h = function () {
                                        var m = "position: absolute !important; top: -1000 !important; ";
                                        e = e.clone().attr("style", m).appendTo("body")
                                };
                                j = function () {
                                        e.remove()
                                }
                        } else {
                                var g = [];
                                var d = "";
                                var c;
                                h = function () {
                                        c = e.parents().addBack().filter(":hidden");
                                        d += "visibility: hidden !important; display: block !important; ";
                                        if (i.absolute === true) {
                                                d += "position: absolute !important; "
                                        }
                                        c.each(function () {
                                                var m = a(this);
                                                g.push(m.attr("style"));
                                                m.attr("style", d)
                                        })
                                };
                                j = function () {
                                        c.each(function (m) {
                                                var o = a(this);
                                                var n = g[m];
                                                if (n === undefined) {
                                                        o.removeAttr("style")
                                                } else {
                                                        o.attr("style", n)
                                                }
                                        })
                                }
                        }
                        h();
                        var k = /(outer)/.test(b) ? e[b](i.includeMargin) : e[b]();
                        j();
                        return k
                }
        })
})(jQuery);



























/*
 
 jQuery Tools Validator 1.2.5 - HTML5 is here. Now use it.

 NO COPYRIGHTS OR LICENSES. DO WHAT YOU LIKE.

 http://flowplayer.org/tools/form/validator/

 Since: Mar 2010
 Date:    Wed Sep 22 06:02:10 2010 +0000 
*/
(function (e) {
        function t(a, b, c) {
                var k = a.offset().top,
                        f = a.offset().left,
                        l = c.position.split(/,?\s+/),
                        p = l[0];
                l = l[1];
                k -= b.outerHeight() - c.offset[0];
                f += a.outerWidth() + c.offset[1];
                if (/iPad/i.test(navigator.userAgent)) k -= e(window).scrollTop();
                c = b.outerHeight() + a.outerHeight();
                if (p == "center") k += c / 2;
                if (p == "bottom") k += c;
                a = a.outerWidth();
                if (l == "center") f -= (a + b.outerWidth()) / 2;
                if (l == "left") f -= a;
                return {
                        top: k,
                        left: f
                }
        }
        function y(a) {
                function b() {
                        return this.getAttribute("type") == a
                }
                b.key = "[type=" + a + "]";
                return b
        }
        function u(a, b, c) {
                function k(g, d, i) {
                        if (!(!c.grouped && g.length)) {
                                var j;
                                if (i === false || e.isArray(i)) {
                                        j = h.messages[d.key || d] || h.messages["*"];
                                        j = j[c.lang] || h.messages["*"].en;
                                        (d = j.match(/\$\d/g)) && e.isArray(i) && e.each(d, function (m) {
                                                j = j.replace(this, i[m])
                                        })
                                } else j = i[c.lang] || i;
                                g.push(j)
                        }
                }
                var f = this,
                        l = b.add(f);
                a = a.not(":button, :image, :reset, :submit");
                e.extend(f, {
                        getConf: function () {
                                return c
                        },
                        getForm: function () {
                                return b
                        },
                        getInputs: function () {
                                return a
                        },
                        reflow: function () {
                                a.each(function () {
                                        var g = e(this),
                                                d = g.data("msg.el");
                                        if (d) {
                                                g = t(g, d, c);
                                                d.css({
                                                        top: g.top,
                                                        left: g.left
                                                })
                                        }
                                });
                                return f
                        },
                        invalidate: function (g, d) {
                                if (!d) {
                                        var i = [];
                                        e.each(g, function (j, m) {
                                                j = a.filter("[name='" + j + "']");
                                                if (j.length) {
                                                        j.trigger("OI", [m]);
                                                        i.push({
                                                                input: j,
                                                                messages: [m]
                                                        })
                                                }
                                        });
                                        g = i;
                                        d = e.Event()
                                }
                                d.type = "onFail";
                                l.trigger(d, [g]);
                                d.isDefaultPrevented() || q[c.effect][0].call(f, g, d);
                                return f
                        },
                        reset: function (g) {
                                g = g || a;
                                g.removeClass(c.errorClass).each(function () {
                                        var d = e(this).data("msg.el");
                                        if (d) {
                                                d.remove();
                                                e(this).data("msg.el", null)
                                        }
                                }).unbind(c.errorInputEvent || "");
                                return f
                        },
                        destroy: function () {
                                b.unbind(c.formEvent + ".V").unbind("reset.V");
                                a.unbind(c.inputEvent + ".V").unbind("change.V");
                                return f.reset()
                        },
                        checkValidity: function (g, d) {
                                g = g || a;
                                g = g.not(":disabled");
                                if (!g.length) return true;
                                d = d || e.Event();
                                d.type = "onBeforeValidate";
                                l.trigger(d, [g]);
                                if (d.isDefaultPrevented()) return d.result;
                                var i = [];
                                g.not(":radio:not(:checked)").each(function () {
                                        var m = [],
                                                n = e(this).data("messages", m),
                                                v = r && n.is(":date") ? "onHide.v" : c.errorInputEvent + ".v";
                                        n.unbind(v);
                                        e.each(w, function () {
                                                var o = this,
                                                        s = o[0];
                                                if (n.filter(s).length) {
                                                        o = o[1].call(f, n, n.val());
                                                        if (o !== true) {
                                                                d.type = "onBeforeFail";
                                                                l.trigger(d, [n, s]);
                                                                if (d.isDefaultPrevented()) return false;
                                                                var x = n.attr(c.messageAttr);
                                                                if (x) {
                                                                        m = [x];
                                                                        return false
                                                                } else k(m, s, o)
                                                        }
                                                }
                                        });
                                        if (m.length) {
                                                i.push({
                                                        input: n,
                                                        messages: m
                                                });
                                                n.trigger("OI", [m]);
                                                c.errorInputEvent && n.bind(v, function (o) {
                                                        f.checkValidity(n, o)
                                                })
                                        }
                                        if (c.singleError && i.length) return false
                                });
                                var j = q[c.effect];
                                if (!j) throw 'Validator: cannot find effect "' + c.effect + '"';
                                if (i.length) {
                                        f.invalidate(i, d);
                                        return false
                                } else {
                                        j[1].call(f, g, d);
                                        d.type = "onSuccess";
                                        l.trigger(d, [g]);
                                        g.unbind(c.errorInputEvent + ".v")
                                }
                                return true
                        }
                });
                e.each("onBeforeValidate,onBeforeFail,onFail,onSuccess".split(","), function (g, d) {
                        e.isFunction(c[d]) && e(f).bind(d, c[d]);
                        f[d] = function (i) {
                                i && e(f).bind(d, i);
                                return f
                        }
                });
                c.formEvent && b.bind(c.formEvent + ".V", function (g) {
                        if (!f.checkValidity(null, g)) return g.preventDefault()
                });
                b.bind("reset.V", function () {
                        f.reset()
                });
                a[0] && a[0].validity && a.each(function () {
                        this.oninvalid = function () {
                                return false
                        }
                });
                if (b[0]) b[0].checkValidity = f.checkValidity;
                c.inputEvent && a.bind(c.inputEvent + ".V", function (g) {
                        f.checkValidity(e(this), g)
                });
                a.filter(":checkbox, select").filter("[required]").bind("change.V", function (g) {
                        var d = e(this);
                        if (this.checked || d.is("select") && e(this).val()) q[c.effect][1].call(f, d, g)
                });
                var p = a.filter(":radio").change(function (g) {
                        f.checkValidity(p, g)
                });
                e(window).resize(function () {
                        f.reflow()
                })
        }
        e.tools = e.tools || {
                version: "1.2.5"
        };
        var z = /\[type=([a-z]+)\]/,
                A = /^-?[0-9]*(\.[0-9]+)?$/,
                r = e.tools.dateinput,
                B = /^([a-z0-9_\.\-\+]+)@([\da-z\.\-]+)\.([a-z\.]{2,6})$/i,
                C = /^(https?:\/\/)?[\da-z\.\-]+\.[a-z\.]{2,6}[#&+_\?\/\w \.\-=]*$/i,
                h;
        h = e.tools.validator = {
                conf: {
                        grouped: false,
                        effect: "default",
                        errorClass: "invalid",
                        inputEvent: null,
                        errorInputEvent: "keyup",
                        formEvent: "submit",
                        lang: "en",
                        message: "<div/>",
                        messageAttr: "data-message",
                        messageClass: "error",
                        offset: [0, 0],
                        position: "center right",
                        singleError: false,
                        speed: "normal"
                },
                messages: {
                        "*": {
                                en: "Please correct this value"
                        }
                },
                localize: function (a, b) {
                        e.each(b, function (c, k) {
                                h.messages[c] = h.messages[c] || {};
                                h.messages[c][a] = k
                        })
                },
                localizeFn: function (a, b) {
                        h.messages[a] = h.messages[a] || {};
                        e.extend(h.messages[a], b)
                },
                fn: function (a, b, c) {
                        if (e.isFunction(b)) c = b;
                        else {
                                if (typeof b == "string") b = {
                                        en: b
                                };
                                this.messages[a.key || a] = b
                        }
                        if (b = z.exec(a)) a = y(b[1]);
                        w.push([a, c])
                },
                addEffect: function (a, b, c) {
                        q[a] = [b, c]
                }
        };
        var w = [],
                q = {
                        "default": [function (a) {
                                var b = this.getConf();
                                e.each(a, function (c, k) {
                                        c = k.input;
                                        c.addClass(b.errorClass);
                                        var f = c.data("msg.el");
                                        if (!f) {
                                                f = e(b.message).addClass(b.messageClass).appendTo(document.body);
                                                c.data("msg.el", f)
                                        }
                                        f.css({
                                                visibility: "hidden"
                                        }).find("p").remove();
                                        e.each(k.messages, function (l, p) {
                                                e("<p/>").html(p).appendTo(f)
                                        });
                                        f.outerWidth() == f.parent().width() && f.add(f.find("p")).css({
                                                display: "inline"
                                        });
                                        k = t(c, f, b);
                                        f.css({
                                                visibility: "visible",
                                                position: "absolute",
                                                top: k.top,
                                                left: k.left
                                        }).fadeIn(b.speed)
                                })
                        }, function (a) {
                                var b = this.getConf();
                                a.removeClass(b.errorClass).each(function () {
                                        var c = e(this).data("msg.el");
                                        c && c.css({
                                                visibility: "hidden"
                                        })
                                })
                        }]
                };
        e.each("email,url,number".split(","), function (a, b) {
                e.expr[":"][b] = function (c) {
                        return c.getAttribute("type") === b
                }
        });
        e.fn.oninvalid = function (a) {
                return this[a ? "bind" : "trigger"]("OI", a)
        };
        h.fn(":email", "Please enter a valid email address", function (a, b) {
                return !b || B.test(b)
        });
        h.fn(":url", "Please enter a valid URL", function (a, b) {
                return !b || C.test(b)
        });
        h.fn(":number", "Please enter a numeric value.", function (a, b) {
                return A.test(b)
        });
        h.fn("[max]", "Please enter a value smaller than $1", function (a, b) {
                if (b === "" || r && a.is(":date")) return true;
                a = a.attr("max");
                return parseFloat(b) <= parseFloat(a) ? true : [a]
        });
        h.fn("[min]", "Please enter a value larger than $1", function (a, b) {
                if (b === "" || r && a.is(":date")) return true;
                a = a.attr("min");
                return parseFloat(b) >= parseFloat(a) ? true : [a]
        });
        h.fn("[required]", "Please complete this mandatory field.", function (a, b) {
                if (a.is(":checkbox")) return a.is(":checked");
                return !!b
        });
        h.fn("[pattern]", function (a) {
                var b = new RegExp("^" + a.attr("pattern") + "$");
                return b.test(a.val())
        });
        e.fn.validator = function (a) {
                var b = this.data("validator");
                if (b) {
                        b.destroy();
                        this.removeData("validator")
                }
                a = e.extend(true, {}, h.conf, a);
                if (this.is("form")) return this.each(function () {
                        var c = e(this);
                        b = new u(c.find(":input"), c, a);
                        c.data("validator", b)
                });
                else {
                        b = new u(this, this.eq(0).closest("form"), a);
                        return this.data("validator", b)
                }
        }
})(jQuery);

































/*
 * Viewport - jQuery selectors for finding elements in viewport
 *
 * Copyright (c) 2008-2009 Mika Tuupola
 *
 * Licensed under the MIT license:
 *   http://www.opensource.org/licenses/mit-license.php
 *
 * Project home:
 *  http://www.appelsiini.net/projects/viewport
 *
 */
(function ($) {

        "use strict";

        $.belowthefold = function (element, settings) {
                var fold = $(window).height() + $(window).scrollTop();
                return fold <= $(element).offset().top - settings.threshold;
        };

        $.abovethetop = function (element, settings) {
                var top = $(window).scrollTop();
                return top >= $(element).offset().top + $(element).height() - settings.threshold;
        };

        $.rightofscreen = function (element, settings) {
                var fold = $(window).width() + $(window).scrollLeft();
                return fold <= $(element).offset().left - settings.threshold;
        };

        $.leftofscreen = function (element, settings) {
                var left = $(window).scrollLeft();
                return left >= $(element).offset().left + $(element).width() - settings.threshold;
        };

        $.inviewport = function (element, settings) {
                return !$.rightofscreen(element, settings) && !$.leftofscreen(element, settings) && !$.belowthefold(element, settings) && !$.abovethetop(element, settings);
        };

        $.extend($.expr[':'], {
                "below-the-fold": function (a) {
                        return $.belowthefold(a, {
                                threshold: 0
                        });
                },
                "above-the-top": function (a) {
                        return $.abovethetop(a, {
                                threshold: 0
                        });
                },
                "left-of-screen": function (a) {
                        return $.leftofscreen(a, {
                                threshold: 0
                        });
                },
                "right-of-screen": function (a) {
                        return $.rightofscreen(a, {
                                threshold: 0
                        });
                },
                "in-viewport": function (a) {
                        return $.inviewport(a, {
                                threshold: -40
                        });
                }
        });


})(jQuery);



























/**
 * @depends jquery
 * @name jquery.scrollto
 * @package jquery-scrollto {@link http://balupton.com/projects/jquery-scrollto}
 */

/**
 * jQuery Aliaser
 */
(function (window, undefined) {
        // Prepare
        var jQuery, $, ScrollTo;
        jQuery = $ = window.jQuery;

        /**
         * jQuery ScrollTo (balupton edition)
         * @version 1.2.0
         * @date July 9, 2012
         * @since 0.1.0, August 27, 2010
         * @package jquery-scrollto {@link http://balupton.com/projects/jquery-scrollto}
         * @author Benjamin "balupton" Lupton {@link http://balupton.com}
         * @copyright (c) 2010 Benjamin Arthur Lupton {@link http://balupton.com}
         * @license MIT License {@link http://creativecommons.org/licenses/MIT/}
         */
        ScrollTo = $.ScrollTo = $.ScrollTo || {
                /**
                 * The Default Configuration
                 */
                config: {
                        duration: 400,
                        easing: 'swing',
                        callback: undefined,
                        durationMode: 'each',
                        offsetTop: 0,
                        offsetLeft: 0
                },

                /**
                 * Configure ScrollTo
                 */
                configure: function (options) {
                        // Apply Options to Config
                        $.extend(ScrollTo.config, options || {});

                        // Chain
                        return this;
                },

                /**
                 * Perform the Scroll Animation for the Collections
                 * We use $inline here, so we can determine the actual offset start for each overflow:scroll item
                 * Each collection is for each overflow:scroll item
                 */
                scroll: function (collections, config) {
                        // Prepare
                        var collection, $container, container, $target, $inline, position, containerScrollTop, containerScrollLeft, containerScrollTopEnd, containerScrollLeftEnd, startOffsetTop, targetOffsetTop, targetOffsetTopAdjusted, startOffsetLeft, targetOffsetLeft, targetOffsetLeftAdjusted, scrollOptions, callback;

                        // Determine the Scroll
                        collection = collections.pop();
                        $container = collection.$container;
                        container = $container.get(0);
                        $target = collection.$target;

                        // Prepare the Inline Element of the Container
                        $inline = $('<span/>').css({
                                'position': 'absolute',
                                'top': '0px',
                                'left': '0px'
                        });
                        position = $container.css('position');

                        // Insert the Inline Element of the Container
                        $container.css('position', 'relative');
                        $inline.appendTo($container);

                        // Determine the top offset
                        startOffsetTop = $inline.offset().top;
                        targetOffsetTop = $target.offset().top;
                        targetOffsetTopAdjusted = targetOffsetTop - startOffsetTop - parseInt(config.offsetTop, 10);

                        // Determine the left offset
                        startOffsetLeft = $inline.offset().left;
                        targetOffsetLeft = $target.offset().left;
                        targetOffsetLeftAdjusted = targetOffsetLeft - startOffsetLeft - parseInt(config.offsetLeft, 10);

                        // Determine current scroll positions
                        containerScrollTop = container.scrollTop;
                        containerScrollLeft = container.scrollLeft;

                        // Reset the Inline Element of the Container
                        $inline.remove();
                        $container.css('position', position);

                        // Prepare the scroll options
                        scrollOptions = {};

                        // Prepare the callback
                        callback = function (event) {
                                // Check
                                if (collections.length === 0) {
                                        // Callback
                                        if (typeof config.callback === 'function') {
                                                config.callback.apply(this, [event]);
                                        }
                                } else {
                                        // Recurse
                                        ScrollTo.scroll(collections, config);
                                }
                                // Return true
                                return true;
                        };

                        // Handle if we only want to scroll if we are outside the viewport
                        if (config.onlyIfOutside) {
                                // Determine current scroll positions
                                containerScrollTopEnd = containerScrollTop + $container.height();
                                containerScrollLeftEnd = containerScrollLeft + $container.width();

                                // Check if we are in the range of the visible area of the container
                                if (containerScrollTop < targetOffsetTopAdjusted && targetOffsetTopAdjusted < containerScrollTopEnd) {
                                        targetOffsetTopAdjusted = containerScrollTop;
                                }
                                if (containerScrollLeft < targetOffsetLeftAdjusted && targetOffsetLeftAdjusted < containerScrollLeftEnd) {
                                        targetOffsetLeftAdjusted = containerScrollLeft;
                                }
                        }

                        // Determine the scroll options
                        if (targetOffsetTopAdjusted !== containerScrollTop) {
                                scrollOptions.scrollTop = targetOffsetTopAdjusted;
                        }
                        if (targetOffsetLeftAdjusted !== containerScrollLeft) {
                                scrollOptions.scrollLeft = targetOffsetLeftAdjusted;
                        }

                        // Perform the scroll
                        if ($.browser.safari && container === document.body) {
                                window.scrollTo(scrollOptions.scrollLeft, scrollOptions.scrollTop);
                                callback();
                        } else if (scrollOptions.scrollTop || scrollOptions.scrollLeft) {
                                $container.animate(scrollOptions, config.duration, config.easing, callback);
                        } else {
                                callback();
                        }

                        // Return true
                        return true;
                },

                /**
                 * ScrollTo the Element using the Options
                 */
                fn: function (options) {
                        // Prepare
                        var collections, config, $container, container;
                        collections = [];

                        // Prepare
                        var $target = $(this);
                        if ($target.length === 0) {
                                // Chain
                                return this;
                        }

                        // Handle Options
                        config = $.extend({}, ScrollTo.config, options);

                        // Fetch
                        $container = $target.parent();
                        container = $container.get(0);

                        // Cycle through the containers
                        while (($container.length === 1) && (container !== document.body) && (container !== document)) {
                                // Check Container for scroll differences
                                var scrollTop, scrollLeft;
                                scrollTop = $container.css('overflow-y') !== 'visible' && container.scrollHeight !== container.clientHeight;
                                scrollLeft = $container.css('overflow-x') !== 'visible' && container.scrollWidth !== container.clientWidth;
                                if (scrollTop || scrollLeft) {
                                        // Push the Collection
                                        collections.push({
                                                '$container': $container,
                                                '$target': $target
                                        });
                                        // Update the Target
                                        $target = $container;
                                }
                                // Update the Container
                                $container = $container.parent();
                                container = $container.get(0);
                        }

                        // Add the final collection
                        collections.push({
                                '$container': $(($.browser.msie || $.browser.mozilla) ? 'html' : 'body'),
                                '$target': $target
                        });

                        // Adjust the Config
                        if (config.durationMode === 'all') {
                                config.duration /= collections.length;
                        }

                        // Handle
                        ScrollTo.scroll(collections, config);

                        // Chain
                        return this;
                }
        };

        // Apply our jQuery Prototype Function
        $.fn.ScrollTo = $.ScrollTo.fn;

})(window);




























/*
 
 jQuery Tools 1.2.5 Tabs- The basics of UI design.

 NO COPYRIGHTS OR LICENSES. DO WHAT YOU LIKE.

 http://flowplayer.org/tools/tabs/

 Since: November 2008
 Date:    Wed Sep 22 06:02:10 2010 +0000 
*/
(function (c) {
        function p(d, b, a) {
                var e = this,
                        l = d.add(this),
                        h = d.find(a.toolsTabs),
                        i = b.jquery ? b : d.children(b),
                        j;
                h.length || (h = d.children());
                i.length || (i = d.parent().find(b));
                i.length || (i = c(b));
                c.extend(this, {
                        click: function (f, g) {
                                var k = h.eq(f);
                                if (typeof f == "string" && f.replace("#", "")) {
                                        k = h.filter("[href*=" + f.replace("#", "") + "]");
                                        f = Math.max(h.index(k), 0)
                                }
                                if (a.rotate) {
                                        var n = h.length - 1;
                                        if (f < 0) return e.click(n, g);
                                        if (f > n) return e.click(0, g)
                                }
                                if (!k.length) {
                                        if (j >= 0) return e;
                                        f = a.initialIndex;
                                        k = h.eq(f)
                                }
                                if (f === j) return e;
                                g = g || c.Event();
                                g.type = "onBeforeClick";
                                l.trigger(g, [f]);
                                if (!g.isDefaultPrevented()) {
                                        o[a.effect].call(e, f, function () {
                                                g.type = "onClick";
                                                l.trigger(g, [f])
                                        });
                                        j = f;
                                        h.removeClass(a.current);
                                        k.addClass(a.current);
                                        return e
                                }
                        },
                        getConf: function () {
                                return a
                        },
                        getTabs: function () {
                                return h
                        },
                        getPanes: function () {
                                return i
                        },
                        getCurrentPane: function () {
                                return i.eq(j)
                        },
                        getCurrentTab: function () {
                                return h.eq(j)
                        },
                        getIndex: function () {
                                return j
                        },
                        next: function () {
                                return e.click(j + 1)
                        },
                        prev: function () {
                                return e.click(j - 1)
                        },
                        destroy: function () {
                                h.unbind(a.event).removeClass(a.current);
                                i.find("a[href^=#]").unbind("click.T");
                                return e
                        }
                });
                c.each("onBeforeClick,onClick".split(","), function (f, g) {
                        c.isFunction(a[g]) && c(e).bind(g, a[g]);
                        e[g] = function (k) {
                                k && c(e).bind(g, k);
                                return e
                        }
                });
                if (a.history && c.fn.history) {
                        c.tools.history.init(h);
                        a.event = "history"
                }
                h.each(function (f) {
                        c(this).bind(a.event, function (g) {
                                e.click(f, g);
                                return g.preventDefault()
                        })
                });
                i.find("a[href^=#]").bind("click.T", function (f) {
                        e.click(c(this).attr("href"), f)
                });
                if (location.hash && a.toolsTabs == "a" && d.find("[href=" + location.hash + "]").length) e.click(location.hash);
                else if (a.initialIndex === 0 || a.initialIndex > 0) e.click(a.initialIndex)
        }
        c.tools = c.tools || {
                version: "1.2.5"
        };
        c.tools.toolsTabs = {
                conf: {
                        toolsTabs: "a",
                        current: "current",
                        onBeforeClick: null,
                        onClick: null,
                        effect: "default",
                        initialIndex: 0,
                        event: "click",
                        rotate: false,
                        history: false
                },
                addEffect: function (d, b) {
                        o[d] = b
                }
        };
        var o = {
                "default": function (d, b) {
                        this.getPanes().addClass('visuallyhidden').eq(d).removeClass('visuallyhidden');
                        b.call()
                },
                fade: function (d, b) {
                        var a = this.getConf(),
                                e = a.fadeOutSpeed,
                                l = this.getPanes();
                        e ? l.fadeOut(e) : l.hide();
                        l.eq(d).fadeIn(a.fadeInSpeed, b)
                },
                slide: function (d, b) {
                        this.getPanes().slideUp(100);
                        this.getPanes().eq(d).slideDown(100, b)
                },
                ajax: function (d, b) {
                        this.getPanes().eq(0).load(this.getTabs().eq(d).attr("href"), b)
                }
        },
                m;
        c.tools.toolsTabs.addEffect("horizontal", function (d, b) {
                m || (m = this.getPanes().eq(0).width());
                this.getCurrentPane().animate({
                        width: 0
                }, function () {
                        c(this).hide()
                });
                this.getPanes().eq(d).animate({
                        width: m
                }, function () {
                        c(this).show();
                        b.call()
                })
        });
        c.fn.toolsTabs = function (d, b) {
                var a = this.data("toolsTabs");
                if (a) {
                        a.destroy();
                        this.removeData("toolsTabs")
                }
                if (c.isFunction(b)) b = {
                        onBeforeClick: b
                };
                b = c.extend({}, c.tools.toolsTabs.conf, b);
                this.each(function () {
                        a = new p(c(this), d, b);
                        c(this).data("toolsTabs", a)
                });
                return b.api ? a : this
        }
})(jQuery);



























/*
 * jQuery FlexSlider v2.1
 * http://www.woothemes.com/flexslider/
 *
 * Copyright 2012 WooThemes
 * Free to use under the GPLv2 license.
 * http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Contributing author: Tyler Smith (@mbmufffin)
 */

;
(function ($) {

        //FlexSlider: Object Instance
        $.flexslider = function (el, options) {
                var slider = $(el),
                        vars = $.extend({}, $.flexslider.defaults, options),
                        namespace = vars.namespace,
                        touch = ("ontouchstart" in window) || window.DocumentTouch && document instanceof DocumentTouch,
                        eventType = (touch) ? "touchend" : "click",
                        vertical = vars.direction === "vertical",
                        reverse = vars.reverse,
                        carousel = (vars.itemWidth > 0),
                        fade = vars.animation === "fade",
                        asNav = vars.asNavFor !== "",
                        methods = {};

                // Store a reference to the slider object
                $.data(el, "flexslider", slider);

                // Privat slider methods
                methods = {
                        init: function () {
                                slider.animating = false;
                                slider.currentSlide = vars.startAt;
                                slider.animatingTo = slider.currentSlide;
                                slider.atEnd = (slider.currentSlide === 0 || slider.currentSlide === slider.last);
                                slider.containerSelector = vars.selector.substr(0, vars.selector.search(' '));
                                slider.slides = $(vars.selector, slider);
                                slider.container = $(slider.containerSelector, slider);
                                slider.count = slider.slides.length;
                                // SYNC:
                                slider.syncExists = $(vars.sync).length > 0;
                                // SLIDE:
                                if (vars.animation === "slide") vars.animation = "swing";
                                slider.prop = (vertical) ? "top" : "marginLeft";
                                slider.args = {};
                                // SLIDESHOW:
                                slider.manualPause = false;
                                // TOUCH/USECSS:
                                slider.transitions = !vars.video && !fade && vars.useCSS && (function () {
                                        var obj = document.createElement('div'),
                                                props = ['perspectiveProperty', 'WebkitPerspective', 'MozPerspective', 'OPerspective', 'msPerspective'];
                                        for (var i in props) {
                                                if (obj.style[props[i]] !== undefined) {
                                                        slider.pfx = props[i].replace('Perspective', '').toLowerCase();
                                                        slider.prop = "-" + slider.pfx + "-transform";
                                                        return true;
                                                }
                                        }
                                        return false;
                                }());
                                // CONTROLSCONTAINER:
                                if (vars.controlsContainer !== "") slider.controlsContainer = $(vars.controlsContainer).length > 0 && $(vars.controlsContainer);
                                // MANUAL:
                                if (vars.manualControls !== "") slider.manualControls = $(vars.manualControls).length > 0 && $(vars.manualControls);

                                // RANDOMIZE:
                                if (vars.randomize) {
                                        slider.slides.sort(function () {
                                                return (Math.round(Math.random()) - 0.5);
                                        });
                                        slider.container.empty().append(slider.slides);
                                }

                                slider.doMath();

                                // ASNAV:
                                if (asNav) methods.asNav.setup();

                                // INIT
                                slider.setup("init");

                                // CONTROLNAV:
                                if (vars.controlNav) methods.controlNav.setup();

                                // DIRECTIONNAV:
                                if (vars.directionNav) methods.directionNav.setup();

                                // KEYBOARD:
                                if (vars.keyboard && ($(slider.containerSelector).length === 1 || vars.multipleKeyboard)) {
                                        $(document).bind('keyup', function (event) {
                                                var keycode = event.keyCode;
                                                if (!slider.animating && (keycode === 39 || keycode === 37)) {
                                                        var target = (keycode === 39) ? slider.getTarget('next') : (keycode === 37) ? slider.getTarget('prev') : false;
                                                        slider.flexAnimate(target, vars.pauseOnAction);
                                                }
                                        });
                                }
                                // MOUSEWHEEL:
                                if (vars.mousewheel) {
                                        slider.bind('mousewheel', function (event, delta, deltaX, deltaY) {
                                                event.preventDefault();
                                                var target = (delta < 0) ? slider.getTarget('next') : slider.getTarget('prev');
                                                slider.flexAnimate(target, vars.pauseOnAction);
                                        });
                                }

                                // PAUSEPLAY
                                if (vars.pausePlay) methods.pausePlay.setup();

                                // SLIDSESHOW
                                if (vars.slideshow) {
                                        if (vars.pauseOnHover) {
                                                slider.hover(function () {
                                                        if (!slider.manualPlay && !slider.manualPause) slider.pause();
                                                }, function () {
                                                        if (!slider.manualPause && !slider.manualPlay) slider.play();
                                                });
                                        }
                                        // initialize animation
                                        (vars.initDelay > 0) ? setTimeout(slider.play, vars.initDelay) : slider.play();
                                }

                                // TOUCH
                                if (touch && vars.touch) methods.touch();

                                // FADE&&SMOOTHHEIGHT || SLIDE:
                                if (!fade || (fade && vars.smoothHeight)) $(window).bind("resize focus", methods.resize);


                                // API: start() Callback
                                setTimeout(function () {
                                        vars.start(slider);
                                }, 200);
                        },
                        asNav: {
                                setup: function () {
                                        slider.asNav = true;
                                        slider.animatingTo = Math.floor(slider.currentSlide / slider.move);
                                        slider.currentItem = slider.currentSlide;
                                        slider.slides.removeClass(namespace + "active-slide").eq(slider.currentItem).addClass(namespace + "active-slide");
                                        slider.slides.click(function (e) {
                                                e.preventDefault();
                                                var $slide = $(this),
                                                        target = $slide.index();
                                                if (!$(vars.asNavFor).data('flexslider').animating && !$slide.hasClass('active')) {
                                                        slider.direction = (slider.currentItem < target) ? "next" : "prev";
                                                        slider.flexAnimate(target, vars.pauseOnAction, false, true, true);
                                                }
                                        });
                                }
                        },
                        controlNav: {
                                setup: function () {
                                        if (!slider.manualControls) {
                                                methods.controlNav.setupPaging();
                                        } else { // MANUALCONTROLS:
                                                methods.controlNav.setupManual();
                                        }
                                },
                                setupPaging: function () {
                                        var type = (vars.controlNav === "thumbnails") ? 'control-thumbs' : 'control-paging',
                                                j = 1,
                                                item;

                                        slider.controlNavScaffold = $('<ol class="' + namespace + 'control-nav ' + namespace + type + '"></ol>');

                                        if (slider.pagingCount > 1) {
                                                for (var i = 0; i < slider.pagingCount; i++) {
                                                        item = (vars.controlNav === "thumbnails") ? '<img src="' + slider.slides.eq(i).attr("data-thumb") + '"/>' : '<a><i class="mk-icon-circle-blank"></i></a>';
                                                        slider.controlNavScaffold.append('<li>' + item + '</li>');
                                                        j++;
                                                }
                                        }

                                        // CONTROLSCONTAINER:
                                        (slider.controlsContainer) ? $(slider.controlsContainer).append(slider.controlNavScaffold) : slider.append(slider.controlNavScaffold);
                                        methods.controlNav.set();

                                        methods.controlNav.active();

                                        slider.controlNavScaffold.delegate('a, img', eventType, function (event) {
                                                event.preventDefault();
                                                var $this = $(this),
                                                        target = slider.controlNav.index($this);

                                                if (!$this.hasClass(namespace + 'active')) {
                                                        slider.direction = (target > slider.currentSlide) ? "next" : "prev";
                                                        slider.flexAnimate(target, vars.pauseOnAction);
                                                }
                                        });
                                        // Prevent iOS click event bug
                                        if (touch) {
                                                slider.controlNavScaffold.delegate('a', "click touchstart", function (event) {
                                                        event.preventDefault();
                                                });
                                        }
                                },
                                setupManual: function () {
                                        slider.controlNav = slider.manualControls;
                                        methods.controlNav.active();

                                        slider.controlNav.live(eventType, function (event) {
                                                event.preventDefault();
                                                var $this = $(this),
                                                        target = slider.controlNav.index($this);

                                                if (!$this.hasClass(namespace + 'active')) {
                                                        (target > slider.currentSlide) ? slider.direction = "next" : slider.direction = "prev";
                                                        slider.flexAnimate(target, vars.pauseOnAction);
                                                }
                                        });
                                        // Prevent iOS click event bug
                                        if (touch) {
                                                slider.controlNav.live("click touchstart", function (event) {
                                                        event.preventDefault();
                                                });
                                        }
                                },
                                set: function () {
                                        var selector = (vars.controlNav === "thumbnails") ? 'img' : 'a';
                                        slider.controlNav = $('.' + namespace + 'control-nav li ' + selector, (slider.controlsContainer) ? slider.controlsContainer : slider);
                                },
                                active: function () {
                                        slider.controlNav.removeClass(namespace + "active").eq(slider.animatingTo).addClass(namespace + "active");
                                },
                                update: function (action, pos) {
                                        if (slider.pagingCount > 1 && action === "add") {
                                                slider.controlNavScaffold.append($('<li><a>' + slider.count + '</a></li>'));
                                        } else if (slider.pagingCount === 1) {
                                                slider.controlNavScaffold.find('li').remove();
                                        } else {
                                                slider.controlNav.eq(pos).closest('li').remove();
                                        }
                                        methods.controlNav.set();
                                        (slider.pagingCount > 1 && slider.pagingCount !== slider.controlNav.length) ? slider.update(pos, action) : methods.controlNav.active();
                                }
                        },
                        directionNav: {
                                setup: function () {
                                        var directionNavScaffold = $('<ul class="' + namespace + 'direction-nav"><li><a class="' + namespace + 'prev" href="#">' + vars.directionNavArrowsLeft + vars.prevText + '</a></li><li><a class="' + namespace + 'next" href="#">' + vars.directionNavArrowsRight + vars.nextText + '</a></li></ul>');

                                        // CONTROLSCONTAINER:
                                        if (slider.controlsContainer) {
                                                $(slider.controlsContainer).append(directionNavScaffold);
                                                slider.directionNav = $('.' + namespace + 'direction-nav li a', slider.controlsContainer);
                                        } else {
                                                slider.append(directionNavScaffold);
                                                slider.directionNav = $('.' + namespace + 'direction-nav li a', slider);
                                        }

                                        methods.directionNav.update();

                                        slider.directionNav.bind(eventType, function (event) {
                                                event.preventDefault();
                                                var target = ($(this).hasClass(namespace + 'next')) ? slider.getTarget('next') : slider.getTarget('prev');
                                                slider.flexAnimate(target, vars.pauseOnAction);
                                        });
                                        // Prevent iOS click event bug
                                        if (touch) {
                                                slider.directionNav.bind("click touchstart", function (event) {
                                                        event.preventDefault();
                                                });
                                        }
                                },
                                update: function () {
                                        var disabledClass = namespace + 'disabled';
                                        if (slider.pagingCount === 1) {
                                                slider.directionNav.addClass(disabledClass);
                                        } else if (!vars.animationLoop) {
                                                if (slider.animatingTo === 0) {
                                                        slider.directionNav.removeClass(disabledClass).filter('.' + namespace + "prev").addClass(disabledClass);
                                                } else if (slider.animatingTo === slider.last) {
                                                        slider.directionNav.removeClass(disabledClass).filter('.' + namespace + "next").addClass(disabledClass);
                                                } else {
                                                        slider.directionNav.removeClass(disabledClass);
                                                }
                                        } else {
                                                slider.directionNav.removeClass(disabledClass);
                                        }
                                }
                        },
                        pausePlay: {
                                setup: function () {
                                        var pausePlayScaffold = $('<div class="' + namespace + 'pauseplay"><a></a></div>');

                                        // CONTROLSCONTAINER:
                                        if (slider.controlsContainer) {
                                                slider.controlsContainer.append(pausePlayScaffold);
                                                slider.pausePlay = $('.' + namespace + 'pauseplay a', slider.controlsContainer);
                                        } else {
                                                slider.append(pausePlayScaffold);
                                                slider.pausePlay = $('.' + namespace + 'pauseplay a', slider);
                                        }

                                        methods.pausePlay.update((vars.slideshow) ? namespace + 'pause' : namespace + 'play');

                                        slider.pausePlay.bind(eventType, function (event) {
                                                event.preventDefault();
                                                if ($(this).hasClass(namespace + 'pause')) {
                                                        slider.manualPause = true;
                                                        slider.manualPlay = false;
                                                        slider.pause();
                                                } else {
                                                        slider.manualPause = false;
                                                        slider.manualPlay = true;
                                                        slider.play();
                                                }
                                        });
                                        // Prevent iOS click event bug
                                        if (touch) {
                                                slider.pausePlay.bind("click touchstart", function (event) {
                                                        event.preventDefault();
                                                });
                                        }
                                },
                                update: function (state) {
                                        (state === "play") ? slider.pausePlay.removeClass(namespace + 'pause').addClass(namespace + 'play').text(vars.playText) : slider.pausePlay.removeClass(namespace + 'play').addClass(namespace + 'pause').text(vars.pauseText);
                                }
                        },
                        touch: function () {
                                var startX, startY, offset, cwidth, dx, startT, scrolling = false;

                                el.addEventListener('touchstart', onTouchStart, false);

                                function onTouchStart(e) {
                                        if (slider.animating) {
                                                e.preventDefault();
                                        } else if (e.touches.length === 1) {
                                                slider.pause();
                                                // CAROUSEL: 
                                                cwidth = (vertical) ? slider.h : slider.w;
                                                startT = Number(new Date());
                                                // CAROUSEL:
                                                offset = (carousel && reverse && slider.animatingTo === slider.last) ? 0 : (carousel && reverse) ? slider.limit - (((slider.itemW + vars.itemMargin) * slider.move) * slider.animatingTo) : (carousel && slider.currentSlide === slider.last) ? slider.limit : (carousel) ? ((slider.itemW + vars.itemMargin) * slider.move) * slider.currentSlide : (reverse) ? (slider.last - slider.currentSlide + slider.cloneOffset) * cwidth : (slider.currentSlide + slider.cloneOffset) * cwidth;
                                                startX = (vertical) ? e.touches[0].pageY : e.touches[0].pageX;
                                                startY = (vertical) ? e.touches[0].pageX : e.touches[0].pageY;

                                                el.addEventListener('touchmove', onTouchMove, false);
                                                el.addEventListener('touchend', onTouchEnd, false);
                                        }
                                }

                                function onTouchMove(e) {
                                        dx = (vertical) ? startX - e.touches[0].pageY : startX - e.touches[0].pageX;
                                        scrolling = (vertical) ? (Math.abs(dx) < Math.abs(e.touches[0].pageX - startY)) : (Math.abs(dx) < Math.abs(e.touches[0].pageY - startY));

                                        if (!scrolling || Number(new Date()) - startT > 500) {
                                                e.preventDefault();
                                                if (!fade && slider.transitions) {
                                                        if (!vars.animationLoop) {
                                                                dx = dx / ((slider.currentSlide === 0 && dx < 0 || slider.currentSlide === slider.last && dx > 0) ? (Math.abs(dx) / cwidth + 2) : 1);
                                                        }
                                                        slider.setProps(offset + dx, "setTouch");
                                                }
                                        }
                                }

                                function onTouchEnd(e) {
                                        // finish the touch by undoing the touch session
                                        el.removeEventListener('touchmove', onTouchMove, false);

                                        if (slider.animatingTo === slider.currentSlide && !scrolling && !(dx === null)) {
                                                var updateDx = (reverse) ? -dx : dx,
                                                        target = (updateDx > 0) ? slider.getTarget('next') : slider.getTarget('prev');

                                                if (slider.canAdvance(target) && (Number(new Date()) - startT < 550 && Math.abs(updateDx) > 50 || Math.abs(updateDx) > cwidth / 2)) {
                                                        slider.flexAnimate(target, vars.pauseOnAction);
                                                } else {
                                                        if (!fade) slider.flexAnimate(slider.currentSlide, vars.pauseOnAction, true);
                                                }
                                        }
                                        el.removeEventListener('touchend', onTouchEnd, false);
                                        startX = null;
                                        startY = null;
                                        dx = null;
                                        offset = null;
                                }
                        },
                        resize: function () {
                                if (!slider.animating && slider.is(':visible')) {
                                        if (!carousel) slider.doMath();

                                        if (fade) {
                                                // SMOOTH HEIGHT:
                                                methods.smoothHeight();
                                        } else if (carousel) { //CAROUSEL:
                                                slider.slides.width(slider.computedW);
                                                slider.update(slider.pagingCount);
                                                slider.setProps();
                                        } else if (vertical) { //VERTICAL:
                                                slider.viewport.height(slider.h);
                                                slider.setProps(slider.h, "setTotal");
                                        } else {
                                                // SMOOTH HEIGHT:
                                                if (vars.smoothHeight) methods.smoothHeight();
                                                slider.newSlides.width(slider.computedW);
                                                slider.setProps(slider.computedW, "setTotal");
                                        }
                                }
                        },
                        smoothHeight: function (dur) {
                                if (!vertical || fade) {
                                        var $obj = (fade) ? slider : slider.viewport;
                                        (dur) ? $obj.animate({
                                                "height": slider.slides.eq(slider.animatingTo).height()
                                        }, dur) : $obj.height(slider.slides.eq(slider.animatingTo).height());
                                }
                        },
                        sync: function (action) {
                                var $obj = $(vars.sync).data("flexslider"),
                                        target = slider.animatingTo;

                                switch (action) {
                                case "animate":
                                        $obj.flexAnimate(target, vars.pauseOnAction, false, true);
                                        break;
                                case "play":
                                        if (!$obj.playing && !$obj.asNav) {
                                                $obj.play();
                                        }
                                        break;
                                case "pause":
                                        $obj.pause();
                                        break;
                                }
                        }
                }

                // public methods
                slider.flexAnimate = function (target, pause, override, withSync, fromNav) {
                        if (asNav && slider.pagingCount === 1) slider.direction = (slider.currentItem < target) ? "next" : "prev";

                        if (!slider.animating && (slider.canAdvance(target, fromNav) || override) && slider.is(":visible")) {
                                if (asNav && withSync) {
                                        var master = $(vars.asNavFor).data('flexslider');
                                        slider.atEnd = target === 0 || target === slider.count - 1;
                                        master.flexAnimate(target, true, false, true, fromNav);
                                        slider.direction = (slider.currentItem < target) ? "next" : "prev";
                                        master.direction = slider.direction;

                                        if (Math.ceil((target + 1) / slider.visible) - 1 !== slider.currentSlide && target !== 0) {
                                                slider.currentItem = target;
                                                slider.slides.removeClass(namespace + "active-slide").eq(target).addClass(namespace + "active-slide");
                                                target = Math.floor(target / slider.visible);
                                        } else {
                                                slider.currentItem = target;
                                                slider.slides.removeClass(namespace + "active-slide").eq(target).addClass(namespace + "active-slide");
                                                return false;
                                        }
                                }

                                slider.animating = true;
                                slider.animatingTo = target;
                                // API: before() animation Callback
                                vars.before(slider);

                                // SLIDESHOW:
                                if (pause) slider.pause();

                                // SYNC:
                                if (slider.syncExists && !fromNav) methods.sync("animate");

                                // CONTROLNAV
                                if (vars.controlNav) methods.controlNav.active();

                                // !CAROUSEL:
                                // CANDIDATE: slide active class (for add/remove slide)
                                if (!carousel) slider.slides.removeClass(namespace + 'active-slide').eq(target).addClass(namespace + 'active-slide');

                                // INFINITE LOOP:
                                // CANDIDATE: atEnd
                                slider.atEnd = target === 0 || target === slider.last;

                                // DIRECTIONNAV:
                                if (vars.directionNav) methods.directionNav.update();

                                if (target === slider.last) {
                                        // API: end() of cycle Callback
                                        vars.end(slider);
                                        // SLIDESHOW && !INFINITE LOOP:
                                        if (!vars.animationLoop) slider.pause();
                                }

                                // SLIDE:
                                if (!fade) {
                                        var dimension = (vertical) ? slider.slides.filter(':first').height() : slider.computedW,
                                                margin, slideString, calcNext;

                                        // INFINITE LOOP / REVERSE:
                                        if (carousel) {
                                                margin = (vars.itemWidth > slider.w) ? vars.itemMargin * 2 : vars.itemMargin;
                                                calcNext = ((slider.itemW + margin) * slider.move) * slider.animatingTo;
                                                slideString = (calcNext > slider.limit && slider.visible !== 1) ? slider.limit : calcNext;
                                        } else if (slider.currentSlide === 0 && target === slider.count - 1 && vars.animationLoop && slider.direction !== "next") {
                                                slideString = (reverse) ? (slider.count + slider.cloneOffset) * dimension : 0;
                                        } else if (slider.currentSlide === slider.last && target === 0 && vars.animationLoop && slider.direction !== "prev") {
                                                slideString = (reverse) ? 0 : (slider.count + 1) * dimension;
                                        } else {
                                                slideString = (reverse) ? ((slider.count - 1) - target + slider.cloneOffset) * dimension : (target + slider.cloneOffset) * dimension;
                                        }
                                        slider.setProps(slideString, "", vars.animationSpeed);
                                        if (slider.transitions) {
                                                if (!vars.animationLoop || !slider.atEnd) {
                                                        slider.animating = false;
                                                        slider.currentSlide = slider.animatingTo;
                                                }
                                                slider.container.unbind("webkitTransitionEnd transitionend");
                                                slider.container.bind("webkitTransitionEnd transitionend", function () {
                                                        slider.wrapup(dimension);
                                                });
                                        } else {
                                                slider.container.animate(slider.args, vars.animationSpeed, vars.easing, function () {
                                                        slider.wrapup(dimension);
                                                });
                                        }
                                } else { // FADE:
                                        if (!touch) {
                                                slider.slides.eq(slider.currentSlide).fadeOut(vars.animationSpeed, vars.easing);
                                                slider.slides.eq(target).fadeIn(vars.animationSpeed, vars.easing, slider.wrapup);
                                        } else {
                                                slider.slides.eq(slider.currentSlide).css({
                                                        "opacity": 0,
                                                        "zIndex": 1
                                                });
                                                slider.slides.eq(target).css({
                                                        "opacity": 1,
                                                        "zIndex": 2
                                                });
                                                slider.animating = false;
                                                slider.currentSlide = slider.animatingTo;
                                        }
                                }
                                // SMOOTH HEIGHT:
                                if (vars.smoothHeight) methods.smoothHeight(vars.animationSpeed);
                        }
                }
                slider.wrapup = function (dimension) {
                        // SLIDE:
                        if (!fade && !carousel) {
                                if (slider.currentSlide === 0 && slider.animatingTo === slider.last && vars.animationLoop) {
                                        slider.setProps(dimension, "jumpEnd");
                                } else if (slider.currentSlide === slider.last && slider.animatingTo === 0 && vars.animationLoop) {
                                        slider.setProps(dimension, "jumpStart");
                                }
                        }
                        slider.animating = false;
                        slider.currentSlide = slider.animatingTo;
                        // API: after() animation Callback
                        vars.after(slider);
                }

                // SLIDESHOW:
                slider.animateSlides = function () {
                        if (!slider.animating) slider.flexAnimate(slider.getTarget("next"));
                }
                // SLIDESHOW:
                slider.pause = function () {
                        clearInterval(slider.animatedSlides);
                        slider.playing = false;
                        // PAUSEPLAY:
                        if (vars.pausePlay) methods.pausePlay.update("play");
                        // SYNC:
                        if (slider.syncExists) methods.sync("pause");
                }
                // SLIDESHOW:
                slider.play = function () {
                        slider.animatedSlides = setInterval(slider.animateSlides, vars.slideshowSpeed);
                        slider.playing = true;
                        // PAUSEPLAY:
                        if (vars.pausePlay) methods.pausePlay.update("pause");
                        // SYNC:
                        if (slider.syncExists) methods.sync("play");
                }
                slider.canAdvance = function (target, fromNav) {
                        // ASNAV:
                        var last = (asNav) ? slider.pagingCount - 1 : slider.last;
                        return (fromNav) ? true : (asNav && slider.currentItem === slider.count - 1 && target === 0 && slider.direction === "prev") ? true : (asNav && slider.currentItem === 0 && target === slider.pagingCount - 1 && slider.direction !== "next") ? false : (target === slider.currentSlide && !asNav) ? false : (vars.animationLoop) ? true : (slider.atEnd && slider.currentSlide === 0 && target === last && slider.direction !== "next") ? false : (slider.atEnd && slider.currentSlide === last && target === 0 && slider.direction === "next") ? false : true;
                }
                slider.getTarget = function (dir) {
                        slider.direction = dir;
                        if (dir === "next") {
                                return (slider.currentSlide === slider.last) ? 0 : slider.currentSlide + 1;
                        } else {
                                return (slider.currentSlide === 0) ? slider.last : slider.currentSlide - 1;
                        }
                }

                // SLIDE:
                slider.setProps = function (pos, special, dur) {
                        var target = (function () {
                                var posCheck = (pos) ? pos : ((slider.itemW + vars.itemMargin) * slider.move) * slider.animatingTo,
                                        posCalc = (function () {
                                                if (carousel) {
                                                        return (special === "setTouch") ? pos : (reverse && slider.animatingTo === slider.last) ? 0 : (reverse) ? slider.limit - (((slider.itemW + vars.itemMargin) * slider.move) * slider.animatingTo) : (slider.animatingTo === slider.last) ? slider.limit : posCheck;
                                                } else {
                                                        switch (special) {
                                                        case "setTotal":
                                                                return (reverse) ? ((slider.count - 1) - slider.currentSlide + slider.cloneOffset) * pos : (slider.currentSlide + slider.cloneOffset) * pos;
                                                        case "setTouch":
                                                                return (reverse) ? pos : pos;
                                                        case "jumpEnd":
                                                                return (reverse) ? pos : slider.count * pos;
                                                        case "jumpStart":
                                                                return (reverse) ? slider.count * pos : pos;
                                                        default:
                                                                return pos;
                                                        }
                                                }
                                        }());
                                return (posCalc * -1) + "px";
                        }());

                        if (slider.transitions) {
                                target = (vertical) ? "translate3d(0," + target + ",0)" : "translate3d(" + target + ",0,0)";
                                dur = (dur !== undefined) ? (dur / 1000) + "s" : "0s";
                                slider.container.css("-" + slider.pfx + "-transition-duration", dur);
                        }

                        slider.args[slider.prop] = target;
                        if (slider.transitions || dur === undefined) slider.container.css(slider.args);
                }

                slider.setup = function (type) {
                        // SLIDE:
                        if (!fade) {
                                var sliderOffset, arr;

                                if (type === "init") {
                                        slider.viewport = $('<div class="' + namespace + 'viewport"></div>').css({
                                                "overflow": "hidden",
                                                "position": "relative"
                                        }).appendTo(slider).append(slider.container);
                                        // INFINITE LOOP:
                                        slider.cloneCount = 0;
                                        slider.cloneOffset = 0;
                                        // REVERSE:
                                        if (reverse) {
                                                arr = $.makeArray(slider.slides).reverse();
                                                slider.slides = $(arr);
                                                slider.container.empty().append(slider.slides);
                                        }
                                }
                                // INFINITE LOOP && !CAROUSEL:
                                if (vars.animationLoop && !carousel) {
                                        slider.cloneCount = 2;
                                        slider.cloneOffset = 1;
                                        // clear out old clones
                                        if (type !== "init") slider.container.find('.clone').remove();
                                        slider.container.append(slider.slides.first().clone().addClass('clone')).prepend(slider.slides.last().clone().addClass('clone'));
                                }
                                slider.newSlides = $(vars.selector, slider);

                                sliderOffset = (reverse) ? slider.count - 1 - slider.currentSlide + slider.cloneOffset : slider.currentSlide + slider.cloneOffset;
                                // VERTICAL:
                                if (vertical && !carousel) {
                                        slider.container.height((slider.count + slider.cloneCount) * 200 + "%").css("position", "absolute").width("100%");
                                        setTimeout(function () {
                                                slider.newSlides.css({
                                                        "display": "block"
                                                });
                                                slider.doMath();
                                                slider.viewport.height(slider.h);
                                                slider.setProps(sliderOffset * slider.h, "init");
                                        }, (type === "init") ? 100 : 0);
                                } else {
                                        slider.container.width((slider.count + slider.cloneCount) * 200 + "%");
                                        slider.setProps(sliderOffset * slider.computedW, "init");
                                        setTimeout(function () {
                                                slider.doMath();
                                                slider.newSlides.css({
                                                        "width": slider.computedW,
                                                        "float": "left",
                                                        "display": "block"
                                                });
                                                // SMOOTH HEIGHT:
                                                if (vars.smoothHeight) methods.smoothHeight();
                                        }, (type === "init") ? 100 : 0);
                                }
                        } else { // FADE: 
                                slider.slides.css({
                                        "width": "100%",
                                        "float": "left",
                                        "marginRight": "-100%",
                                        "position": "relative"
                                });
                                if (type === "init") {
                                        if (!touch) {
                                                slider.slides.eq(slider.currentSlide).fadeIn(vars.animationSpeed, vars.easing);
                                        } else {
                                                slider.slides.css({
                                                        "opacity": 0,
                                                        "display": "block",
                                                        "webkitTransition": "opacity " + vars.animationSpeed / 1000 + "s ease",
                                                        "zIndex": 1
                                                }).eq(slider.currentSlide).css({
                                                        "opacity": 1,
                                                        "zIndex": 2
                                                });
                                        }
                                }
                                // SMOOTH HEIGHT:
                                if (vars.smoothHeight) methods.smoothHeight();
                        }
                        // !CAROUSEL:
                        // CANDIDATE: active slide
                        if (!carousel) slider.slides.removeClass(namespace + "active-slide").eq(slider.currentSlide).addClass(namespace + "active-slide");
                }

                slider.doMath = function () {
                        var slide = slider.slides.first(),
                                slideMargin = vars.itemMargin,
                                minItems = vars.minItems,
                                maxItems = vars.maxItems;

                        slider.w = slider.width();
                        slider.h = slide.height();
                        slider.boxPadding = slide.outerWidth() - slide.width();

                        // CAROUSEL:
                        if (carousel) {
                                slider.itemT = vars.itemWidth + slideMargin;
                                slider.minW = (minItems) ? minItems * slider.itemT : slider.w;
                                slider.maxW = (maxItems) ? maxItems * slider.itemT : slider.w;
                                slider.itemW = (slider.minW > slider.w) ? (slider.w - (slideMargin * minItems)) / minItems : (slider.maxW < slider.w) ? (slider.w - (slideMargin * maxItems)) / maxItems : (vars.itemWidth > slider.w) ? slider.w : vars.itemWidth;
                                slider.visible = Math.floor(slider.w / (slider.itemW + slideMargin));
                                slider.move = (vars.move > 0 && vars.move < slider.visible) ? vars.move : slider.visible;
                                slider.pagingCount = Math.ceil(((slider.count - slider.visible) / slider.move) + 1);
                                slider.last = slider.pagingCount - 1;
                                slider.limit = (slider.pagingCount === 1) ? 0 : (vars.itemWidth > slider.w) ? ((slider.itemW + (slideMargin * 2)) * slider.count) - slider.w - slideMargin : ((slider.itemW + slideMargin) * slider.count) - slider.w - slideMargin;
                        } else {
                                slider.itemW = slider.w;
                                slider.pagingCount = slider.count;
                                slider.last = slider.count - 1;
                        }
                        slider.computedW = slider.itemW - slider.boxPadding;
                }

                slider.update = function (pos, action) {
                        slider.doMath();

                        // update currentSlide and slider.animatingTo if necessary
                        if (!carousel) {
                                if (pos < slider.currentSlide) {
                                        slider.currentSlide += 1;
                                } else if (pos <= slider.currentSlide && pos !== 0) {
                                        slider.currentSlide -= 1;
                                }
                                slider.animatingTo = slider.currentSlide;
                        }

                        // update controlNav
                        if (vars.controlNav && !slider.manualControls) {
                                if ((action === "add" && !carousel) || slider.pagingCount > slider.controlNav.length) {
                                        methods.controlNav.update("add");
                                } else if ((action === "remove" && !carousel) || slider.pagingCount < slider.controlNav.length) {
                                        if (carousel && slider.currentSlide > slider.last) {
                                                slider.currentSlide -= 1;
                                                slider.animatingTo -= 1;
                                        }
                                        methods.controlNav.update("remove", slider.last);
                                }
                        }
                        // update directionNav
                        if (vars.directionNav) methods.directionNav.update();

                }

                slider.addSlide = function (obj, pos) {
                        var $obj = $(obj);

                        slider.count += 1;
                        slider.last = slider.count - 1;

                        // append new slide
                        if (vertical && reverse) {
                                (pos !== undefined) ? slider.slides.eq(slider.count - pos).after($obj) : slider.container.prepend($obj);
                        } else {
                                (pos !== undefined) ? slider.slides.eq(pos).before($obj) : slider.container.append($obj);
                        }

                        // update currentSlide, animatingTo, controlNav, and directionNav
                        slider.update(pos, "add");

                        // update slider.slides
                        slider.slides = $(vars.selector + ':not(.clone)', slider);
                        // re-setup the slider to accomdate new slide
                        slider.setup();

                        //FlexSlider: added() Callback
                        vars.added(slider);
                }
                slider.removeSlide = function (obj) {
                        var pos = (isNaN(obj)) ? slider.slides.index($(obj)) : obj;

                        // update count
                        slider.count -= 1;
                        slider.last = slider.count - 1;

                        // remove slide
                        if (isNaN(obj)) {
                                $(obj, slider.slides).remove();
                        } else {
                                (vertical && reverse) ? slider.slides.eq(slider.last).remove() : slider.slides.eq(obj).remove();
                        }

                        // update currentSlide, animatingTo, controlNav, and directionNav
                        slider.doMath();
                        slider.update(pos, "remove");

                        // update slider.slides
                        slider.slides = $(vars.selector + ':not(.clone)', slider);
                        // re-setup the slider to accomdate new slide
                        slider.setup();

                        // FlexSlider: removed() Callback
                        vars.removed(slider);
                }

                //FlexSlider: Initialize
                methods.init();
        }

        //FlexSlider: Default Settings
        $.flexslider.defaults = {
                namespace: "flex-",
                //{NEW} String: Prefix string attached to the class of every element generated by the plugin
                selector: ".slides > li",
                //{NEW} Selector: Must match a simple pattern. '{container} > {slide}' -- Ignore pattern at your own peril
                animation: "fade",
                //String: Select your animation type, "fade" or "slide"
                easing: "swing",
                //{NEW} String: Determines the easing method used in jQuery transitions. jQuery easing plugin is supported!
                direction: "horizontal",
                //String: Select the sliding direction, "horizontal" or "vertical"
                reverse: false,
                //{NEW} Boolean: Reverse the animation direction
                animationLoop: true,
                //Boolean: Should the animation loop? If false, directionNav will received "disable" classes at either end
                smoothHeight: false,
                //{NEW} Boolean: Allow height of the slider to animate smoothly in horizontal mode  
                startAt: 0,
                //Integer: The slide that the slider should start on. Array notation (0 = first slide)
                slideshow: true,
                //Boolean: Animate slider automatically
                slideshowSpeed: 7000,
                //Integer: Set the speed of the slideshow cycling, in milliseconds
                animationSpeed: 600,
                //Integer: Set the speed of animations, in milliseconds
                initDelay: 0,
                //{NEW} Integer: Set an initialization delay, in milliseconds
                randomize: false,
                //Boolean: Randomize slide order
                // Usability features
                pauseOnAction: true,
                //Boolean: Pause the slideshow when interacting with control elements, highly recommended.
                pauseOnHover: false,
                //Boolean: Pause the slideshow when hovering over slider, then resume when no longer hovering
                useCSS: true,
                //{NEW} Boolean: Slider will use CSS3 transitions if available
                touch: true,
                //{NEW} Boolean: Allow touch swipe navigation of the slider on touch-enabled devices
                video: false,
                //{NEW} Boolean: If using video in the slider, will prevent CSS3 3D Transforms to avoid graphical glitches
                // Primary Controls
                controlNav: true,
                //Boolean: Create navigation for paging control of each clide? Note: Leave true for manualControls usage
                directionNav: true,
                //Boolean: Create navigation for previous/next navigation? (true/false)
                prevText: "Previous",
                //String: Set the text for the "previous" directionNav item
                nextText: "Next",
                //String: Set the text for the "next" directionNav item
                directionNavArrowsLeft: '<i class="mk-icon-chevron-left"></i>',
                directionNavArrowsRight: '<i class="mk-icon-chevron-right"></i>',

                // Secondary Navigation
                keyboard: true,
                //Boolean: Allow slider navigating via keyboard left/right keys
                multipleKeyboard: false,
                //{NEW} Boolean: Allow keyboard navigation to affect multiple sliders. Default behavior cuts out keyboard navigation with more than one slider present.
                mousewheel: false,
                //{UPDATED} Boolean: Requires jquery.mousewheel.js (https://github.com/brandonaaron/jquery-mousewheel) - Allows slider navigating via mousewheel
                pausePlay: false,
                //Boolean: Create pause/play dynamic element
                pauseText: "Pause",
                //String: Set the text for the "pause" pausePlay item
                playText: "Play",
                //String: Set the text for the "play" pausePlay item
                // Special properties
                controlsContainer: "",
                //{UPDATED} jQuery Object/Selector: Declare which container the navigation elements should be appended too. Default container is the FlexSlider element. Example use would be $(".flexslider-container"). Property is ignored if given element is not found.
                manualControls: "",
                //{UPDATED} jQuery Object/Selector: Declare custom control navigation. Examples would be $(".flex-control-nav li") or "#tabs-nav li img", etc. The number of elements in your controlNav should match the number of slides/tabs.
                sync: "",
                //{NEW} Selector: Mirror the actions performed on this slider with another slider. Use with care.
                asNavFor: "",
                //{NEW} Selector: Internal property exposed for turning the slider into a thumbnail navigation for another slider
                // Carousel Options
                itemWidth: 0,
                //{NEW} Integer: Box-model width of individual carousel items, including horizontal borders and padding.
                itemMargin: 0,
                //{NEW} Integer: Margin between carousel items.
                minItems: 0,
                //{NEW} Integer: Minimum number of carousel items that should be visible. Items will resize fluidly when below this.
                maxItems: 0,
                //{NEW} Integer: Maxmimum number of carousel items that should be visible. Items will resize fluidly when above this limit.
                move: 0,
                //{NEW} Integer: Number of carousel items that should move on animation. If 0, slider will move all visible items.
                // Callback API
                start: function () {},
                //Callback: function(slider) - Fires when the slider loads the first slide
                before: function () {},
                //Callback: function(slider) - Fires asynchronously with each slider animation
                after: function () {},
                //Callback: function(slider) - Fires after each slider animation completes
                end: function () {},
                //Callback: function(slider) - Fires when the slider reaches the last slide (asynchronous)
                added: function () {},
                //{NEW} Callback: function(slider) - Fires after a slide is added
                removed: function () {} //{NEW} Callback: function(slider) - Fires after a slide is removed
        }


        //FlexSlider: Plugin Function
        $.fn.flexslider = function (options) {
                if (options === undefined) options = {};

                if (typeof options === "object") {
                        return this.each(function () {
                                var $this = $(this),
                                        selector = (options.selector) ? options.selector : ".slides > li",
                                        $slides = $this.find(selector);

                                if ($slides.length === 1) {
                                        $slides.fadeIn(400);
                                        if (options.start) options.start($this);
                                } else if ($this.data('flexslider') === undefined) {
                                        new $.flexslider(this, options);
                                }
                        });
                } else {
                        // Helper strings to quickly perform functions on the slider
                        var $slider = $(this).data('flexslider');
                        switch (options) {
                        case "play":
                                $slider.play();
                                break;
                        case "pause":
                                $slider.pause();
                                break;
                        case "next":
                                $slider.flexAnimate($slider.getTarget("next"), true);
                                break;
                        case "prev":
                        case "previous":
                                $slider.flexAnimate($slider.getTarget("prev"), true);
                                break;
                        default:
                                if (typeof options === "number") $slider.flexAnimate(options, true);
                        }
                }
        }

})(jQuery);

























/*!
 * jQuery Cookiebar Plugin
 * https://github.com/carlwoodhouse/jquery.cookieBar
 *
 * Copyright 2012, Carl Woodhouse
 * Disclaimer: if you still get fined for not complying with the eu cookielaw, it's not our fault.
 */

(function ($) {
        $.fn.cookieBar = function (options) {
                var settings = $.extend({
                        'closeButton': 'none',
                        'secure': false,
                        'cookieName': 'jupiter_notification_bar',
                        'path': '/',
                        'domain': ''
                }, options);

                return this.each(function () {
                        var cookiebar = $(this);

                        // just in case they didnt hide it by default.
                        cookiebar.hide();

                        // if close button not defined. define it!
                        if (settings.closeButton == 'none') {
                                cookiebar.append('<a class="cookiebar-close">Continue</a>');
                                settings = $.extend({
                                        'closeButton': '.cookiebar-close'
                                }, options);
                        }

                        if ($.cookie(settings.cookieName) != 'hide') {
                                cookiebar.show();
                        }

                        cookiebar.find(settings.closeButton).click(function () {
                                cookiebar.hide();
                                $.cookie(settings.cookieName, 'hide', {
                                        path: settings.path,
                                        secure: settings.secure,
                                        domain: settings.domain,
                                        expires: 30
                                });
                                return false;
                        });
                });
        };

        // self injection init
        $.cookieBar = function (options) {

                $('.cookie-message').cookieBar(options);
        };
})(jQuery);

























/*!
 * Dependancy:
 * jQuery Cookie Plugin
 * https://github.com/carhartl/jquery-cookie
 *
 * Copyright 2011, Klaus Hartl
 * Dual licensed under the MIT or GPL Version 2 licenses.
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.opensource.org/licenses/GPL-2.0
 */
(function ($) {
        $.cookie = function (key, value, options) {
                // key and at least value given, set cookie...
                if (arguments.length > 1 && (!/Object/.test(Object.prototype.toString.call(value)) || value === null || value === undefined)) {
                        options = $.extend({}, options);

                        if (value === null || value === undefined) {
                                options.expires = -1;
                        }

                        if (typeof options.expires === 'number') {
                                var days = options.expires,
                                        t = options.expires = new Date();
                                t.setDate(t.getDate() + days);
                        }

                        value = String(value);

                        return (document.cookie = [
                        encodeURIComponent(key), '=', options.raw ? value : encodeURIComponent(value), options.expires ? '; expires=' + options.expires.toUTCString() : '', // use expires attribute, max-age is not supported by IE
                        options.path ? '; path=' + options.path : '', options.domain ? '; domain=' + options.domain : '', options.secure ? '; secure' : ''].join(''));
                }

                // key and possibly options given, get cookie...
                options = value || {};
                var decode = options.raw ?
                function (s) {
                        return s;
                } : decodeURIComponent;

                var pairs = document.cookie.split('; ');
                for (var i = 0, pair; pair = pairs[i] && pairs[i].split('='); i++) {
                        // IE saves cookies with empty string as "c; ", e.g. without "=" as opposed to EOMB, thus pair[1] may be undefined
                        if (decode(pair[0]) === key) return decode(pair[1] || '');
                }
                return null;
        };
})(jQuery);

























// Generated by CoffeeScript 1.4.0
/*
Easy pie chart is a jquery plugin to display simple animated pie charts for only one value

Dual licensed under the MIT (http://www.opensource.org/licenses/mit-license.php)
and GPL (http://www.opensource.org/licenses/gpl-license.php) licenses.

Built on top of the jQuery library (http://jquery.com)

@source: http://github.com/rendro/easy-pie-chart/
@autor: Robert Fleischmann
@version: 1.1.0

Inspired by: http://dribbble.com/shots/631074-Simple-Pie-Charts-II?list=popular&offset=210
Thanks to Philip Thrasher for the jquery plugin boilerplate for coffee script
*/

(function ($) {
        $.easyPieChart = function (el, options) {
                var addScaleLine, animateLine, drawLine, easeInOutQuad, rAF, renderBackground, renderScale, renderTrack, _this = this;
                this.el = el;
                this.$el = $(el);
                this.$el.data("easyPieChart", this);
                this.init = function () {
                        var percent, scaleBy;
                        _this.options = $.extend({}, $.easyPieChart.defaultOptions, options);
                        percent = parseInt(_this.$el.data('percent'), 10);
                        _this.percentage = 0;
                        _this.canvas = $("<canvas width='" + _this.options.size + "' height='" + _this.options.size + "'></canvas>").get(0);
                        _this.$el.append(_this.canvas);
                        if (typeof G_vmlCanvasManager !== "undefined" && G_vmlCanvasManager !== null) {
                                G_vmlCanvasManager.initElement(_this.canvas);
                        }
                        _this.ctx = _this.canvas.getContext('2d');
                        if (window.devicePixelRatio > 1) {
                                scaleBy = window.devicePixelRatio;
                                $(_this.canvas).css({
                                        width: _this.options.size,
                                        height: _this.options.size
                                });
                                _this.canvas.width *= scaleBy;
                                _this.canvas.height *= scaleBy;
                                _this.ctx.scale(scaleBy, scaleBy);
                        }
                        _this.ctx.translate(_this.options.size / 2, _this.options.size / 2);
                        _this.$el.addClass('easyPieChart');
                        _this.$el.css({
                                width: _this.options.size,
                                height: _this.options.size,
                                lineHeight: "" + _this.options.size + "px"
                        });
                        _this.update(percent);
                        return _this;
                };
                this.update = function (percent) {
                        percent = parseFloat(percent) || 0;
                        if (_this.options.animate === false) {
                                drawLine(percent);
                        } else {
                                animateLine(_this.percentage, percent);
                        }
                        return _this;
                };
                renderScale = function () {
                        var i, _i, _results;
                        _this.ctx.fillStyle = _this.options.scaleColor;
                        _this.ctx.lineWidth = 1;
                        _results = [];
                        for (i = _i = 0; _i <= 24; i = ++_i) {
                                _results.push(addScaleLine(i));
                        }
                        return _results;
                };
                addScaleLine = function (i) {
                        var offset;
                        offset = i % 6 === 0 ? 0 : _this.options.size * 0.017;
                        _this.ctx.save();
                        _this.ctx.rotate(i * Math.PI / 12);
                        _this.ctx.fillRect(_this.options.size / 2 - offset, 0, -_this.options.size * 0.05 + offset, 1);
                        _this.ctx.restore();
                };
                renderTrack = function () {
                        var offset;
                        offset = _this.options.size / 2 - _this.options.lineWidth / 2;
                        if (_this.options.scaleColor !== false) {
                                offset -= _this.options.size * 0.08;
                        }
                        _this.ctx.beginPath();
                        _this.ctx.arc(0, 0, offset, 0, Math.PI * 2, true);
                        _this.ctx.closePath();
                        _this.ctx.strokeStyle = _this.options.trackColor;
                        _this.ctx.lineWidth = _this.options.lineWidth;
                        _this.ctx.stroke();
                };
                renderBackground = function () {
                        if (_this.options.scaleColor !== false) {
                                renderScale();
                        }
                        if (_this.options.trackColor !== false) {
                                renderTrack();
                        }
                };
                drawLine = function (percent) {
                        var offset;
                        renderBackground();
                        _this.ctx.strokeStyle = $.isFunction(_this.options.barColor) ? _this.options.barColor(percent) : _this.options.barColor;
                        _this.ctx.lineCap = _this.options.lineCap;
                        _this.ctx.lineWidth = _this.options.lineWidth;
                        offset = _this.options.size / 2 - _this.options.lineWidth / 2;
                        if (_this.options.scaleColor !== false) {
                                offset -= _this.options.size * 0.08;
                        }
                        _this.ctx.save();
                        _this.ctx.rotate(-Math.PI / 2);
                        _this.ctx.beginPath();
                        _this.ctx.arc(0, 0, offset, 0, Math.PI * 2 * percent / 100, false);
                        _this.ctx.stroke();
                        _this.ctx.restore();
                };
                rAF = (function () {
                        return window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame ||
                        function (callback) {
                                return window.setTimeout(callback, 1000 / 60);
                        };
                })();
                animateLine = function (from, to) {
                        var anim, startTime;
                        _this.options.onStart.call(_this);
                        _this.percentage = to;
                        startTime = Date.now();
                        anim = function () {
                                var currentValue, process;
                                process = Date.now() - startTime;
                                if (process < _this.options.animate) {
                                        rAF(anim);
                                }
                                _this.ctx.clearRect(-_this.options.size / 2, -_this.options.size / 2, _this.options.size, _this.options.size);
                                renderBackground.call(_this);
                                currentValue = [easeInOutQuad(process, from, to - from, _this.options.animate)];
                                _this.options.onStep.call(_this, currentValue);
                                drawLine.call(_this, currentValue);
                                if (process >= _this.options.animate) {
                                        return _this.options.onStop.call(_this);
                                }
                        };
                        rAF(anim);
                };
                easeInOutQuad = function (t, b, c, d) {
                        var easeIn, easing;
                        easeIn = function (t) {
                                return Math.pow(t, 2);
                        };
                        easing = function (t) {
                                if (t < 1) {
                                        return easeIn(t);
                                } else {
                                        return 2 - easeIn((t / 2) * -2 + 2);
                                }
                        };
                        t /= d / 2;
                        return c / 2 * easing(t) + b;
                };
                return this.init();
        };
        $.easyPieChart.defaultOptions = {
                barColor: '#ef1e25',
                trackColor: '#f2f2f2',
                scaleColor: '#dfe0e0',
                lineCap: 'round',
                size: 110,
                lineWidth: 3,
                animate: false,
                onStart: $.noop,
                onStop: $.noop,
                onStep: $.noop
        };
        $.fn.easyPieChart = function (options) {
                return $.each(this, function (i, el) {
                        var $el;
                        $el = $(el);
                        if (!$el.data('easyPieChart')) {
                                return $el.data('easyPieChart', new $.easyPieChart(el, options));
                        }
                });
        };
        return void 0;
})(jQuery);

























/* Copyright 2012, Ben Lin (http://dreamerslab.com/)
 * Licensed under the MIT License (LICENSE.txt).
 *
 * Version: 1.0.15
 *
 * Requires: jQuery >= 1.2.3
 */
(function (a) {
        a.fn.addBack = a.fn.addBack || a.fn.andSelf;
        a.fn.extend({
                actual: function (b, l) {
                        if (!this[b]) {
                                throw '$.actual => The jQuery method "' + b + '" you called does not exist';
                        }
                        var f = {
                                absolute: false,
                                clone: false,
                                includeMargin: false
                        };
                        var i = a.extend(f, l);
                        var e = this.eq(0);
                        var h, j;
                        if (i.clone === true) {
                                h = function () {
                                        var m = "position: absolute !important; top: -1000 !important; ";
                                        e = e.clone().attr("style", m).appendTo("body")
                                };
                                j = function () {
                                        e.remove()
                                }
                        } else {
                                var g = [];
                                var d = "";
                                var c;
                                h = function () {
                                        c = e.parents().addBack().filter(":hidden");
                                        d += "visibility: hidden !important; display: block !important; ";
                                        if (i.absolute === true) {
                                                d += "position: absolute !important; "
                                        }
                                        c.each(function () {
                                                var m = a(this);
                                                g.push(m.attr("style"));
                                                m.attr("style", d)
                                        })
                                };
                                j = function () {
                                        c.each(function (m) {
                                                var o = a(this);
                                                var n = g[m];
                                                if (n === undefined) {
                                                        o.removeAttr("style")
                                                } else {
                                                        o.attr("style", n)
                                                }
                                        })
                                }
                        }
                        h();
                        var k = /(outer)/.test(b) ? e[b](i.includeMargin) : e[b]();
                        j();
                        return k
                }
        })
})(jQuery);



























/*! waitForImages jQuery Plugin - v1.5.0 - 2013-07-20
 * https://github.com/alexanderdickson/waitForImages
 * Copyright (c) 2013 Alex Dickson; Licensed MIT */
(function ($) {
        var o = 'waitForImages';
        $.waitForImages = {
                hasImageProperties: ['backgroundImage', 'listStyleImage', 'borderImage', 'borderCornerImage', 'cursor']
        };
        $.expr[':'].uncached = function (a) {
                if (!$(a).is('img[src!=""]')) {
                        return false
                }
                var b = new Image();
                b.src = a.src;
                return !b.complete
        };
        $.fn.waitForImages = function (j, k, l) {
                var m = 0;
                var n = 0;
                if ($.isPlainObject(arguments[0])) {
                        l = arguments[0].waitForAll;
                        k = arguments[0].each;
                        j = arguments[0].finished
                }
                j = j || $.noop;
                k = k || $.noop;
                l = !! l;
                if (!$.isFunction(j) || !$.isFunction(k)) {
                        throw new TypeError('An invalid callback was supplied.');
                }
                return this.each(function () {
                        var e = $(this);
                        var f = [];
                        var g = $.waitForImages.hasImageProperties || [];
                        var h = /url\(\s*(['"]?)(.*?)\1\s*\)/g;
                        if (l) {
                                e.find('*').addBack().each(function () {
                                        var d = $(this);
                                        if (d.is('img:uncached')) {
                                                f.push({
                                                        src: d.attr('src'),
                                                        element: d[0]
                                                })
                                        }
                                        $.each(g, function (i, a) {
                                                var b = d.css(a);
                                                var c;
                                                if (!b) {
                                                        return true
                                                }
                                                while (c = h.exec(b)) {
                                                        f.push({
                                                                src: c[2],
                                                                element: d[0]
                                                        })
                                                }
                                        })
                                })
                        } else {
                                e.find('img:uncached').each(function () {
                                        f.push({
                                                src: this.src,
                                                element: this
                                        })
                                })
                        }
                        m = f.length;
                        n = 0;
                        if (m === 0) {
                                j.call(e[0])
                        }
                        $.each(f, function (i, b) {
                                var c = new Image();
                                $(c).on('load.' + o + ' error.' + o, function (a) {
                                        n++;
                                        k.call(b.element, n, m, a.type == 'load');
                                        if (n == m) {
                                                j.call(e[0]);
                                                return false
                                        }
                                });
                                c.src = b.src
                        })
                })
        }
}(jQuery));



























/*
 * Swiper 2.4+ - Mobile Touch Slider
 * http://www.idangero.us/sliders/swiper/
 *
 * Copyright 2012-2013, Vladimir Kharlampidi
 * The iDangero.us
 * http://www.idangero.us/
 *
 * Licensed under GPL & MIT
 *
 * Updated on: December 6, 2013
 */
var Swiper = function (selector, params) {
/*=========================
      A little bit dirty but required part for IE8 and old FF support
      ===========================*/
                if (document.body.__defineGetter__) {
                        if (HTMLElement) {
                                var element = HTMLElement.prototype;
                                if (element.__defineGetter__) {
                                        element.__defineGetter__("outerHTML", function () {
                                                return new XMLSerializer().serializeToString(this);
                                        });
                                }
                        }
                }

                if (!window.getComputedStyle) {
                        window.getComputedStyle = function (el, pseudo) {
                                this.el = el;
                                this.getPropertyValue = function (prop) {
                                        var re = /(\-([a-z]){1})/g;
                                        if (prop === 'float') prop = 'styleFloat';
                                        if (re.test(prop)) {
                                                prop = prop.replace(re, function () {
                                                        return arguments[2].toUpperCase();
                                                });
                                        }
                                        return el.currentStyle[prop] ? el.currentStyle[prop] : null;
                                }
                                return this;
                        }
                }
                if (!Array.prototype.indexOf) {
                        Array.prototype.indexOf = function (obj, start) {
                                for (var i = (start || 0), j = this.length; i < j; i++) {
                                        if (this[i] === obj) {
                                                return i;
                                        }
                                }
                                return -1;
                        }
                }
                if (!document.querySelectorAll) {
                        if (!window.jQuery) return;
                }

                function $$(selector, context) {
                        if (document.querySelectorAll) return (context || document).querySelectorAll(selector);
                        else return jQuery(selector, context);
                }

/*=========================
      Check for correct selector
      ===========================*/
                if (typeof selector === 'undefined') return;

                if (!(selector.nodeType)) {
                        if ($$(selector).length === 0) return;
                }

/*=========================
      _this
      ===========================*/
                var _this = this;

/*=========================
      Default Flags and vars
      ===========================*/
                _this.touches = {
                        start: 0,
                        startX: 0,
                        startY: 0,
                        current: 0,
                        currentX: 0,
                        currentY: 0,
                        diff: 0,
                        abs: 0
                };
                _this.positions = {
                        start: 0,
                        abs: 0,
                        diff: 0,
                        current: 0
                };
                _this.times = {
                        start: 0,
                        end: 0
                };

                _this.id = (new Date()).getTime();
                _this.container = (selector.nodeType) ? selector : $$(selector)[0];
                _this.isTouched = false;
                _this.isMoved = false;
                _this.activeIndex = 0;
                _this.centerIndex = 0;
                _this.activeLoaderIndex = 0;
                _this.activeLoopIndex = 0;
                _this.previousIndex = null;
                _this.velocity = 0;
                _this.snapGrid = [];
                _this.slidesGrid = [];
                _this.imagesToLoad = [];
                _this.imagesLoaded = 0;
                _this.wrapperLeft = 0;
                _this.wrapperRight = 0;
                _this.wrapperTop = 0;
                _this.wrapperBottom = 0;
                var wrapper, slideSize, wrapperSize, direction, isScrolling, containerSize;

/*=========================
      Default Parameters
      ===========================*/
                var defaults = {
                        mode: 'horizontal',
                        // or 'vertical'
                        touchRatio: 1,
                        speed: 300,
                        freeMode: false,
                        freeModeFluid: false,
                        momentumRatio: 1,
                        momentumBounce: true,
                        momentumBounceRatio: 1,
                        slidesPerView: 1,
                        slidesPerGroup: 1,
                        simulateTouch: true,
                        followFinger: true,
                        shortSwipes: true,
                        moveStartThreshold: false,
                        onlyExternal: false,
                        createPagination: true,
                        pagination: false,
                        paginationElement: 'span',
                        paginationClickable: false,
                        paginationAsRange: true,
                        resistance: true,
                        // or false or 100%
                        scrollContainer: false,
                        preventLinks: true,
                        noSwiping: false,
                        // or class
                        noSwipingClass: 'swiper-no-swiping',
                        //:)
                        initialSlide: 0,
                        keyboardControl: false,
                        mousewheelControl: false,
                        useCSS3Transforms: true,
                        // Autoplay
                        autoplay: false,
                        autoplayDisableOnInteraction: true,
                        //Loop mode
                        loop: false,
                        loopAdditionalSlides: 0,
                        //Auto Height
                        calculateHeight: false,
                        cssWidthAndHeight: false,
                        //Images Preloader
                        updateOnImagesReady: true,
                        //Form elements
                        releaseFormElements: true,
                        //Watch for active slide, useful when use effects on different slide states
                        watchActiveIndex: false,
                        //Slides Visibility Fit
                        visibilityFullFit: false,
                        //Slides Offset
                        offsetPxBefore: 0,
                        offsetPxAfter: 0,
                        offsetSlidesBefore: 0,
                        offsetSlidesAfter: 0,
                        centeredSlides: false,
                        //Queue callbacks
                        queueStartCallbacks: false,
                        queueEndCallbacks: false,
                        //Auto Resize
                        autoResize: true,
                        resizeReInit: false,
                        //DOMAnimation
                        DOMAnimation: true,
                        //Slides Loader
                        loader: {
                                slides: [],
                                //array with slides
                                slidesHTMLType: 'inner',
                                // or 'outer'
                                surroundGroups: 1,
                                //keep preloaded slides groups around view
                                logic: 'reload',
                                //or 'change'
                                loadAllSlides: false
                        },
                        //Namespace
                        slideElement: 'div',
                        slideClass: 'swiper-slide',
                        slideActiveClass: 'swiper-slide-active',
                        slideVisibleClass: 'swiper-slide-visible',
                        wrapperClass: 'swiper-wrapper',
                        paginationElementClass: 'swiper-pagination-switch',
                        paginationActiveClass: 'swiper-active-switch',
                        paginationVisibleClass: 'swiper-visible-switch'
                }
                params = params || {};
                for (var prop in defaults) {
                        if (prop in params && typeof params[prop] === 'object') {
                                for (var subProp in defaults[prop]) {
                                        if (!(subProp in params[prop])) {
                                                params[prop][subProp] = defaults[prop][subProp];
                                        }
                                }
                        } else if (!(prop in params)) {
                                params[prop] = defaults[prop]
                        }
                }
                _this.params = params;
                if (params.scrollContainer) {
                        params.freeMode = true;
                        params.freeModeFluid = true;
                }
                if (params.loop) {
                        params.resistance = '100%';
                }
                var isH = params.mode === 'horizontal';

/*=========================
      Define Touch Events
      ===========================*/

                _this.touchEvents = {
                        touchStart: _this.support.touch || !params.simulateTouch ? 'touchstart' : (_this.browser.ie10 ? 'MSPointerDown' : 'mousedown'),
                        touchMove: _this.support.touch || !params.simulateTouch ? 'touchmove' : (_this.browser.ie10 ? 'MSPointerMove' : 'mousemove'),
                        touchEnd: _this.support.touch || !params.simulateTouch ? 'touchend' : (_this.browser.ie10 ? 'MSPointerUp' : 'mouseup')
                };

/*=========================
      Wrapper
      ===========================*/
                for (var i = _this.container.childNodes.length - 1; i >= 0; i--) {
                        if (_this.container.childNodes[i].className) {
                                var _wrapperClasses = _this.container.childNodes[i].className.split(' ')
                                for (var j = 0; j < _wrapperClasses.length; j++) {
                                        if (_wrapperClasses[j] === params.wrapperClass) {
                                                wrapper = _this.container.childNodes[i];
                                        }
                                };
                        }
                };

                _this.wrapper = wrapper;
/*=========================
      Slide API
      ===========================*/
                _this._extendSwiperSlide = function (el) {
                        el.append = function () {
                                if (params.loop) {
                                        el.insertAfter(_this.slides.length - _this.loopedSlides);
                                        _this.removeLoopedSlides();
                                        _this.calcSlides();
                                        _this.createLoop();
                                } else {
                                        _this.wrapper.appendChild(el);
                                }

                                _this.reInit();
                                return el;
                        }
                        el.prepend = function () {
                                if (params.loop) {
                                        _this.wrapper.insertBefore(el, _this.slides[_this.loopedSlides]);
                                        _this.removeLoopedSlides();
                                        _this.calcSlides();
                                        _this.createLoop();
                                } else {
                                        _this.wrapper.insertBefore(el, _this.wrapper.firstChild);
                                }
                                _this.reInit();
                                return el;
                        }
                        el.insertAfter = function (index) {
                                if (typeof index === 'undefined') return false;
                                var beforeSlide;

                                if (params.loop) {
                                        beforeSlide = _this.slides[index + 1 + _this.loopedSlides];
                                        _this.wrapper.insertBefore(el, beforeSlide);
                                        _this.removeLoopedSlides();
                                        _this.calcSlides();
                                        _this.createLoop();
                                } else {
                                        beforeSlide = _this.slides[index + 1];
                                        _this.wrapper.insertBefore(el, beforeSlide)
                                }
                                _this.reInit();
                                return el;
                        }
                        el.clone = function () {
                                return _this._extendSwiperSlide(el.cloneNode(true))
                        }
                        el.remove = function () {
                                _this.wrapper.removeChild(el);
                                _this.reInit();
                        }
                        el.html = function (html) {
                                if (typeof html === 'undefined') {
                                        return el.innerHTML;
                                } else {
                                        el.innerHTML = html;
                                        return el;
                                }
                        }
                        el.index = function () {
                                var index;
                                for (var i = _this.slides.length - 1; i >= 0; i--) {
                                        if (el === _this.slides[i]) index = i;
                                }
                                return index;
                        }
                        el.isActive = function () {
                                if (el.index() === _this.activeIndex) return true;
                                else return false;
                        }
                        if (!el.swiperSlideDataStorage) el.swiperSlideDataStorage = {};
                        el.getData = function (name) {
                                return el.swiperSlideDataStorage[name];
                        }
                        el.setData = function (name, value) {
                                el.swiperSlideDataStorage[name] = value;
                                return el;
                        }
                        el.data = function (name, value) {
                                if (!value) {
                                        return el.getAttribute('data-' + name);
                                } else {
                                        el.setAttribute('data-' + name, value);
                                        return el;
                                }
                        }
                        el.getWidth = function (outer) {
                                return _this.h.getWidth(el, outer);
                        }
                        el.getHeight = function (outer) {
                                return _this.h.getHeight(el, outer);
                        }
                        el.getOffset = function () {
                                return _this.h.getOffset(el);
                        }
                        return el;
                }

                //Calculate information about number of slides
                _this.calcSlides = function (forceCalcSlides) {
                        var oldNumber = _this.slides ? _this.slides.length : false;
                        _this.slides = [];
                        _this.displaySlides = [];
                        for (var i = 0; i < _this.wrapper.childNodes.length; i++) {
                                if (_this.wrapper.childNodes[i].className) {
                                        var _className = _this.wrapper.childNodes[i].className;
                                        var _slideClasses = _className.split(' ');
                                        for (var j = 0; j < _slideClasses.length; j++) {
                                                if (_slideClasses[j] === params.slideClass) {
                                                        _this.slides.push(_this.wrapper.childNodes[i]);
                                                }
                                        }
                                }
                        }
                        for (i = _this.slides.length - 1; i >= 0; i--) {
                                _this._extendSwiperSlide(_this.slides[i]);
                        }
                        if (oldNumber === false) return;
                        if (oldNumber !== _this.slides.length || forceCalcSlides) {
                                // Number of slides has been changed
                                removeSlideEvents();
                                addSlideEvents();
                                _this.updateActiveSlide();
                                if (_this.params.pagination) _this.createPagination();
                                _this.callPlugins('numberOfSlidesChanged');
                        }
                }

                //Create Slide
                _this.createSlide = function (html, slideClassList, el) {
                        var slideClassList = slideClassList || _this.params.slideClass;
                        var el = el || params.slideElement;
                        var newSlide = document.createElement(el);
                        newSlide.innerHTML = html || '';
                        newSlide.className = slideClassList;
                        return _this._extendSwiperSlide(newSlide);
                }

                //Append Slide
                _this.appendSlide = function (html, slideClassList, el) {
                        if (!html) return;
                        if (html.nodeType) {
                                return _this._extendSwiperSlide(html).append()
                        } else {
                                return _this.createSlide(html, slideClassList, el).append()
                        }
                }
                _this.prependSlide = function (html, slideClassList, el) {
                        if (!html) return;
                        if (html.nodeType) {
                                return _this._extendSwiperSlide(html).prepend()
                        } else {
                                return _this.createSlide(html, slideClassList, el).prepend()
                        }
                }
                _this.insertSlideAfter = function (index, html, slideClassList, el) {
                        if (typeof index === 'undefined') return false;
                        if (html.nodeType) {
                                return _this._extendSwiperSlide(html).insertAfter(index);
                        } else {
                                return _this.createSlide(html, slideClassList, el).insertAfter(index);
                        }
                }
                _this.removeSlide = function (index) {
                        if (_this.slides[index]) {
                                if (params.loop) {
                                        if (!_this.slides[index + _this.loopedSlides]) return false;
                                        _this.slides[index + _this.loopedSlides].remove();
                                        _this.removeLoopedSlides();
                                        _this.calcSlides();
                                        _this.createLoop();
                                } else _this.slides[index].remove();
                                return true;
                        } else return false;
                }
                _this.removeLastSlide = function () {
                        if (_this.slides.length > 0) {
                                if (params.loop) {
                                        _this.slides[_this.slides.length - 1 - _this.loopedSlides].remove();
                                        _this.removeLoopedSlides();
                                        _this.calcSlides();
                                        _this.createLoop();
                                } else _this.slides[(_this.slides.length - 1)].remove();
                                return true;
                        } else {
                                return false;
                        }
                }
                _this.removeAllSlides = function () {
                        for (var i = _this.slides.length - 1; i >= 0; i--) {
                                _this.slides[i].remove()
                        }
                }
                _this.getSlide = function (index) {
                        return _this.slides[index]
                }
                _this.getLastSlide = function () {
                        return _this.slides[_this.slides.length - 1]
                }
                _this.getFirstSlide = function () {
                        return _this.slides[0]
                }

                //Currently Active Slide
                _this.activeSlide = function () {
                        return _this.slides[_this.activeIndex]
                }

/*=========================
      Plugins API
      ===========================*/
                var _plugins = [];
                for (var plugin in _this.plugins) {
                        if (params[plugin]) {
                                var p = _this.plugins[plugin](_this, params[plugin]);
                                if (p) _plugins.push(p);
                        }
                }
                _this.callPlugins = function (method, args) {
                        if (!args) args = {}
                        for (var i = 0; i < _plugins.length; i++) {
                                if (method in _plugins[i]) {
                                        _plugins[i][method](args);
                                }
                        }
                }

/*=========================
     Wrapper for Callbacks : Allows additive callbacks via function arrays
     ===========================*/
                _this.fireCallback = function () {
                        var callback = arguments[0];
                        if (Object.prototype.toString.call(callback) === '[object Array]') {
                                for (var i = 0; i < callback.length; i++) {
                                        if (typeof callback[i] === 'function') {
                                                callback[i](arguments[1], arguments[2], arguments[3], arguments[4], arguments[5])
                                        }
                                }
                        } else {
                                callback(arguments[1], arguments[2], arguments[3], arguments[4], arguments[5]);
                        }
                }

                function isArray(obj) {
                        "use strict";
                        if (Object.prototype.toString.apply(obj) === '[object Array]') return true;
                        return false;
                }

                /**
                 * Allows user to add callbacks, rather than replace them
                 * @param callback
                 * @param func
                 * @return {*}
                 */
                _this.addCallback = function (callback, func) {
                        "use strict";
                        var _this = this,
                                tempFunc;
                        if (_this.params['on' + callback]) {
                                if (isArray(this.params['on' + callback])) {
                                        return this.params['on' + callback].push(func);
                                } else if (typeof this.params['on' + callback] === 'function') {
                                        tempFunc = this.params['on' + callback];
                                        this.params['on' + callback] = [];
                                        this.params['on' + callback].push(tempFunc);
                                        return this.params['on' + callback].push(func);
                                }
                        } else {
                                this.params['on' + callback] = [];
                                return this.params['on' + callback].push(func);
                        }
                }
                _this.removeCallbacks = function (callback) {
                        if (_this.params['on' + callback]) {
                                return _this.params['on' + callback] = null;
                        }
                }

/*=========================
      WP8 Fix
      ===========================*/
                if (_this.browser.ie10 && !params.onlyExternal) {
                        _this.wrapper.classList.add('swiper-wp8-' + (isH ? 'horizontal' : 'vertical'));
                }

/*=========================
      Free Mode Class
      ===========================*/
                if (params.freeMode) {
                        _this.container.className += ' swiper-free-mode';
                }

/*==================================================
        Init/Re-init/Resize Fix
    ====================================================*/
                _this.initialized = false;
                _this.init = function (force, forceCalcSlides) {
                        var _width = _this.h.getWidth(_this.container);
                        var _height = _this.h.getHeight(_this.container);
                        if (_width === _this.width && _height === _this.height && !force) return;
                        _this.width = _width;
                        _this.height = _height;

                        containerSize = isH ? _width : _height;
                        var wrapper = _this.wrapper;

                        if (force) {
                                _this.calcSlides(forceCalcSlides);
                        }

                        if (params.slidesPerView === 'auto') {
                                //Auto mode
                                var slidesWidth = 0;
                                var slidesHeight = 0;

                                //Unset Styles
                                if (params.slidesOffset > 0) {
                                        wrapper.style.paddingLeft = '';
                                        wrapper.style.paddingRight = '';
                                        wrapper.style.paddingTop = '';
                                        wrapper.style.paddingBottom = '';
                                }
                                wrapper.style.width = '';
                                wrapper.style.height = '';
                                if (params.offsetPxBefore > 0) {
                                        if (isH) _this.wrapperLeft = params.offsetPxBefore;
                                        else _this.wrapperTop = params.offsetPxBefore;
                                }
                                if (params.offsetPxAfter > 0) {
                                        if (isH) _this.wrapperRight = params.offsetPxAfter;
                                        else _this.wrapperBottom = params.offsetPxAfter;
                                }

                                if (params.centeredSlides) {
                                        if (isH) {
                                                _this.wrapperLeft = (containerSize - this.slides[0].getWidth(true)) / 2;
                                                _this.wrapperRight = (containerSize - _this.slides[_this.slides.length - 1].getWidth(true)) / 2;
                                        } else {
                                                _this.wrapperTop = (containerSize - _this.slides[0].getHeight(true)) / 2;
                                                _this.wrapperBottom = (containerSize - _this.slides[_this.slides.length - 1].getHeight(true)) / 2;
                                        }
                                }

                                if (isH) {
                                        if (_this.wrapperLeft >= 0) wrapper.style.paddingLeft = _this.wrapperLeft + 'px';
                                        if (_this.wrapperRight >= 0) wrapper.style.paddingRight = _this.wrapperRight + 'px';
                                } else {
                                        if (_this.wrapperTop >= 0) wrapper.style.paddingTop = _this.wrapperTop + 'px';
                                        if (_this.wrapperBottom >= 0) wrapper.style.paddingBottom = _this.wrapperBottom + 'px';
                                }
                                var slideLeft = 0;
                                var centeredSlideLeft = 0;
                                _this.snapGrid = [];
                                _this.slidesGrid = [];

                                var slideMaxHeight = 0;
                                for (var i = 0; i < _this.slides.length; i++) {
                                        var slideWidth = _this.slides[i].getWidth(true);
                                        var slideHeight = _this.slides[i].getHeight(true);
                                        if (params.calculateHeight) {
                                                slideMaxHeight = Math.max(slideMaxHeight, slideHeight)
                                        }
                                        var _slideSize = isH ? slideWidth : slideHeight;
                                        if (params.centeredSlides) {
                                                var nextSlideWidth = i === _this.slides.length - 1 ? 0 : _this.slides[i + 1].getWidth(true);
                                                var nextSlideHeight = i === _this.slides.length - 1 ? 0 : _this.slides[i + 1].getHeight(true);
                                                var nextSlideSize = isH ? nextSlideWidth : nextSlideHeight;
                                                if (_slideSize > containerSize) {
                                                        for (var j = 0; j <= Math.floor(_slideSize / (containerSize + _this.wrapperLeft)); j++) {
                                                                if (j === 0) _this.snapGrid.push(slideLeft + _this.wrapperLeft);
                                                                else _this.snapGrid.push(slideLeft + _this.wrapperLeft + containerSize * j);
                                                        }
                                                        _this.slidesGrid.push(slideLeft + _this.wrapperLeft);
                                                } else {
                                                        _this.snapGrid.push(centeredSlideLeft);
                                                        _this.slidesGrid.push(centeredSlideLeft);
                                                }

                                                centeredSlideLeft += _slideSize / 2 + nextSlideSize / 2;

                                        } else {
                                                if (_slideSize > containerSize) {
                                                        for (var j = 0; j <= Math.floor(_slideSize / containerSize); j++) {
                                                                _this.snapGrid.push(slideLeft + containerSize * j);
                                                        }
                                                } else {
                                                        _this.snapGrid.push(slideLeft);
                                                }
                                                _this.slidesGrid.push(slideLeft);
                                        }

                                        slideLeft += _slideSize;

                                        slidesWidth += slideWidth;
                                        slidesHeight += slideHeight;
                                }
                                if (params.calculateHeight) _this.height = slideMaxHeight;
                                if (isH) {
                                        wrapperSize = slidesWidth + _this.wrapperRight + _this.wrapperLeft;
                                        wrapper.style.width = (slidesWidth) + 'px';
                                        wrapper.style.height = (_this.height) + 'px';
                                } else {
                                        wrapperSize = slidesHeight + _this.wrapperTop + _this.wrapperBottom;
                                        wrapper.style.width = (_this.width) + 'px';
                                        wrapper.style.height = (slidesHeight) + 'px';
                                }

                        } else if (params.scrollContainer) {
                                //Scroll Container
                                wrapper.style.width = '';
                                wrapper.style.height = '';
                                var wrapperWidth = _this.slides[0].getWidth(true);
                                var wrapperHeight = _this.slides[0].getHeight(true);
                                wrapperSize = isH ? wrapperWidth : wrapperHeight;
                                wrapper.style.width = wrapperWidth + 'px';
                                wrapper.style.height = wrapperHeight + 'px';
                                slideSize = isH ? wrapperWidth : wrapperHeight;

                        } else {
                                //For usual slides
                                if (params.calculateHeight) {
                                        var slideMaxHeight = 0;
                                        var wrapperHeight = 0;
                                        //ResetWrapperSize
                                        if (!isH) _this.container.style.height = '';
                                        wrapper.style.height = '';

                                        for (var i = 0; i < _this.slides.length; i++) {
                                                //ResetSlideSize
                                                _this.slides[i].style.height = '';
                                                slideMaxHeight = Math.max(_this.slides[i].getHeight(true), slideMaxHeight);
                                                if (!isH) wrapperHeight += _this.slides[i].getHeight(true);
                                        }
                                        var slideHeight = slideMaxHeight;
                                        _this.height = slideHeight;

                                        if (isH) wrapperHeight = slideHeight;
                                        else containerSize = slideHeight, _this.container.style.height = containerSize + 'px';
                                } else {
                                        var slideHeight = isH ? _this.height : _this.height / params.slidesPerView;
                                        var wrapperHeight = isH ? _this.height : _this.slides.length * slideHeight;
                                }
                                var slideWidth = isH ? _this.width / params.slidesPerView : _this.width;
                                var wrapperWidth = isH ? _this.slides.length * slideWidth : _this.width;
                                slideSize = isH ? slideWidth : slideHeight;

                                if (params.offsetSlidesBefore > 0) {
                                        if (isH) _this.wrapperLeft = slideSize * params.offsetSlidesBefore;
                                        else _this.wrapperTop = slideSize * params.offsetSlidesBefore;
                                }
                                if (params.offsetSlidesAfter > 0) {
                                        if (isH) _this.wrapperRight = slideSize * params.offsetSlidesAfter;
                                        else _this.wrapperBottom = slideSize * params.offsetSlidesAfter;
                                }
                                if (params.offsetPxBefore > 0) {
                                        if (isH) _this.wrapperLeft = params.offsetPxBefore;
                                        else _this.wrapperTop = params.offsetPxBefore;
                                }
                                if (params.offsetPxAfter > 0) {
                                        if (isH) _this.wrapperRight = params.offsetPxAfter;
                                        else _this.wrapperBottom = params.offsetPxAfter;
                                }
                                if (params.centeredSlides) {
                                        if (isH) {
                                                _this.wrapperLeft = (containerSize - slideSize) / 2;
                                                _this.wrapperRight = (containerSize - slideSize) / 2;
                                        } else {
                                                _this.wrapperTop = (containerSize - slideSize) / 2;
                                                _this.wrapperBottom = (containerSize - slideSize) / 2;
                                        }
                                }
                                if (isH) {
                                        if (_this.wrapperLeft > 0) wrapper.style.paddingLeft = _this.wrapperLeft + 'px';
                                        if (_this.wrapperRight > 0) wrapper.style.paddingRight = _this.wrapperRight + 'px';
                                } else {
                                        if (_this.wrapperTop > 0) wrapper.style.paddingTop = _this.wrapperTop + 'px';
                                        if (_this.wrapperBottom > 0) wrapper.style.paddingBottom = _this.wrapperBottom + 'px';
                                }

                                wrapperSize = isH ? wrapperWidth + _this.wrapperRight + _this.wrapperLeft : wrapperHeight + _this.wrapperTop + _this.wrapperBottom;
                                if (!params.cssWidthAndHeight) {
                                        if (parseFloat(wrapperWidth) > 0) {
                                                wrapper.style.width = wrapperWidth + 'px';
                                        }
                                        if (parseFloat(wrapperHeight) > 0) {
                                                wrapper.style.height = wrapperHeight + 'px';
                                        }
                                }
                                var slideLeft = 0;
                                _this.snapGrid = [];
                                _this.slidesGrid = [];
                                for (var i = 0; i < _this.slides.length; i++) {
                                        _this.snapGrid.push(slideLeft);
                                        _this.slidesGrid.push(slideLeft);
                                        slideLeft += slideSize;
                                        if (!params.cssWidthAndHeight) {
                                                if (parseFloat(slideWidth) > 0) {
                                                        _this.slides[i].style.width = slideWidth + 'px';
                                                }
                                                if (parseFloat(slideHeight) > 0) {
                                                        _this.slides[i].style.height = slideHeight + 'px';
                                                }
                                        }
                                }

                        }

                        if (!_this.initialized) {
                                _this.callPlugins('onFirstInit');
                                if (params.onFirstInit) _this.fireCallback(params.onFirstInit, _this);
                        } else {
                                _this.callPlugins('onInit');
                                if (params.onInit) _this.fireCallback(params.onInit, _this);
                        }
                        _this.initialized = true;
                }

                _this.reInit = function (forceCalcSlides) {
                        _this.init(true, forceCalcSlides);
                }

                _this.resizeFix = function (reInit) {
                        _this.callPlugins('beforeResizeFix');

                        _this.init(params.resizeReInit || reInit);

                        // swipe to active slide in fixed mode
                        if (!params.freeMode) {
                                _this.swipeTo((params.loop ? _this.activeLoopIndex : _this.activeIndex), 0, false);
                        }

                        // move wrapper to the beginning in free mode
                        else if (_this.getWrapperTranslate() < -maxWrapperPosition()) {
                                _this.setWrapperTransition(0);
                                _this.setWrapperTranslate(-maxWrapperPosition());
                        }

                        _this.callPlugins('afterResizeFix');
                }

/*==========================================
        Max and Min Positions
    ============================================*/

                function maxWrapperPosition() {
                        var a = (wrapperSize - containerSize);
                        if (params.freeMode) {
                                a = wrapperSize - containerSize;
                        }
                        // if (params.loop) a -= containerSize;
                        if (params.slidesPerView > _this.slides.length) a = 0;
                        if (a < 0) a = 0;
                        return a;
                }

                function minWrapperPosition() {
                        var a = 0;
                        // if (params.loop) a = containerSize;
                        return a;
                }

/*==========================================
        Event Listeners
    ============================================*/

                function initEvents() {
                        var bind = _this.h.addEventListener;

                        //Touch Events
                        if (!_this.browser.ie10) {
                                if (_this.support.touch) {
                                        bind(_this.wrapper, 'touchstart', onTouchStart);
                                        bind(_this.wrapper, 'touchmove', onTouchMove);
                                        bind(_this.wrapper, 'touchend', onTouchEnd);
                                }
                                if (params.simulateTouch) {
                                        bind(_this.wrapper, 'mousedown', onTouchStart);
                                        bind(document, 'mousemove', onTouchMove);
                                        bind(document, 'mouseup', onTouchEnd);
                                }
                        } else {
                                bind(_this.wrapper, _this.touchEvents.touchStart, onTouchStart);
                                bind(document, _this.touchEvents.touchMove, onTouchMove);
                                bind(document, _this.touchEvents.touchEnd, onTouchEnd);
                        }

                        //Resize Event
                        if (params.autoResize) {
                                bind(window, 'resize', _this.resizeFix);
                        }
                        //Slide Events
                        addSlideEvents();
                        //Mousewheel
                        _this._wheelEvent = false;
                        if (params.mousewheelControl) {
                                if (document.onmousewheel !== undefined) {
                                        _this._wheelEvent = "mousewheel";
                                }
                                try {
                                        WheelEvent("wheel");
                                        _this._wheelEvent = "wheel";
                                } catch (e) {}
                                if (!_this._wheelEvent) {
                                        _this._wheelEvent = "DOMMouseScroll";
                                }

                                if (_this._wheelEvent) {
                                        bind(_this.container, _this._wheelEvent, handleMousewheel);
                                }
                        }

                        //Keyboard
                        if (params.keyboardControl) {
                                bind(document, 'keydown', handleKeyboardKeys);
                        }
                        if (params.updateOnImagesReady) {
                                _this.imagesToLoad = $$('img', _this.container);

                                for (var i = 0; i < _this.imagesToLoad.length; i++) {
                                        _loadImage(_this.imagesToLoad[i].getAttribute('src'))
                                }
                        }

                        function _loadImage(src) {
                                var image = new Image();
                                image.onload = function () {
                                        _this.imagesLoaded++;
                                        if (_this.imagesLoaded == _this.imagesToLoad.length) {
                                                _this.reInit();
                                                if (params.onImagesReady) _this.fireCallback(params.onImagesReady, _this);
                                        }
                                }
                                image.src = src;
                        }
                }

                //Remove Event Listeners
                _this.destroy = function (removeResizeFix) {
                        var unbind = _this.h.removeEventListener;

                        //Touch Events
                        if (!_this.browser.ie10) {
                                if (_this.support.touch) {
                                        unbind(_this.wrapper, 'touchstart', onTouchStart);
                                        unbind(_this.wrapper, 'touchmove', onTouchMove);
                                        unbind(_this.wrapper, 'touchend', onTouchEnd);
                                }
                                if (params.simulateTouch) {
                                        unbind(_this.wrapper, 'mousedown', onTouchStart);
                                        unbind(document, 'mousemove', onTouchMove);
                                        unbind(document, 'mouseup', onTouchEnd);
                                }
                        } else {
                                unbind(_this.wrapper, _this.touchEvents.touchStart, onTouchStart);
                                unbind(document, _this.touchEvents.touchMove, onTouchMove);
                                unbind(document, _this.touchEvents.touchEnd, onTouchEnd);
                        }

                        //Resize Event
                        if (params.autoResize) {
                                unbind(window, 'resize', _this.resizeFix);
                        }

                        //Init Slide Events
                        removeSlideEvents();

                        //Pagination
                        if (params.paginationClickable) {
                                removePaginationEvents();
                        }

                        //Mousewheel
                        if (params.mousewheelControl && _this._wheelEvent) {
                                unbind(_this.container, _this._wheelEvent, handleMousewheel);
                        }

                        //Keyboard
                        if (params.keyboardControl) {
                                unbind(document, 'keydown', handleKeyboardKeys);
                        }

                        //Stop autoplay
                        if (params.autoplay) {
                                _this.stopAutoplay();
                        }
                        _this.callPlugins('onDestroy');

                        //Destroy variable
                        _this = null;
                }

                function addSlideEvents() {
                        var bind = _this.h.addEventListener,
                                i;

                        //Prevent Links Events
                        if (params.preventLinks) {
                                var links = $$('a', _this.container);
                                for (i = 0; i < links.length; i++) {
                                        bind(links[i], 'click', preventClick);
                                }
                        }
                        //Release Form Elements
                        if (params.releaseFormElements) {
                                var formElements = $$('input, textarea, select', _this.container);
                                for (i = 0; i < formElements.length; i++) {
                                        bind(formElements[i], _this.touchEvents.touchStart, releaseForms, true);
                                }
                        }

                        //Slide Clicks & Touches
                        if (params.onSlideClick) {
                                for (i = 0; i < _this.slides.length; i++) {
                                        bind(_this.slides[i], 'click', slideClick);
                                }
                        }
                        if (params.onSlideTouch) {
                                for (i = 0; i < _this.slides.length; i++) {
                                        bind(_this.slides[i], _this.touchEvents.touchStart, slideTouch);
                                }
                        }
                }

                function removeSlideEvents() {
                        var unbind = _this.h.removeEventListener,
                                i;

                        //Slide Clicks & Touches
                        if (params.onSlideClick) {
                                for (i = 0; i < _this.slides.length; i++) {
                                        unbind(_this.slides[i], 'click', slideClick);
                                }
                        }
                        if (params.onSlideTouch) {
                                for (i = 0; i < _this.slides.length; i++) {
                                        unbind(_this.slides[i], _this.touchEvents.touchStart, slideTouch);
                                }
                        }
                        //Release Form Elements
                        if (params.releaseFormElements) {
                                var formElements = $$('input, textarea, select', _this.container);
                                for (i = 0; i < formElements.length; i++) {
                                        unbind(formElements[i], _this.touchEvents.touchStart, releaseForms, true);
                                }
                        }
                        //Prevent Links Events
                        if (params.preventLinks) {
                                var links = $$('a', _this.container);
                                for (i = 0; i < links.length; i++) {
                                        unbind(links[i], 'click', preventClick);
                                }
                        }
                }
/*==========================================
        Keyboard Control
    ============================================*/

                function handleKeyboardKeys(e) {
                        var kc = e.keyCode || e.charCode;
                        if (kc == 37 || kc == 39 || kc == 38 || kc == 40) {
                                var inView = false;
                                //Check that swiper should be inside of visible area of window
                                var swiperOffset = _this.h.getOffset(_this.container);
                                var scrollLeft = _this.h.windowScroll().left;
                                var scrollTop = _this.h.windowScroll().top;
                                var windowWidth = _this.h.windowWidth();
                                var windowHeight = _this.h.windowHeight();
                                var swiperCoord = [
                                        [swiperOffset.left, swiperOffset.top],
                                        [swiperOffset.left + _this.width, swiperOffset.top],
                                        [swiperOffset.left, swiperOffset.top + _this.height],
                                        [swiperOffset.left + _this.width, swiperOffset.top + _this.height]
                                ]
                                for (var i = 0; i < swiperCoord.length; i++) {
                                        var point = swiperCoord[i];
                                        if (
                                        point[0] >= scrollLeft && point[0] <= scrollLeft + windowWidth && point[1] >= scrollTop && point[1] <= scrollTop + windowHeight) {
                                                inView = true;
                                        }

                                }
                                if (!inView) return;
                        }
                        if (isH) {
                                if (kc == 37 || kc == 39) {
                                        if (e.preventDefault) e.preventDefault();
                                        else e.returnValue = false;
                                }
                                if (kc == 39) _this.swipeNext();
                                if (kc == 37) _this.swipePrev();
                        } else {
                                if (kc == 38 || kc == 40) {
                                        if (e.preventDefault) e.preventDefault();
                                        else e.returnValue = false;
                                }
                                if (kc == 40) _this.swipeNext();
                                if (kc == 38) _this.swipePrev();
                        }
                }

/*==========================================
        Mousewheel Control
    ============================================*/
                var lastScrollTime = (new Date()).getTime();

                function handleMousewheel(e) {
                        var we = _this._wheelEvent;
                        var delta = 0;

                        //Opera & IE
                        if (e.detail) delta = -e.detail;
                        //WebKits
                        else if (we == 'mousewheel') {
                                if (isH) {
                                        if (Math.abs(e.wheelDeltaX) > Math.abs(e.wheelDeltaY)) delta = e.wheelDeltaX;
                                        else return;
                                } else {
                                        if (Math.abs(e.wheelDeltaY) > Math.abs(e.wheelDeltaX)) delta = e.wheelDeltaY;
                                        else return;
                                }
                        }
                        //Old FireFox
                        else if (we == 'DOMMouseScroll') delta = -e.detail;
                        //New FireFox
                        else if (we == 'wheel') {
                                if (isH) {
                                        if (Math.abs(e.deltaX) > Math.abs(e.deltaY)) delta = -e.deltaX;
                                        else return;
                                } else {
                                        if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) delta = -e.deltaY;
                                        else return;
                                }
                        }

                        if (!params.freeMode) {
                                if ((new Date()).getTime() - lastScrollTime > 60) {
                                        if (delta < 0) _this.swipeNext();
                                        else _this.swipePrev();
                                }
                                lastScrollTime = (new Date()).getTime();

                        } else {
                                //Freemode or scrollContainer:
                                var position = _this.getWrapperTranslate() + delta;

                                if (position > 0) position = 0;
                                if (position < -maxWrapperPosition()) position = -maxWrapperPosition();

                                _this.setWrapperTransition(0);
                                _this.setWrapperTranslate(position);
                                _this.updateActiveSlide(position);

                                // Return page scroll on edge positions
                                if (position == 0 || position == -maxWrapperPosition()) return;
                        }
                        if (params.autoplay) _this.stopAutoplay(true);

                        if (e.preventDefault) e.preventDefault();
                        else e.returnValue = false;
                        return false;
                }

/*=========================
      Grab Cursor
      ===========================*/
                if (params.grabCursor) {
                        var containerStyle = _this.container.style;
                        containerStyle.cursor = 'move';
                        containerStyle.cursor = 'grab';
                        containerStyle.cursor = '-moz-grab';
                        containerStyle.cursor = '-webkit-grab';
                }

/*=========================
      Slides Events Handlers
      ===========================*/

                _this.allowSlideClick = true;

                function slideClick(event) {
                        if (_this.allowSlideClick) {
                                setClickedSlide(event);
                                _this.fireCallback(params.onSlideClick, _this, event);
                        }
                }

                function slideTouch(event) {
                        setClickedSlide(event);
                        _this.fireCallback(params.onSlideTouch, _this, event);
                }

                function setClickedSlide(event) {

                        // IE 6-8 support
                        if (!event.currentTarget) {
                                var element = event.srcElement;
                                do {
                                        if (element.className.indexOf(params.slideClass) > -1) {
                                                break;
                                        }
                                }
                                while (element = element.parentNode);
                                _this.clickedSlide = element;
                        } else {
                                _this.clickedSlide = event.currentTarget;
                        }

                        _this.clickedSlideIndex = _this.slides.indexOf(_this.clickedSlide);
                        _this.clickedSlideLoopIndex = _this.clickedSlideIndex - (_this.loopedSlides || 0);
                }

                _this.allowLinks = true;

                function preventClick(e) {
                        if (!_this.allowLinks) {
                                if (e.preventDefault) e.preventDefault();
                                else e.returnValue = false;
                                return false;
                        }
                }

                function releaseForms(e) {
                        if (e.stopPropagation) e.stopPropagation();
                        else e.returnValue = false;
                        return false;

                }

/*==================================================
        Event Handlers
    ====================================================*/
                var isTouchEvent = false;
                var allowThresholdMove;
                var allowMomentumBounce = true;

                function onTouchStart(event) {
                        if (params.preventLinks) _this.allowLinks = true;
                        //Exit if slider is already was touched
                        if (_this.isTouched || params.onlyExternal) {
                                return false;
                        }

                        if (params.noSwiping && (event.target || event.srcElement) && noSwipingSlide(event.target || event.srcElement)) return false;
                        allowMomentumBounce = false;

                        //Check For Nested Swipers
                        _this.isTouched = true;
                        isTouchEvent = event.type == 'touchstart';

                        if (!isTouchEvent || event.targetTouches.length == 1) {
                                _this.callPlugins('onTouchStartBegin');

                                if (!isTouchEvent) {
                                        if (event.preventDefault) event.preventDefault();
                                        else event.returnValue = false;
                                }

                                var pageX = isTouchEvent ? event.targetTouches[0].pageX : (event.pageX || event.clientX);
                                var pageY = isTouchEvent ? event.targetTouches[0].pageY : (event.pageY || event.clientY);

                                //Start Touches to check the scrolling
                                _this.touches.startX = _this.touches.currentX = pageX;
                                _this.touches.startY = _this.touches.currentY = pageY;

                                _this.touches.start = _this.touches.current = isH ? pageX : pageY;

                                //Set Transition Time to 0
                                _this.setWrapperTransition(0);

                                //Get Start Translate Position
                                _this.positions.start = _this.positions.current = _this.getWrapperTranslate();

                                //Set Transform
                                _this.setWrapperTranslate(_this.positions.start);

                                //TouchStartTime
                                _this.times.start = (new Date()).getTime();

                                //Unset Scrolling
                                isScrolling = undefined;

                                //Set Treshold
                                if (params.moveStartThreshold > 0) allowThresholdMove = false;

                                //CallBack
                                if (params.onTouchStart) _this.fireCallback(params.onTouchStart, _this);
                                _this.callPlugins('onTouchStartEnd');

                        }
                }
                var velocityPrevPosition, velocityPrevTime;

                function onTouchMove(event) {
                        // If slider is not touched - exit
                        if (!_this.isTouched || params.onlyExternal) return;
                        if (isTouchEvent && event.type == 'mousemove') return;

                        var pageX = isTouchEvent ? event.targetTouches[0].pageX : (event.pageX || event.clientX);
                        var pageY = isTouchEvent ? event.targetTouches[0].pageY : (event.pageY || event.clientY);

                        //check for scrolling
                        if (typeof isScrolling === 'undefined' && isH) {
                                isScrolling = !! (isScrolling || Math.abs(pageY - _this.touches.startY) > Math.abs(pageX - _this.touches.startX));
                        }
                        if (typeof isScrolling === 'undefined' && !isH) {
                                isScrolling = !! (isScrolling || Math.abs(pageY - _this.touches.startY) < Math.abs(pageX - _this.touches.startX));
                        }
                        if (isScrolling) {
                                _this.isTouched = false;
                                return;
                        }

                        //Check For Nested Swipers
                        if (event.assignedToSwiper) {
                                _this.isTouched = false;
                                return;
                        }
                        event.assignedToSwiper = true;

                        //Block inner links
                        if (params.preventLinks) {
                                _this.allowLinks = false;
                        }
                        if (params.onSlideClick) {
                                _this.allowSlideClick = false;
                        }

                        //Stop AutoPlay if exist
                        if (params.autoplay) {
                                _this.stopAutoplay(true);
                        }
                        if (!isTouchEvent || event.touches.length == 1) {

                                //Moved Flag
                                if (!_this.isMoved) {
                                        _this.callPlugins('onTouchMoveStart');

                                        if (params.loop) {
                                                _this.fixLoop();
                                                _this.positions.start = _this.getWrapperTranslate();
                                        }
                                        if (params.onTouchMoveStart) _this.fireCallback(params.onTouchMoveStart, _this);
                                }
                                _this.isMoved = true;

                                // cancel event
                                if (event.preventDefault) event.preventDefault();
                                else event.returnValue = false;

                                _this.touches.current = isH ? pageX : pageY;

                                _this.positions.current = (_this.touches.current - _this.touches.start) * params.touchRatio + _this.positions.start;

                                //Resistance Callbacks
                                if (_this.positions.current > 0 && params.onResistanceBefore) {
                                        _this.fireCallback(params.onResistanceBefore, _this, _this.positions.current);
                                }
                                if (_this.positions.current < -maxWrapperPosition() && params.onResistanceAfter) {
                                        _this.fireCallback(params.onResistanceAfter, _this, Math.abs(_this.positions.current + maxWrapperPosition()));
                                }
                                //Resistance
                                if (params.resistance && params.resistance != '100%') {
                                        //Resistance for Negative-Back sliding
                                        if (_this.positions.current > 0) {
                                                var resistance = 1 - _this.positions.current / containerSize / 2;
                                                if (resistance < 0.5) _this.positions.current = (containerSize / 2);
                                                else _this.positions.current = _this.positions.current * resistance;
                                        }
                                        //Resistance for After-End Sliding
                                        if (_this.positions.current < -maxWrapperPosition()) {

                                                var diff = (_this.touches.current - _this.touches.start) * params.touchRatio + (maxWrapperPosition() + _this.positions.start);
                                                var resistance = (containerSize + diff) / (containerSize);
                                                var newPos = _this.positions.current - diff * (1 - resistance) / 2;
                                                var stopPos = -maxWrapperPosition() - containerSize / 2;

                                                if (newPos < stopPos || resistance <= 0) _this.positions.current = stopPos;
                                                else _this.positions.current = newPos;
                                        }
                                }
                                if (params.resistance && params.resistance == '100%') {
                                        //Resistance for Negative-Back sliding
                                        if (_this.positions.current > 0 && !(params.freeMode && !params.freeModeFluid)) {
                                                _this.positions.current = 0;
                                        }
                                        //Resistance for After-End Sliding
                                        if ((_this.positions.current) < -maxWrapperPosition() && !(params.freeMode && !params.freeModeFluid)) {
                                                _this.positions.current = -maxWrapperPosition();
                                        }
                                }
                                //Move Slides
                                if (!params.followFinger) return;

                                if (!params.moveStartThreshold) {
                                        _this.setWrapperTranslate(_this.positions.current);
                                } else {
                                        if (Math.abs(_this.touches.current - _this.touches.start) > params.moveStartThreshold || allowThresholdMove) {
                                                allowThresholdMove = true;
                                                _this.setWrapperTranslate(_this.positions.current);
                                        } else {
                                                _this.positions.current = _this.positions.start;
                                        }
                                }

                                if (params.freeMode || params.watchActiveIndex) {
                                        _this.updateActiveSlide(_this.positions.current);
                                }

                                //Grab Cursor
                                if (params.grabCursor) {
                                        _this.container.style.cursor = 'move';
                                        _this.container.style.cursor = 'grabbing';
                                        _this.container.style.cursor = '-moz-grabbin';
                                        _this.container.style.cursor = '-webkit-grabbing';
                                }
                                //Velocity
                                if (!velocityPrevPosition) velocityPrevPosition = _this.touches.current;
                                if (!velocityPrevTime) velocityPrevTime = (new Date).getTime();
                                _this.velocity = (_this.touches.current - velocityPrevPosition) / ((new Date).getTime() - velocityPrevTime) / 2;
                                if (Math.abs(_this.touches.current - velocityPrevPosition) < 2) _this.velocity = 0;
                                velocityPrevPosition = _this.touches.current;
                                velocityPrevTime = (new Date).getTime();
                                //Callbacks
                                _this.callPlugins('onTouchMoveEnd');
                                if (params.onTouchMove) _this.fireCallback(params.onTouchMove, _this);

                                return false;
                        }
                }

                function onTouchEnd(event) {
                        //Check For scrolling
                        if (isScrolling) {
                                _this.swipeReset();
                        }
                        // If slider is not touched exit
                        if (params.onlyExternal || !_this.isTouched) return;
                        _this.isTouched = false

                        //Return Grab Cursor
                        if (params.grabCursor) {
                                _this.container.style.cursor = 'move';
                                _this.container.style.cursor = 'grab';
                                _this.container.style.cursor = '-moz-grab';
                                _this.container.style.cursor = '-webkit-grab';
                        }

                        //Check for Current Position
                        if (!_this.positions.current && _this.positions.current !== 0) {
                                _this.positions.current = _this.positions.start
                        }

                        //For case if slider touched but not moved
                        if (params.followFinger) {
                                _this.setWrapperTranslate(_this.positions.current);
                        }

                        // TouchEndTime
                        _this.times.end = (new Date()).getTime();

                        //Difference
                        _this.touches.diff = _this.touches.current - _this.touches.start
                        _this.touches.abs = Math.abs(_this.touches.diff)

                        _this.positions.diff = _this.positions.current - _this.positions.start
                        _this.positions.abs = Math.abs(_this.positions.diff)

                        var diff = _this.positions.diff;
                        var diffAbs = _this.positions.abs;
                        var timeDiff = _this.times.end - _this.times.start

                        if (diffAbs < 5 && (timeDiff) < 300 && _this.allowLinks == false) {
                                if (!params.freeMode && diffAbs != 0) _this.swipeReset()
                                //Release inner links
                                if (params.preventLinks) {
                                        _this.allowLinks = true;
                                }
                                if (params.onSlideClick) {
                                        _this.allowSlideClick = true;
                                }
                        }

                        setTimeout(function () {
                                //Release inner links
                                if (params.preventLinks) {
                                        _this.allowLinks = true;
                                }
                                if (params.onSlideClick) {
                                        _this.allowSlideClick = true;
                                }
                        }, 100);

                        var maxPosition = maxWrapperPosition();

                        //Not moved or Prevent Negative Back Sliding/After-End Sliding
                        if (!_this.isMoved && params.freeMode) {
                                _this.isMoved = false;
                                if (params.onTouchEnd) _this.fireCallback(params.onTouchEnd, _this);
                                _this.callPlugins('onTouchEnd');
                                return;
                        }
                        if (!_this.isMoved || _this.positions.current > 0 || _this.positions.current < -maxPosition) {
                                _this.swipeReset();
                                if (params.onTouchEnd) _this.fireCallback(params.onTouchEnd, _this);
                                _this.callPlugins('onTouchEnd');
                                return;
                        }

                        _this.isMoved = false;

                        //Free Mode
                        if (params.freeMode) {
                                if (params.freeModeFluid) {
                                        var momentumDuration = 1000 * params.momentumRatio;
                                        var momentumDistance = _this.velocity * momentumDuration;
                                        var newPosition = _this.positions.current + momentumDistance
                                        var doBounce = false;
                                        var afterBouncePosition;
                                        var bounceAmount = Math.abs(_this.velocity) * 20 * params.momentumBounceRatio;
                                        if (newPosition < -maxPosition) {
                                                if (params.momentumBounce && _this.support.transitions) {
                                                        if (newPosition + maxPosition < -bounceAmount) newPosition = -maxPosition - bounceAmount;
                                                        afterBouncePosition = -maxPosition;
                                                        doBounce = true;
                                                        allowMomentumBounce = true;
                                                } else newPosition = -maxPosition;
                                        }
                                        if (newPosition > 0) {
                                                if (params.momentumBounce && _this.support.transitions) {
                                                        if (newPosition > bounceAmount) newPosition = bounceAmount;
                                                        afterBouncePosition = 0
                                                        doBounce = true;
                                                        allowMomentumBounce = true;
                                                } else newPosition = 0;
                                        }
                                        //Fix duration
                                        if (_this.velocity != 0) momentumDuration = Math.abs((newPosition - _this.positions.current) / _this.velocity)

                                        _this.setWrapperTranslate(newPosition);

                                        _this.setWrapperTransition(momentumDuration);

                                        if (params.momentumBounce && doBounce) {
                                                _this.wrapperTransitionEnd(function () {
                                                        if (!allowMomentumBounce) return;
                                                        if (params.onMomentumBounce) _this.fireCallback(params.onMomentumBounce, _this);
                                                        _this.callPlugins('onMomentumBounce');

                                                        _this.setWrapperTranslate(afterBouncePosition);
                                                        _this.setWrapperTransition(300);
                                                })
                                        }

                                        _this.updateActiveSlide(newPosition)
                                }
                                if (!params.freeModeFluid || timeDiff >= 300) _this.updateActiveSlide(_this.positions.current)

                                if (params.onTouchEnd) _this.fireCallback(params.onTouchEnd, _this);
                                _this.callPlugins('onTouchEnd');
                                return;
                        }

                        //Direction
                        direction = diff < 0 ? "toNext" : "toPrev"

                        //Short Touches
                        if (direction == "toNext" && (timeDiff <= 300)) {
                                if (diffAbs < 30 || !params.shortSwipes) _this.swipeReset()
                                else _this.swipeNext(true);
                        }

                        if (direction == "toPrev" && (timeDiff <= 300)) {
                                if (diffAbs < 30 || !params.shortSwipes) _this.swipeReset()
                                else _this.swipePrev(true);
                        }

                        //Long Touches
                        var targetSlideSize = 0;
                        if (params.slidesPerView == 'auto') {
                                //Define current slide's width
                                var currentPosition = Math.abs(_this.getWrapperTranslate());
                                var slidesOffset = 0;
                                var _slideSize;
                                for (var i = 0; i < _this.slides.length; i++) {
                                        _slideSize = isH ? _this.slides[i].getWidth(true) : _this.slides[i].getHeight(true);
                                        slidesOffset += _slideSize;
                                        if (slidesOffset > currentPosition) {
                                                targetSlideSize = _slideSize;
                                                break;
                                        }
                                }
                                if (targetSlideSize > containerSize) targetSlideSize = containerSize;
                        } else {
                                targetSlideSize = slideSize * params.slidesPerView;
                        }
                        if (direction == "toNext" && (timeDiff > 300)) {
                                if (diffAbs >= targetSlideSize * 0.5) {
                                        _this.swipeNext(true)
                                } else {
                                        _this.swipeReset()
                                }
                        }
                        if (direction == "toPrev" && (timeDiff > 300)) {
                                if (diffAbs >= targetSlideSize * 0.5) {
                                        _this.swipePrev(true);
                                } else {
                                        _this.swipeReset()
                                }
                        }
                        if (params.onTouchEnd) params.onTouchEnd(_this)
                        _this.callPlugins('onTouchEnd');
                }


/*==================================================
        noSwiping Bubble Check by Isaac Strack
    ====================================================*/

                function noSwipingSlide(el) {
/*This function is specifically designed to check the parent elements for the noSwiping class, up to the wrapper.
        We need to check parents because while onTouchStart bubbles, _this.isTouched is checked in onTouchStart, which stops the bubbling.
        So, if a text box, for example, is the initial target, and the parent slide container has the noSwiping class, the _this.isTouched
        check will never find it, and what was supposed to be noSwiping is able to be swiped.
        This function will iterate up and check for the noSwiping class in parents, up through the wrapperClass.*/

                        // First we create a truthy variable, which is that swiping is allowd (noSwiping = false)
                        var noSwiping = false;

                        // Now we iterate up (parentElements) until we reach the node with the wrapperClass.
                        do {

                                // Each time, we check to see if there's a 'swiper-no-swiping' class (noSwipingClass).
                                if (el.className.indexOf(params.noSwipingClass) > -1) {
                                        noSwiping = true; // If there is, we set noSwiping = true;
                                }

                                el = el.parentElement; // now we iterate up (parent node)
                        } while (!noSwiping && el.parentElement && el.className.indexOf(params.wrapperClass) == -1); // also include el.parentElement truthy, just in case.
                        // because we didn't check the wrapper itself, we do so now, if noSwiping is false:
                        if (!noSwiping && el.className.indexOf(params.wrapperClass) > -1 && el.className.indexOf(params.noSwipingClass) > -1) noSwiping = true; // if the wrapper has the noSwipingClass, we set noSwiping = true;
                        return noSwiping;
                }

/*==================================================
        Swipe Functions
    ====================================================*/
                _this.swipeNext = function (internal) {
                        if (!internal && params.loop) _this.fixLoop();
                        if (!internal && params.autoplay) _this.stopAutoplay(true);
                        _this.callPlugins('onSwipeNext');
                        var currentPosition = _this.getWrapperTranslate();
                        var newPosition = currentPosition;
                        if (params.slidesPerView == 'auto') {
                                for (var i = 0; i < _this.snapGrid.length; i++) {
                                        if (-currentPosition >= _this.snapGrid[i] && -currentPosition < _this.snapGrid[i + 1]) {
                                                newPosition = -_this.snapGrid[i + 1]
                                                break;
                                        }
                                }
                        } else {
                                var groupSize = slideSize * params.slidesPerGroup;
                                newPosition = -(Math.floor(Math.abs(currentPosition) / Math.floor(groupSize)) * groupSize + groupSize);
                        }
                        if (newPosition < -maxWrapperPosition()) {
                                newPosition = -maxWrapperPosition()
                        };
                        if (newPosition == currentPosition) return false;
                        swipeToPosition(newPosition, 'next');
                        return true
                }
                _this.swipePrev = function (internal) {
                        if (!internal && params.loop) _this.fixLoop();
                        if (!internal && params.autoplay) _this.stopAutoplay(true);
                        _this.callPlugins('onSwipePrev');

                        var currentPosition = Math.ceil(_this.getWrapperTranslate());
                        var newPosition;
                        if (params.slidesPerView == 'auto') {
                                newPosition = 0;
                                for (var i = 1; i < _this.snapGrid.length; i++) {
                                        if (-currentPosition == _this.snapGrid[i]) {
                                                newPosition = -_this.snapGrid[i - 1]
                                                break;
                                        }
                                        if (-currentPosition > _this.snapGrid[i] && -currentPosition < _this.snapGrid[i + 1]) {
                                                newPosition = -_this.snapGrid[i]
                                                break;
                                        }
                                }
                        } else {
                                var groupSize = slideSize * params.slidesPerGroup;
                                newPosition = -(Math.ceil(-currentPosition / groupSize) - 1) * groupSize;
                        }

                        if (newPosition > 0) newPosition = 0;

                        if (newPosition == currentPosition) return false;
                        swipeToPosition(newPosition, 'prev');
                        return true;

                }
                _this.swipeReset = function () {
                        _this.callPlugins('onSwipeReset');
                        var currentPosition = _this.getWrapperTranslate();
                        var groupSize = slideSize * params.slidesPerGroup;
                        var newPosition;
                        var maxPosition = -maxWrapperPosition();
                        if (params.slidesPerView == 'auto') {
                                newPosition = 0;
                                for (var i = 0; i < _this.snapGrid.length; i++) {
                                        if (-currentPosition === _this.snapGrid[i]) return;
                                        if (-currentPosition >= _this.snapGrid[i] && -currentPosition < _this.snapGrid[i + 1]) {
                                                if (_this.positions.diff > 0) newPosition = -_this.snapGrid[i + 1]
                                                else newPosition = -_this.snapGrid[i]
                                                break;
                                        }
                                }
                                if (-currentPosition >= _this.snapGrid[_this.snapGrid.length - 1]) newPosition = -_this.snapGrid[_this.snapGrid.length - 1];
                                if (currentPosition <= -maxWrapperPosition()) newPosition = -maxWrapperPosition()
                        } else {
                                newPosition = currentPosition < 0 ? Math.round(currentPosition / groupSize) * groupSize : 0
                        }
                        if (params.scrollContainer) {
                                newPosition = currentPosition < 0 ? currentPosition : 0;
                        }
                        if (newPosition < -maxWrapperPosition()) {
                                newPosition = -maxWrapperPosition()
                        }
                        if (params.scrollContainer && (containerSize > slideSize)) {
                                newPosition = 0;
                        }

                        if (newPosition == currentPosition) return false;

                        swipeToPosition(newPosition, 'reset');
                        return true;
                }

                _this.swipeTo = function (index, speed, runCallbacks) {
                        index = parseInt(index, 10);
                        _this.callPlugins('onSwipeTo', {
                                index: index,
                                speed: speed
                        });
                        if (params.loop) index = index + _this.loopedSlides;
                        var currentPosition = _this.getWrapperTranslate();
                        if (index > (_this.slides.length - 1) || index < 0) return;
                        var newPosition
                        if (params.slidesPerView == 'auto') {
                                newPosition = -_this.slidesGrid[index];
                        } else {
                                newPosition = -index * slideSize;
                        }
                        if (newPosition < -maxWrapperPosition()) {
                                newPosition = -maxWrapperPosition();
                        };

                        if (newPosition == currentPosition) return false;

                        runCallbacks = runCallbacks === false ? false : true;
                        swipeToPosition(newPosition, 'to', {
                                index: index,
                                speed: speed,
                                runCallbacks: runCallbacks
                        });
                        return true;
                }

                function swipeToPosition(newPosition, action, toOptions) {
                        var speed = (action == 'to' && toOptions.speed >= 0) ? toOptions.speed : params.speed;

                        if (_this.support.transitions || !params.DOMAnimation) {
                                _this.setWrapperTranslate(newPosition);
                                _this.setWrapperTransition(speed);
                        } else {
                                //Try the DOM animation
                                var currentPosition = _this.getWrapperTranslate();
                                var animationStep = Math.ceil((newPosition - currentPosition) / speed * (1000 / 60));
                                var direction = currentPosition > newPosition ? 'toNext' : 'toPrev';
                                var condition = direction == 'toNext' ? currentPosition > newPosition : currentPosition < newPosition;
                                if (_this._DOMAnimating) return;

                                anim();
                        }

                        function anim() {
                                currentPosition += animationStep;
                                condition = direction == 'toNext' ? currentPosition > newPosition : currentPosition < newPosition;
                                if (condition) {
                                        _this.setWrapperTranslate(Math.round(currentPosition));
                                        _this._DOMAnimating = true
                                        window.setTimeout(function () {
                                                anim()
                                        }, 1000 / 60)
                                } else {
                                        if (params.onSlideChangeEnd) _this.fireCallback(params.onSlideChangeEnd, _this);
                                        _this.setWrapperTranslate(newPosition);
                                        _this._DOMAnimating = false;
                                }
                        }

                        //Update Active Slide Index
                        _this.updateActiveSlide(newPosition);

                        //Callbacks
                        if (params.onSlideNext && action == 'next') {
                                _this.fireCallback(params.onSlideNext, _this, newPosition);
                        }
                        if (params.onSlidePrev && action == 'prev') {
                                _this.fireCallback(params.onSlidePrev, _this, newPosition);
                        }
                        //"Reset" Callback
                        if (params.onSlideReset && action == 'reset') {
                                _this.fireCallback(params.onSlideReset, _this, newPosition);
                        }

                        //"Next", "Prev" and "To" Callbacks
                        if (action == 'next' || action == 'prev' || (action == 'to' && toOptions.runCallbacks == true)) slideChangeCallbacks(action);
                }
/*==================================================
        Transition Callbacks
    ====================================================*/
                //Prevent Multiple Callbacks
                _this._queueStartCallbacks = false;
                _this._queueEndCallbacks = false;

                function slideChangeCallbacks(direction) {
                        //Transition Start Callback
                        _this.callPlugins('onSlideChangeStart');
                        if (params.onSlideChangeStart) {
                                if (params.queueStartCallbacks && _this.support.transitions) {
                                        if (_this._queueStartCallbacks) return;
                                        _this._queueStartCallbacks = true;
                                        _this.fireCallback(params.onSlideChangeStart, _this, direction)
                                        _this.wrapperTransitionEnd(function () {
                                                _this._queueStartCallbacks = false;
                                        })
                                } else _this.fireCallback(params.onSlideChangeStart, _this, direction)
                        }
                        //Transition End Callback
                        if (params.onSlideChangeEnd) {
                                if (_this.support.transitions) {
                                        if (params.queueEndCallbacks) {
                                                if (_this._queueEndCallbacks) return;
                                                _this._queueEndCallbacks = true;
                                                _this.wrapperTransitionEnd(function (swiper) {
                                                        _this.fireCallback(params.onSlideChangeEnd, swiper, direction)
                                                })
                                        } else _this.wrapperTransitionEnd(function (swiper) {
                                                _this.fireCallback(params.onSlideChangeEnd, swiper, direction)
                                        })
                                } else {
                                        if (!params.DOMAnimation) {
                                                setTimeout(function () {
                                                        _this.fireCallback(params.onSlideChangeStart, _this, direction)
                                                }, 10)
                                        }
                                }
                        }
                }

/*==================================================
        Update Active Slide Index
    ====================================================*/
                _this.updateActiveSlide = function (position) {
                        if (!_this.initialized) return;
                        if (_this.slides.length == 0) return;
                        _this.previousIndex = _this.activeIndex;
                        if (typeof position == 'undefined') position = _this.getWrapperTranslate();
                        if (position > 0) position = 0;

                        if (params.slidesPerView == 'auto') {
                                var slidesOffset = 0;
                                _this.activeIndex = _this.slidesGrid.indexOf(-position);
                                if (_this.activeIndex < 0) {
                                        for (var i = 0; i < _this.slidesGrid.length - 1; i++) {
                                                if (-position > _this.slidesGrid[i] && -position < _this.slidesGrid[i + 1]) {
                                                        break;
                                                }
                                        }
                                        var leftDistance = Math.abs(_this.slidesGrid[i] + position)
                                        var rightDistance = Math.abs(_this.slidesGrid[i + 1] + position)
                                        if (leftDistance <= rightDistance) _this.activeIndex = i;
                                        else _this.activeIndex = i + 1;
                                }
                        } else {
                                _this.activeIndex = Math[params.visibilityFullFit ? 'ceil' : 'round'](-position / slideSize);
                        }

                        if (_this.activeIndex == _this.slides.length) _this.activeIndex = _this.slides.length - 1;
                        if (_this.activeIndex < 0) _this.activeIndex = 0;

                        // Check for slide
                        if (!_this.slides[_this.activeIndex]) return;

                        // Calc Visible slides
                        _this.calcVisibleSlides(position);

                        // Mark visible and active slides with additonal classes
                        var activeClassRegexp = new RegExp("\\s*" + params.slideActiveClass);
                        var inViewClassRegexp = new RegExp("\\s*" + params.slideVisibleClass);

                        for (var i = 0; i < _this.slides.length; i++) {
                                _this.slides[i].className = _this.slides[i].className.replace(activeClassRegexp, '').replace(inViewClassRegexp, '');
                                if (_this.visibleSlides.indexOf(_this.slides[i]) >= 0) {
                                        _this.slides[i].className += ' ' + params.slideVisibleClass;
                                }

                        }
                        _this.slides[_this.activeIndex].className += ' ' + params.slideActiveClass;

                        //Update loop index
                        if (params.loop) {
                                var ls = _this.loopedSlides;
                                _this.activeLoopIndex = _this.activeIndex - ls;
                                if (_this.activeLoopIndex >= _this.slides.length - ls * 2) {
                                        _this.activeLoopIndex = _this.slides.length - ls * 2 - _this.activeLoopIndex;
                                }
                                if (_this.activeLoopIndex < 0) {
                                        _this.activeLoopIndex = _this.slides.length - ls * 2 + _this.activeLoopIndex;
                                }
                        } else {
                                _this.activeLoopIndex = _this.activeIndex;
                        }
                        //Update Pagination
                        if (params.pagination) {
                                _this.updatePagination(position);
                        }
                }
/*==================================================
        Pagination
    ====================================================*/
                _this.createPagination = function (firstInit) {
                        if (params.paginationClickable && _this.paginationButtons) {
                                removePaginationEvents();
                        }
                        _this.paginationContainer = params.pagination.nodeType ? params.pagination : $$(params.pagination)[0];
                        if (params.createPagination) {
                                var paginationHTML = "";
                                var numOfSlides = _this.slides.length;
                                var numOfButtons = numOfSlides;
                                if (params.loop) numOfButtons -= _this.loopedSlides * 2
                                for (var i = 0; i < numOfButtons; i++) {
                                        paginationHTML += '<' + params.paginationElement + ' class="' + params.paginationElementClass + '"></' + params.paginationElement + '>'
                                }
                                _this.paginationContainer.innerHTML = paginationHTML;
                        }
                        _this.paginationButtons = $$('.' + params.paginationElementClass, _this.paginationContainer);
                        if (!firstInit) _this.updatePagination()
                        _this.callPlugins('onCreatePagination');
                        if (params.paginationClickable) {
                                addPaginationEvents();
                        }
                }

                function removePaginationEvents() {
                        var pagers = _this.paginationButtons;
                        for (var i = 0; i < pagers.length; i++) {
                                _this.h.removeEventListener(pagers[i], 'click', paginationClick);
                        }
                }

                function addPaginationEvents() {
                        var pagers = _this.paginationButtons;
                        for (var i = 0; i < pagers.length; i++) {
                                _this.h.addEventListener(pagers[i], 'click', paginationClick);
                        }
                }

                function paginationClick(e) {
                        var index;
                        var target = e.target || e.srcElement;
                        var pagers = _this.paginationButtons;
                        for (var i = 0; i < pagers.length; i++) {
                                if (target === pagers[i]) index = i;
                        }
                        _this.swipeTo(index)
                }
                _this.updatePagination = function (position) {
                        if (!params.pagination) return;
                        if (_this.slides.length < 1) return;
                        var activePagers = $$('.' + params.paginationActiveClass, _this.paginationContainer);
                        if (!activePagers) return;

                        //Reset all Buttons' class to not active
                        var pagers = _this.paginationButtons;
                        if (pagers.length == 0) return;
                        for (var i = 0; i < pagers.length; i++) {
                                pagers[i].className = params.paginationElementClass
                        }

                        var indexOffset = params.loop ? _this.loopedSlides : 0;
                        if (params.paginationAsRange) {
                                if (!_this.visibleSlides) _this.calcVisibleSlides(position)
                                //Get Visible Indexes
                                var visibleIndexes = [];
                                for (var i = 0; i < _this.visibleSlides.length; i++) {
                                        var visIndex = _this.slides.indexOf(_this.visibleSlides[i]) - indexOffset

                                        if (params.loop && visIndex < 0) {
                                                visIndex = _this.slides.length - _this.loopedSlides * 2 + visIndex;
                                        }
                                        if (params.loop && visIndex >= _this.slides.length - _this.loopedSlides * 2) {
                                                visIndex = _this.slides.length - _this.loopedSlides * 2 - visIndex;
                                                visIndex = Math.abs(visIndex)
                                        }
                                        visibleIndexes.push(visIndex)
                                }

                                for (i = 0; i < visibleIndexes.length; i++) {
                                        if (pagers[visibleIndexes[i]]) pagers[visibleIndexes[i]].className += ' ' + params.paginationVisibleClass;
                                }

                                if (params.loop) {
                                        pagers[_this.activeLoopIndex].className += ' ' + params.paginationActiveClass;
                                } else {
                                        pagers[_this.activeIndex].className += ' ' + params.paginationActiveClass;
                                }

                        } else {
                                if (params.loop) {
                                        pagers[_this.activeLoopIndex].className += ' ' + params.paginationActiveClass + ' ' + params.paginationVisibleClass;
                                } else {
                                        pagers[_this.activeIndex].className += ' ' + params.paginationActiveClass + ' ' + params.paginationVisibleClass;
                                }

                        }

                }
                _this.calcVisibleSlides = function (position) {
                        var visibleSlides = [];
                        var _slideLeft = 0,
                                _slideSize = 0,
                                _slideRight = 0;
                        if (isH && _this.wrapperLeft > 0) position = position + _this.wrapperLeft;
                        if (!isH && _this.wrapperTop > 0) position = position + _this.wrapperTop;

                        for (var i = 0; i < _this.slides.length; i++) {
                                _slideLeft += _slideSize;
                                if (params.slidesPerView == 'auto') _slideSize = isH ? _this.h.getWidth(_this.slides[i], true) : _this.h.getHeight(_this.slides[i], true);
                                else _slideSize = slideSize;

                                _slideRight = _slideLeft + _slideSize;
                                var isVisibile = false;
                                if (params.visibilityFullFit) {
                                        if (_slideLeft >= -position && _slideRight <= -position + containerSize) isVisibile = true;
                                        if (_slideLeft <= -position && _slideRight >= -position + containerSize) isVisibile = true;
                                } else {

                                        if (_slideRight > -position && _slideRight <= ((-position + containerSize))) isVisibile = true;
                                        if (_slideLeft >= -position && _slideLeft < ((-position + containerSize))) isVisibile = true;
                                        if (_slideLeft < -position && _slideRight > ((-position + containerSize))) isVisibile = true;
                                }

                                if (isVisibile) visibleSlides.push(_this.slides[i])

                        }
                        if (visibleSlides.length == 0) visibleSlides = [_this.slides[_this.activeIndex]]

                        _this.visibleSlides = visibleSlides;
                }

/*==========================================
        Autoplay
    ============================================*/
                var autoplayTimeoutId = undefined;
                _this.startAutoplay = function () {
                        if (typeof autoplayTimeoutId !== 'undefined') return false;
                        if (!params.autoplay) return;
                        _this.callPlugins('onAutoplayStart');
                        autoplay();
                }
                _this.stopAutoplay = function (internal) {
                        if (autoplayTimeoutId) clearTimeout(autoplayTimeoutId);
                        autoplayTimeoutId = undefined;
                        if (internal && !params.autoplayDisableOnInteraction) {
                                _this.wrapperTransitionEnd(function () {
                                        autoplay();
                                })
                        }
                        _this.callPlugins('onAutoplayStop');
                }

                function autoplay() {
                        autoplayTimeoutId = setTimeout(function () {
                                if (params.loop) {
                                        _this.fixLoop();
                                        _this.swipeNext(true);
                                } else if (!_this.swipeNext(true)) _this.swipeTo(0);
                                _this.wrapperTransitionEnd(function () {
                                        if (typeof autoplayTimeoutId !== 'undefined') autoplay();
                                })
                        }, params.autoplay)
                }
/*==================================================
        Loop
    ====================================================*/
                _this.loopCreated = false;
                _this.removeLoopedSlides = function () {
                        if (_this.loopCreated) {
                                for (var i = 0; i < _this.slides.length; i++) {
                                        if (_this.slides[i].getData('looped') === true) _this.wrapper.removeChild(_this.slides[i]);
                                }
                        }
                }

                _this.createLoop = function () {
                        if (_this.slides.length == 0) return;
                        if (params.slidesPerView == 'auto') {
                                _this.loopedSlides = params.loopedSlides || 1;
                        } else {
                                _this.loopedSlides = params.slidesPerView + params.loopAdditionalSlides;
                        }

                        if (_this.loopedSlides > _this.slides.length) {
                                _this.loopedSlides = _this.slides.length;
                        }

                        var slideFirstHTML = '',
                                slideLastHTML = '',
                                i;
                        var slidesSetFullHTML = '';
/**
                loopedSlides is too large if loopAdditionalSlides are set.
                Need to divide the slides by maximum number of slides existing.
                
                @author        Tomaz Lovrec <tomaz.lovrec@blanc-noir.at>
        */
                        var numSlides = _this.slides.length;
                        var fullSlideSets = Math.floor(_this.loopedSlides / numSlides);
                        var remainderSlides = _this.loopedSlides % numSlides;
                        // assemble full sets of slides
                        for (i = 0; i < (fullSlideSets * numSlides); i++) {
                                var j = i;
                                if (i >= numSlides) {
                                        var over = Math.floor(i / numSlides);
                                        j = i - (numSlides * over);
                                }
                                slidesSetFullHTML += _this.slides[j].outerHTML;
                        }
                        // assemble remainder slides
                        // assemble remainder appended to existing slides
                        for (i = 0; i < remainderSlides; i++) {
                                slideLastHTML += _this.slides[i].outerHTML;
                        }
                        // assemble slides that get preppended to existing slides
                        for (i = numSlides - remainderSlides; i < numSlides; i++) {
                                slideFirstHTML += _this.slides[i].outerHTML;
                        }
                        // assemble all slides
                        var slides = slideFirstHTML + slidesSetFullHTML + wrapper.innerHTML + slidesSetFullHTML + slideLastHTML;
                        // set the slides
                        wrapper.innerHTML = slides;

                        _this.loopCreated = true;
                        _this.calcSlides();

                        //Update Looped Slides with special class
                        for (i = 0; i < _this.slides.length; i++) {
                                if (i < _this.loopedSlides || i >= _this.slides.length - _this.loopedSlides) _this.slides[i].setData('looped', true);
                        }
                        _this.callPlugins('onCreateLoop');

                }

                _this.fixLoop = function () {
                        var newIndex;
                        //Fix For Negative Oversliding
                        if (_this.activeIndex < _this.loopedSlides) {
                                newIndex = _this.slides.length - _this.loopedSlides * 3 + _this.activeIndex;
                                _this.swipeTo(newIndex, 0, false);
                        }
                        //Fix For Positive Oversliding
                        else if (_this.activeIndex > _this.slides.length - params.slidesPerView * 2) {
                                newIndex = -_this.slides.length + _this.activeIndex + _this.loopedSlides
                                _this.swipeTo(newIndex, 0, false);
                        }
                }

/*==================================================
        Slides Loader
    ====================================================*/
                _this.loadSlides = function () {
                        var slidesHTML = '';
                        _this.activeLoaderIndex = 0;
                        var slides = params.loader.slides;
                        var slidesToLoad = params.loader.loadAllSlides ? slides.length : params.slidesPerView * (1 + params.loader.surroundGroups);
                        for (var i = 0; i < slidesToLoad; i++) {
                                if (params.loader.slidesHTMLType == 'outer') slidesHTML += slides[i];
                                else {
                                        slidesHTML += '<' + params.slideElement + ' class="' + params.slideClass + '" data-swiperindex="' + i + '">' + slides[i] + '</' + params.slideElement + '>';
                                }
                        }
                        _this.wrapper.innerHTML = slidesHTML;
                        _this.calcSlides(true);
                        //Add permanent transitionEnd callback
                        if (!params.loader.loadAllSlides) {
                                _this.wrapperTransitionEnd(_this.reloadSlides, true);
                        }
                }

                _this.reloadSlides = function () {
                        var slides = params.loader.slides;
                        var newActiveIndex = parseInt(_this.activeSlide().data('swiperindex'), 10)
                        if (newActiveIndex < 0 || newActiveIndex > slides.length - 1) return //<-- Exit
                        _this.activeLoaderIndex = newActiveIndex;
                        var firstIndex = Math.max(0, newActiveIndex - params.slidesPerView * params.loader.surroundGroups)
                        var lastIndex = Math.min(newActiveIndex + params.slidesPerView * (1 + params.loader.surroundGroups) - 1, slides.length - 1)
                        //Update Transforms
                        if (newActiveIndex > 0) {
                                var newTransform = -slideSize * (newActiveIndex - firstIndex)
                                _this.setWrapperTranslate(newTransform);
                                _this.setWrapperTransition(0);
                        }
                        //New Slides
                        if (params.loader.logic === 'reload') {
                                _this.wrapper.innerHTML = '';
                                var slidesHTML = '';
                                for (var i = firstIndex; i <= lastIndex; i++) {
                                        slidesHTML += params.loader.slidesHTMLType == 'outer' ? slides[i] : '<' + params.slideElement + ' class="' + params.slideClass + '" data-swiperindex="' + i + '">' + slides[i] + '</' + params.slideElement + '>';
                                }
                                _this.wrapper.innerHTML = slidesHTML;
                        } else {
                                var minExistIndex = 1000;
                                var maxExistIndex = 0;
                                for (var i = 0; i < _this.slides.length; i++) {
                                        var index = _this.slides[i].data('swiperindex');
                                        if (index < firstIndex || index > lastIndex) {
                                                _this.wrapper.removeChild(_this.slides[i]);
                                        } else {
                                                minExistIndex = Math.min(index, minExistIndex)
                                                maxExistIndex = Math.max(index, maxExistIndex)
                                        }
                                }
                                for (var i = firstIndex; i <= lastIndex; i++) {
                                        if (i < minExistIndex) {
                                                var newSlide = document.createElement(params.slideElement);
                                                newSlide.className = params.slideClass;
                                                newSlide.setAttribute('data-swiperindex', i);
                                                newSlide.innerHTML = slides[i];
                                                _this.wrapper.insertBefore(newSlide, _this.wrapper.firstChild);
                                        }
                                        if (i > maxExistIndex) {
                                                var newSlide = document.createElement(params.slideElement);
                                                newSlide.className = params.slideClass;
                                                newSlide.setAttribute('data-swiperindex', i);
                                                newSlide.innerHTML = slides[i];
                                                _this.wrapper.appendChild(newSlide);
                                        }
                                }
                        }
                        //reInit
                        _this.reInit(true);
                }

/*==================================================
        Make Swiper
    ====================================================*/

                function makeSwiper() {
                        _this.calcSlides();
                        if (params.loader.slides.length > 0 && _this.slides.length == 0) {
                                _this.loadSlides();
                        }
                        if (params.loop) {
                                _this.createLoop();
                        }
                        _this.init();
                        initEvents();
                        if (params.pagination) {
                                _this.createPagination(true);
                        }

                        if (params.loop || params.initialSlide > 0) {
                                _this.swipeTo(params.initialSlide, 0, false);
                        } else {
                                _this.updateActiveSlide(0);
                        }
                        if (params.autoplay) {
                                _this.startAutoplay();
                        }
                        /**
                         * Set center slide index.
                         * 
                         * @author        Tomaz Lovrec <tomaz.lovrec@gmail.com> 
                         */
                        _this.centerIndex = _this.activeIndex;

                        // Callbacks
                        if (params.onSwiperCreated) _this.fireCallback(params.onSwiperCreated, _this);
                        _this.callPlugins('onSwiperCreated');
                }

                makeSwiper();
        }

Swiper.prototype = {
        plugins: {},

/*==================================================
        Wrapper Operations
    ====================================================*/
        wrapperTransitionEnd: function (callback, permanent) {
                var a = this,
                        el = a.wrapper,
                        events = ['webkitTransitionEnd', 'transitionend', 'oTransitionEnd', 'MSTransitionEnd', 'msTransitionEnd'],
                        i;

                function fireCallBack() {
                        callback(a);
                        if (a.params.queueEndCallbacks) a._queueEndCallbacks = false;
                        if (!permanent) {
                                for (i = 0; i < events.length; i++) {
                                        a.h.removeEventListener(el, events[i], fireCallBack);
                                }
                        }
                }

                if (callback) {
                        for (i = 0; i < events.length; i++) {
                                a.h.addEventListener(el, events[i], fireCallBack);
                        }
                }
        },

        getWrapperTranslate: function (axis) {
                var el = this.wrapper,
                        matrix, curTransform, curStyle, transformMatrix;

                // automatic axis detection
                if (typeof axis == 'undefined') {
                        axis = this.params.mode == 'horizontal' ? 'x' : 'y';
                }

                if (this.support.transforms && this.params.useCSS3Transforms) {
                        curStyle = window.getComputedStyle(el, null);
                        if (window.WebKitCSSMatrix) {
                                transformMatrix = new WebKitCSSMatrix(curStyle.webkitTransform);
                        } else {
                                transformMatrix = curStyle.MozTransform || curStyle.OTransform || curStyle.MsTransform || curStyle.msTransform || curStyle.transform || curStyle.getPropertyValue("transform").replace("translate(", "matrix(1, 0, 0, 1,");
                                matrix = transformMatrix.toString().split(',');
                        }

                        if (axis == 'x') {
                                //Latest Chrome and webkits Fix
                                if (window.WebKitCSSMatrix) curTransform = transformMatrix.m41;
                                //Crazy IE10 Matrix
                                else if (matrix.length == 16) curTransform = parseFloat(matrix[12]);
                                //Normal Browsers
                                else curTransform = parseFloat(matrix[4]);
                        }
                        if (axis == 'y') {
                                //Latest Chrome and webkits Fix
                                if (window.WebKitCSSMatrix) curTransform = transformMatrix.m42;
                                //Crazy IE10 Matrix
                                else if (matrix.length == 16) curTransform = parseFloat(matrix[13]);
                                //Normal Browsers
                                else curTransform = parseFloat(matrix[5]);
                        }
                } else {
                        if (axis == 'x') curTransform = parseFloat(el.style.left, 10) || 0;
                        if (axis == 'y') curTransform = parseFloat(el.style.top, 10) || 0;
                }
                return curTransform || 0;
        },

        setWrapperTranslate: function (x, y, z) {
                var es = this.wrapper.style,
                        coords = {
                                x: 0,
                                y: 0,
                                z: 0
                        },
                        translate;

                // passed all coordinates
                if (arguments.length == 3) {
                        coords.x = x;
                        coords.y = y;
                        coords.z = z;
                }

                // passed one coordinate and optional axis
                else {
                        if (typeof y == 'undefined') {
                                y = this.params.mode == 'horizontal' ? 'x' : 'y';
                        }
                        coords[y] = x;
                }

                if (this.support.transforms && this.params.useCSS3Transforms) {
                        translate = this.support.transforms3d ? 'translate3d(' + coords.x + 'px, ' + coords.y + 'px, ' + coords.z + 'px)' : 'translate(' + coords.x + 'px, ' + coords.y + 'px)';
                        es.webkitTransform = es.MsTransform = es.msTransform = es.MozTransform = es.OTransform = es.transform = translate;
                } else {
                        es.left = coords.x + 'px';
                        es.top = coords.y + 'px';
                }
                this.callPlugins('onSetWrapperTransform', coords);
                if (this.params.onSetWrapperTransform) this.fireCallback(this.params.onSetWrapperTransform, this, coords);
        },

        setWrapperTransition: function (duration) {
                var es = this.wrapper.style;
                es.webkitTransitionDuration = es.MsTransitionDuration = es.msTransitionDuration = es.MozTransitionDuration = es.OTransitionDuration = es.transitionDuration = (duration / 1000) + 's';
                this.callPlugins('onSetWrapperTransition', {
                        duration: duration
                });
                if (this.params.onSetWrapperTransition) this.fireCallback(this.params.onSetWrapperTransition, this, duration);

        },

/*==================================================
        Helpers
    ====================================================*/
        h: {
                getWidth: function (el, outer) {
                        var width = window.getComputedStyle(el, null).getPropertyValue('width')
                        var returnWidth = parseFloat(width);
                        //IE Fixes
                        if (isNaN(returnWidth) || width.indexOf('%') > 0) {
                                returnWidth = el.offsetWidth - parseFloat(window.getComputedStyle(el, null).getPropertyValue('padding-left')) - parseFloat(window.getComputedStyle(el, null).getPropertyValue('padding-right'));
                        }
                        if (outer) returnWidth += parseFloat(window.getComputedStyle(el, null).getPropertyValue('padding-left')) + parseFloat(window.getComputedStyle(el, null).getPropertyValue('padding-right'))

                        return returnWidth;
                },
                getHeight: function (el, outer) {
                        if (outer) return el.offsetHeight;

                        var height = window.getComputedStyle(el, null).getPropertyValue('height')
                        var returnHeight = parseFloat(height);
                        //IE Fixes
                        if (isNaN(returnHeight) || height.indexOf('%') > 0) {
                                returnHeight = el.offsetHeight - parseFloat(window.getComputedStyle(el, null).getPropertyValue('padding-top')) - parseFloat(window.getComputedStyle(el, null).getPropertyValue('padding-bottom'));
                        }
                        if (outer) returnHeight += parseFloat(window.getComputedStyle(el, null).getPropertyValue('padding-top')) + parseFloat(window.getComputedStyle(el, null).getPropertyValue('padding-bottom'))
                        return returnHeight;
                },
                getOffset: function (el) {
                        var box = el.getBoundingClientRect();
                        var body = document.body;
                        var clientTop = el.clientTop || body.clientTop || 0;
                        var clientLeft = el.clientLeft || body.clientLeft || 0;
                        var scrollTop = window.pageYOffset || el.scrollTop;
                        var scrollLeft = window.pageXOffset || el.scrollLeft;
                        if (document.documentElement && !window.pageYOffset) {
                                //IE7-8
                                scrollTop = document.documentElement.scrollTop;
                                scrollLeft = document.documentElement.scrollLeft;
                        }
                        return {
                                top: box.top + scrollTop - clientTop,
                                left: box.left + scrollLeft - clientLeft
                        };
                },
                windowWidth: function () {
                        if (window.innerWidth) return window.innerWidth
                        else if (document.documentElement && document.documentElement.clientWidth) return document.documentElement.clientWidth;
                },
                windowHeight: function () {
                        if (window.innerHeight) return window.innerHeight
                        else if (document.documentElement && document.documentElement.clientHeight) return document.documentElement.clientHeight;
                },
                windowScroll: function () {
                        var left = 0,
                                top = 0;
                        if (typeof pageYOffset != 'undefined') {
                                return {
                                        left: window.pageXOffset,
                                        top: window.pageYOffset
                                }
                        } else if (document.documentElement) {
                                return {
                                        left: document.documentElement.scrollLeft,
                                        top: document.documentElement.scrollTop
                                }
                        }
                },

                addEventListener: function (el, event, listener, useCapture) {
                        if (typeof useCapture == 'undefined') {
                                useCapture = false;
                        }

                        if (el.addEventListener) {
                                el.addEventListener(event, listener, useCapture);
                        } else if (el.attachEvent) {
                                el.attachEvent('on' + event, listener);
                        }
                },

                removeEventListener: function (el, event, listener, useCapture) {
                        if (typeof useCapture == 'undefined') {
                                useCapture = false;
                        }

                        if (el.removeEventListener) {
                                el.removeEventListener(event, listener, useCapture);
                        } else if (el.detachEvent) {
                                el.detachEvent('on' + event, listener);
                        }
                }
        },
        setTransform: function (el, transform) {
                var es = el.style
                es.webkitTransform = es.MsTransform = es.msTransform = es.MozTransform = es.OTransform = es.transform = transform
        },
        setTranslate: function (el, translate) {
                var es = el.style
                var pos = {
                        x: translate.x || 0,
                        y: translate.y || 0,
                        z: translate.z || 0
                };
                var transformString = this.support.transforms3d ? 'translate3d(' + (pos.x) + 'px,' + (pos.y) + 'px,' + (pos.z) + 'px)' : 'translate(' + (pos.x) + 'px,' + (pos.y) + 'px)';
                es.webkitTransform = es.MsTransform = es.msTransform = es.MozTransform = es.OTransform = es.transform = transformString;
                if (!this.support.transforms) {
                        es.left = pos.x + 'px'
                        es.top = pos.y + 'px'
                }
        },
        setTransition: function (el, duration) {
                var es = el.style
                es.webkitTransitionDuration = es.MsTransitionDuration = es.msTransitionDuration = es.MozTransitionDuration = es.OTransitionDuration = es.transitionDuration = duration + 'ms';
        },
/*==================================================
        Feature Detection
    ====================================================*/
        support: {

                touch: (window.Modernizr && Modernizr.touch === true) || (function () {
                        return !!(("ontouchstart" in window) || window.DocumentTouch && document instanceof DocumentTouch);
                })(),

                transforms3d: (window.Modernizr && Modernizr.csstransforms3d === true) || (function () {
                        var div = document.createElement('div').style;
                        return ("webkitPerspective" in div || "MozPerspective" in div || "OPerspective" in div || "MsPerspective" in div || "perspective" in div);
                })(),

                transforms: (window.Modernizr && Modernizr.csstransforms === true) || (function () {
                        var div = document.createElement('div').style;
                        return ('transform' in div || 'WebkitTransform' in div || 'MozTransform' in div || 'msTransform' in div || 'MsTransform' in div || 'OTransform' in div);
                })(),

                transitions: (window.Modernizr && Modernizr.csstransitions === true) || (function () {
                        var div = document.createElement('div').style;
                        return ('transition' in div || 'WebkitTransition' in div || 'MozTransition' in div || 'msTransition' in div || 'MsTransition' in div || 'OTransition' in div);
                })()
        },

        browser: {

                ie8: (function () {
                        var rv = -1; // Return value assumes failure.
                        if (navigator.appName == 'Microsoft Internet Explorer') {
                                var ua = navigator.userAgent;
                                var re = new RegExp("MSIE ([0-9]{1,}[\.0-9]{0,})");
                                if (re.exec(ua) != null) rv = parseFloat(RegExp.$1);
                        }
                        return rv != -1 && rv < 9;
                })(),

                ie10: window.navigator.msPointerEnabled
        }
}

/*=========================
  jQuery & Zepto Plugins
  ===========================*/
if (window.jQuery || window.Zepto) {
        (function ($) {
                $.fn.swiper = function (params) {
                        var s = new Swiper($(this)[0], params)
                        $(this).data('swiper', s);
                        return s;
                }
        })(window.jQuery || window.Zepto)
}

// component
if (typeof (module) !== 'undefined') {
        module.exports = Swiper;
}





























/*! Copyright (c) 2011 Brandon Aaron (http://brandonaaron.net)
 * Licensed under the MIT License (LICENSE.txt).
 *
 * Thanks to: http://adomas.org/javascript-mouse-wheel/ for some pointers.
 * Thanks to: Mathias Bank(http://www.mathias-bank.de) for a scope bug fix.
 * Thanks to: Seamus Leahy for adding deltaX and deltaY
 *
 * Version: 3.0.6
 * 
 * Requires: 1.2.2+
 */

(function ($) {

        var types = ['DOMMouseScroll', 'mousewheel'];

        if ($.event.fixHooks) {
                for (var i = types.length; i;) {
                        $.event.fixHooks[types[--i]] = $.event.mouseHooks;
                }
        }

        $.event.special.mousewheel = {
                setup: function () {
                        if (this.addEventListener) {
                                for (var i = types.length; i;) {
                                        this.addEventListener(types[--i], handler, false);
                                }
                        } else {
                                this.onmousewheel = handler;
                        }
                },

                teardown: function () {
                        if (this.removeEventListener) {
                                for (var i = types.length; i;) {
                                        this.removeEventListener(types[--i], handler, false);
                                }
                        } else {
                                this.onmousewheel = null;
                        }
                }
        };

        $.fn.extend({
                mousewheel: function (fn) {
                        return fn ? this.bind("mousewheel", fn) : this.trigger("mousewheel");
                },

                unmousewheel: function (fn) {
                        return this.unbind("mousewheel", fn);
                }
        });


        function handler(event) {
                var orgEvent = event || window.event,
                        args = [].slice.call(arguments, 1),
                        delta = 0,
                        returnValue = true,
                        deltaX = 0,
                        deltaY = 0;
                event = $.event.fix(orgEvent);
                event.type = "mousewheel";

                // Old school scrollwheel delta
                if (orgEvent.wheelDelta) {
                        delta = orgEvent.wheelDelta / 120;
                }
                if (orgEvent.detail) {
                        delta = -orgEvent.detail / 3;
                }

                // New school multidimensional scroll (touchpads) deltas
                deltaY = delta;

                // Gecko
                if (orgEvent.axis !== undefined && orgEvent.axis === orgEvent.HORIZONTAL_AXIS) {
                        deltaY = 0;
                        deltaX = -1 * delta;
                }

                // Webkit
                if (orgEvent.wheelDeltaY !== undefined) {
                        deltaY = orgEvent.wheelDeltaY / 120;
                }
                if (orgEvent.wheelDeltaX !== undefined) {
                        deltaX = -1 * orgEvent.wheelDeltaX / 120;
                }

                // Add event and delta to the front of the arguments
                args.unshift(event, delta, deltaX, deltaY);

                return ($.event.dispatch || $.event.handle).apply(this, args);
        }

})(jQuery);



(function ($, window, undefined) {
        // http://paulirish.com/2011/requestanimationframe-for-smart-animating/
        // http://my.opera.com/emoller/blog/2011/12/20/requestanimationframe-for-smart-er-animating
        // requestAnimationFrame polyfill by Erik Möller
        // fixes from Paul Irish and Tino Zijdel
        var lastTime = 0,
                running, animate = function (elem) {
                        if (running) {
                                window.requestAnimationFrame(animate, elem);
                                jQuery.fx.tick();
                        }
                },
                vendors = ['ms', 'moz', 'webkit', 'o'];

        for (var x = 0; x < vendors.length && !window.requestAnimationFrame; ++x) {
                window.requestAnimationFrame = window[vendors[x] + 'RequestAnimationFrame'];
                window.cancelAnimationFrame = window[vendors[x] + 'CancelAnimationFrame'] || window[vendors[x] + 'CancelRequestAnimationFrame'];
        }

        if (!window.requestAnimationFrame) window.requestAnimationFrame = function (fn, element) {
                var currTime = new Date().getTime(),
                        delta = currTime - lastTime,
                        timeToCall = Math.max(0, 16 - delta);

                var id = window.setTimeout(function () {
                        fn(currTime + timeToCall);
                }, timeToCall);

                lastTime = currTime + timeToCall;

                return id;
        };

        if (!window.cancelAnimationFrame) {
                window.cancelAnimationFrame = function (id) {
                        clearTimeout(id);
                };
        }

        jQuery.fx.timer = function (timer) {
                if (timer() && jQuery.timers.push(timer) && !running) {
                        running = true;
                        animate(timer.elem);
                }
        };

        jQuery.fx.stop = function () {
                running = false;
        };

}(jQuery, this));




// Stackblur, courtesy of Mario Klingemann: http://www.quasimondo.com/StackBlurForCanvas/StackBlurDemo.html
(function (l) {
        l.fn.blurjs = function (e) {
                function O() {
                        this.a = this.b = this.g = this.r = 0;
                        this.next = null
                }
                var y = document.createElement("canvas"),
                        P = !1,
                        H = l(this).selector.replace(/[^a-zA-Z0-9]/g, "");
                if (y.getContext) {
                        var e = l.extend({
                                source: "body",
                                radius: 5,
                                overlay: "",
                                offset: {
                                        x: 0,
                                        y: 0
                                },
                                optClass: "",
                                cache: !1,
                                cacheKeyPrefix: "blurjs-",
                                draggable: !1,
                                debug: !1
                        }, e),
                                R = [512, 512, 456, 512, 328, 456, 335, 512, 405, 328, 271, 456, 388, 335, 292, 512, 454, 405, 364, 328, 298, 271, 496, 456, 420, 388, 360, 335, 312, 292, 273, 512, 482, 454, 428, 405, 383, 364, 345, 328, 312, 298, 284, 271, 259, 496, 475, 456, 437, 420, 404, 388, 374, 360, 347, 335, 323, 312, 302, 292, 282, 273, 265, 512, 497, 482, 468, 454, 441, 428, 417, 405, 394, 383, 373, 364, 354, 345, 337, 328, 320, 312, 305, 298, 291, 284, 278, 271, 265, 259, 507, 496, 485, 475, 465, 456, 446, 437, 428, 420, 412, 404, 396, 388, 381, 374, 367, 360, 354, 347, 341, 335, 329, 323, 318, 312, 307, 302, 297, 292, 287, 282, 278, 273, 269, 265, 261, 512, 505, 497, 489, 482, 475, 468, 461, 454, 447, 441, 435, 428, 422, 417, 411, 405, 399, 394, 389, 383, 378, 373, 368, 364, 359, 354, 350, 345, 341, 337, 332, 328, 324, 320, 316, 312, 309, 305, 301, 298, 294, 291, 287, 284, 281, 278, 274, 271, 268, 265, 262, 259, 257, 507, 501, 496, 491, 485, 480, 475, 470, 465, 460, 456, 451, 446, 442, 437, 433, 428, 424, 420, 416, 412, 408, 404, 400, 396, 392, 388, 385, 381, 377, 374, 370, 367, 363, 360, 357, 354, 350, 347, 344, 341, 338, 335, 332, 329, 326, 323, 320, 318, 315, 312, 310, 307, 304, 302, 299, 297, 294, 292, 289, 287, 285, 282, 280, 278, 275, 273, 271, 269, 267, 265, 263, 261, 259],
                                S = [9, 11, 12, 13, 13, 14, 14, 15, 15, 15, 15, 16, 16, 16, 16, 17, 17, 17, 17, 17, 17, 17, 18, 18, 18, 18, 18, 18, 18, 18, 18, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 19, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 21, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 22, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 23, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24, 24];
                        return this.each(function () {
                                var A = l(this),
                                        I = l(e.source),
                                        B = I.css("backgroundImage").replace(/"/g, "").replace(/url\(|\)$/ig, "");
                                ctx = y.getContext("2d");
                                tempImg = new Image;
                                tempImg.onload = function () {
                                        if (P) j = tempImg.src;
                                        else {
                                                y.style.display = "none";
                                                y.width = tempImg.width;
                                                y.height = tempImg.height;
                                                ctx.drawImage(tempImg, 0, 0);
                                                var j = y.width,
                                                        q = y.height,
                                                        k = e.radius;
                                                if (!(isNaN(k) || 1 > k)) {
                                                        var k = k | 0,
                                                                M = y.getContext("2d"),
                                                                l;
                                                        try {
                                                                try {
                                                                        l = M.getImageData(0, 0, j, q)
                                                                } catch (L) {
                                                                        try {
                                                                                netscape.security.PrivilegeManager.enablePrivilege("UniversalBrowserRead"), l = M.getImageData(0, 0, j, q)
                                                                        } catch (T) {
                                                                                throw alert("Cannot access local image"), Error("unable to access local image data: " + T);
                                                                        }
                                                                }
                                                        } catch (U) {
                                                                throw alert("Cannot access image"), Error("unable to access image data: " + U);
                                                        }
                                                        var c = l.data,
                                                                u, z, a, d, f, J, g, h, i, v, w, x, m, n, o, r, s, t, C;
                                                        u = k + k + 1;
                                                        var K = j - 1,
                                                                N = q - 1,
                                                                p = k + 1,
                                                                D = p * (p + 1) / 2,
                                                                E = new O,
                                                                b = E;
                                                        for (a = 1; a < u; a++) if (b = b.next = new O, a == p) var Q = b;
                                                        b.next = E;
                                                        b = a = null;
                                                        J = f = 0;
                                                        var F = R[k],
                                                                G = S[k];
                                                        for (z = 0; z < q; z++) {
                                                                m = n = o = g = h = i = 0;
                                                                v = p * (r = c[f]);
                                                                w = p * (s = c[f + 1]);
                                                                x = p * (t = c[f + 2]);
                                                                g += D * r;
                                                                h += D * s;
                                                                i += D * t;
                                                                b = E;
                                                                for (a = 0; a < p; a++) b.r = r, b.g = s, b.b = t, b = b.next;
                                                                for (a = 1; a < p; a++) d = f + ((K < a ? K : a) << 2), g += (b.r = r = c[d]) * (C = p - a), h += (b.g = s = c[d + 1]) * C, i += (b.b = t = c[d + 2]) * C, m += r, n += s, o += t, b = b.next;
                                                                a = E;
                                                                b = Q;
                                                                for (u = 0; u < j; u++) c[f] = g * F >> G, c[f + 1] = h * F >> G, c[f + 2] = i * F >> G, g -= v, h -= w, i -= x, v -= a.r, w -= a.g, x -= a.b, d = J + ((d = u + k + 1) < K ? d : K) << 2, m += a.r = c[d], n += a.g = c[d + 1], o += a.b = c[d + 2], g += m, h += n, i += o, a = a.next, v += r = b.r, w += s = b.g, x += t = b.b, m -= r, n -= s, o -= t, b = b.next, f += 4;
                                                                J += j
                                                        }
                                                        for (u = 0; u < j; u++) {
                                                                n = o = m = h = i = g = 0;
                                                                f = u << 2;
                                                                v = p * (r = c[f]);
                                                                w = p * (s = c[f + 1]);
                                                                x = p * (t = c[f + 2]);
                                                                g += D * r;
                                                                h += D * s;
                                                                i += D * t;
                                                                b = E;
                                                                for (a = 0; a < p; a++) b.r = r, b.g = s, b.b = t, b = b.next;
                                                                d = j;
                                                                for (a = 1; a <= k; a++) f = d + u << 2, g += (b.r = r = c[f]) * (C = p - a), h += (b.g = s = c[f + 1]) * C, i += (b.b = t = c[f + 2]) * C, m += r, n += s, o += t, b = b.next, a < N && (d += j);
                                                                f = u;
                                                                a = E;
                                                                b = Q;
                                                                for (z = 0; z < q; z++) d = f << 2, c[d] = g * F >> G, c[d + 1] = h * F >> G, c[d + 2] = i * F >> G, g -= v, h -= w, i -= x, v -= a.r, w -= a.g, x -= a.b, d = u + ((d = z + p) < N ? d : N) * j << 2, g += m += a.r = c[d], h += n += a.g = c[d + 1], i += o += a.b = c[d + 2], a = a.next, v += r = b.r, w += s = b.g, x += t = b.b, m -= r, n -= s, o -= t, b = b.next, f += j
                                                        }
                                                        M.putImageData(l, 0, 0)
                                                }
                                                if (!1 != e.overlay) ctx.beginPath(), ctx.rect(0, 0, tempImg.width, tempImg.width), ctx.fillStyle = e.overlay, ctx.fill();
                                                var j = y.toDataURL();
                                                if (e.cache) try {
                                                        e.debug && console.log("Cache Set"), localStorage.setItem(e.cacheKeyPrefix + H + "-" + B + "-data-image", j)
                                                } catch (V) {
                                                        console.log(V)
                                                }
                                        }
                                        q = I.css("backgroundAttachment");
                                        k = "fixed" == q ? "" : "-" + (A.offset().left - I.offset().left - e.offset.x) + "px -" + (A.offset().top - I.offset().top - e.offset.y) + "px";
                                        A.css({
                                                "background-image": 'url("' + j + '")',
                                                "background-repeat": I.css("backgroundRepeat"),
                                                "background-position": k,
                                                "background-attachment": q
                                        });
                                        !1 != e.optClass && A.addClass(e.optClass);
                                        e.draggable && (A.css({
                                                "background-attachment": "fixed",
                                                "background-position": "0 0"
                                        }), A.draggable())
                                };
                                Storage.prototype.cacheChecksum = function (j) {
                                        var q = "",
                                                k;
                                        for (k in j) var l = j[k],
                                                q = "[object Object]" == l.toString() ? q + (l.x.toString() + l.y.toString() + ",").replace(/[^a-zA-Z0-9]/g, "") : q + (l + ",").replace(/[^a-zA-Z0-9]/g, "");
                                        this.getItem(e.cacheKeyPrefix + H + "-" + B + "-options-cache") != q && (this.removeItem(e.cacheKeyPrefix + H + "-" + B + "-options-cache"), this.setItem(e.cacheKeyPrefix + H + "-" + B + "-options-cache", q), e.debug && console.log("Settings Changed, Cache Emptied"))
                                };
                                var L = null;
                                e.cache && (localStorage.cacheChecksum(e), L = localStorage.getItem(e.cacheKeyPrefix + H + "-" + B + "-data-image"));
                                null != L ? (e.debug && console.log("Cache Used"), P = !0, tempImg.src = L) : (e.debug && console.log("Source Used"), tempImg.src = B)
                        })
                }
        }
})(jQuery);



























/*jshint undef: true */
/*global jQuery: true */

/*
   --------------------------------
   Infinite Scroll
   --------------------------------
   + https://github.com/paulirish/infinite-scroll
   + version 2.0b2.120519
   + Copyright 2011/12 Paul Irish & Luke Shumard
   + Licensed under the MIT license

   + Documentation: http://infinite-scroll.com/
*/

(function (e, t, n) {
        "use strict";
        t.infinitescroll = function (n, r, i) {
                this.element = t(i);
                if (!this._create(n, r)) {
                        this.failed = true
                }
        };
        t.infinitescroll.defaults = {
                loading: {
                        finished: n,
                        finishedMsg: "<em>Congratulations, you've reached the end of the internet.</em>",
                        img: "data:image/gif;base64,R0lGODlh3AATAPQeAPDy+MnQ6LW/4N3h8MzT6rjC4sTM5r/I5NHX7N7j8c7U6tvg8OLl8uXo9Ojr9b3G5MfP6Ovu9tPZ7PT1+vX2+tbb7vf4+8/W69jd7rC73vn5/O/x+K243ai02////wAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQECgD/ACwAAAAA3AATAAAF/6AnjmRpnmiqrmzrvnAsz3Rt33iu73zv/8CgcEj0BAScpHLJbDqf0Kh0Sq1ar9isdioItAKGw+MAKYMFhbF63CW438f0mg1R2O8EuXj/aOPtaHx7fn96goR4hmuId4qDdX95c4+RBIGCB4yAjpmQhZN0YGYGXitdZBIVGAsLoq4BBKQDswm1CQRkcG6ytrYKubq8vbfAcMK9v7q7EMO1ycrHvsW6zcTKsczNz8HZw9vG3cjTsMIYqQkCLBwHCgsMDQ4RDAYIqfYSFxDxEfz88/X38Onr16+Bp4ADCco7eC8hQYMAEe57yNCew4IVBU7EGNDiRn8Z831cGLHhSIgdFf9chIeBg7oA7gjaWUWTVQAGE3LqBDCTlc9WOHfm7PkTqNCh54rePDqB6M+lR536hCpUqs2gVZM+xbrTqtGoWqdy1emValeXKzggYBBB5y1acFNZmEvXAoN2cGfJrTv3bl69Ffj2xZt3L1+/fw3XRVw4sGDGcR0fJhxZsF3KtBTThZxZ8mLMgC3fRatCbYMNFCzwLEqLgE4NsDWs/tvqdezZf13Hvk2A9Szdu2X3pg18N+68xXn7rh1c+PLksI/Dhe6cuO3ow3NfV92bdArTqC2Ebd3A8vjf5QWfH6Bg7Nz17c2fj69+fnq+8N2Lty+fuP78/eV2X13neIcCeBRwxorbZrA1ANoCDGrgoG8RTshahQ9iSKEEzUmYIYfNWViUhheCGJyIP5E4oom7WWjgCeBFAJNv1DVV01MAdJhhjdkplWNzO/5oXI846njjVEIqR2OS2B1pE5PVscajkxhMycqLJghQSwT40PgfAl4GqNSXYdZXJn5gSkmmmmJu1aZYb14V51do+pTOCmA40AqVCIhG5IJ9PvYnhIFOxmdqhpaI6GeHCtpooisuutmg+Eg62KOMKuqoTaXgicQWoIYq6qiklmoqFV0UoeqqrLbq6quwxirrrLTWauutJ4QAACH5BAUKABwALAcABADOAAsAAAX/IPd0D2dyRCoUp/k8gpHOKtseR9yiSmGbuBykler9XLAhkbDavXTL5k2oqFqNOxzUZPU5YYZd1XsD72rZpBjbeh52mSNnMSC8lwblKZGwi+0QfIJ8CncnCoCDgoVnBHmKfByGJimPkIwtiAeBkH6ZHJaKmCeVnKKTHIihg5KNq4uoqmEtcRUtEREMBggtEr4QDrjCuRC8h7/BwxENeicSF8DKy82pyNLMOxzWygzFmdvD2L3P0dze4+Xh1Arkyepi7dfFvvTtLQkZBC0T/FX3CRgCMOBHsJ+EHYQY7OinAGECgQsB+Lu3AOK+CewcWjwxQeJBihtNGHSoQOE+iQ3//4XkwBBhRZMcUS6YSXOAwIL8PGqEaSJCiYt9SNoCmnJPAgUVLChdaoFBURN8MAzl2PQphwQLfDFd6lTowglHve6rKpbjhK7/pG5VinZP1qkiz1rl4+tr2LRwWU64cFEihwEtZgbgR1UiHaMVvxpOSwBA37kzGz9e8G+B5MIEKLutOGEsAH2ATQwYfTmuX8aETWdGPZmiZcccNSzeTCA1Sw0bdiitC7LBWgu8jQr8HRzqgpK6gX88QbrB14z/kF+ELpwB8eVQj/JkqdylAudji/+ts3039vEEfK8Vz2dlvxZKG0CmbkKDBvllRd6fCzDvBLKBDSCeffhRJEFebFk1k/Mv9jVIoIJZSeBggwUaNeB+Qk34IE0cXlihcfRxkOAJFFhwGmKlmWDiakZhUJtnLBpnWWcnKaAZcxI0piFGGLBm1mc90kajSCveeBVWKeYEoU2wqeaQi0PetoE+rr14EpVC7oAbAUHqhYExbn2XHHsVqbcVew9tx8+XJKk5AZsqqdlddGpqAKdbAYBn1pcczmSTdWvdmZ17c1b3FZ99vnTdCRFM8OEcAhLwm1NdXnWcBBSMRWmfkWZqVlsmLIiAp/o1gGV2vpS4lalGYsUOqXrddcKCmK61aZ8SjEpUpVFVoCpTj4r661Km7kBHjrDyc1RAIQAAIfkEBQoAGwAsBwAEAM4ACwAABf/gtmUCd4goQQgFKj6PYKi0yrrbc8i4ohQt12EHcal+MNSQiCP8gigdz7iCioaCIvUmZLp8QBzW0EN2vSlCuDtFKaq4RyHzQLEKZNdiQDhRDVooCwkbfm59EAmKi4SGIm+AjIsKjhsqB4mSjT2IOIOUnICeCaB/mZKFNTSRmqVpmJqklSqskq6PfYYCDwYHDC4REQwGCBLGxxIQDsHMwhAIX8bKzcENgSLGF9PU1j3Sy9zX2NrgzQziChLk1BHWxcjf7N046tvN82715czn9Pryz6Ilc4ACj4EBOCZM8KEnAYYADBRKnACAYUMFv1wotIhCEcaJCisqwJFgAUSQGyX/kCSVUUTIdKMwJlyo0oXHlhskwrTJciZHEXsgaqS4s6PJiCAr1uzYU8kBBSgnWFqpoMJMUjGtDmUwkmfVmVypakWhEKvXsS4nhLW5wNjVroJIoc05wSzTr0PtiigpYe4EC2vj4iWrFu5euWIMRBhacaVJhYQBEFjA9jHjyQ0xEABwGceGAZYjY0YBOrRLCxUp29QM+bRkx5s7ZyYgVbTqwwti2ybJ+vLtDYpycyZbYOlptxdx0kV+V7lC5iJAyyRrwYKxAdiz82ng0/jnAdMJFz0cPi104Ec1Vj9/M6F173vKL/feXv156dw11tlqeMMnv4V5Ap53GmjQQH97nFfg+IFiucfgRX5Z8KAgbUlQ4IULIlghhhdOSB6AgX0IVn8eReghen3NRIBsRgnH4l4LuEidZBjwRpt6NM5WGwoW0KSjCwX6yJSMab2GwwAPDXfaBCtWpluRTQqC5JM5oUZAjUNS+VeOLWpJEQ7VYQANW0INJSZVDFSnZphjSikfmzE5N4EEbQI1QJmnWXCmHulRp2edwDXF43txukenJwvI9xyg9Q26Z3MzGUcBYFEChZh6DVTq34AU8Iflh51Sd+CnKFYQ6mmZkhqfBKfSxZWqA9DZanWjxmhrWwi0qtCrt/43K6WqVjjpmhIqgEGvculaGKklKstAACEAACH5BAUKABwALAcABADOAAsAAAX/ICdyQmaMYyAUqPgIBiHPxNpy79kqRXH8wAPsRmDdXpAWgWdEIYm2llCHqjVHU+jjJkwqBTecwItShMXkEfNWSh8e1NGAcLgpDGlRgk7EJ/6Ae3VKfoF/fDuFhohVeDeCfXkcCQqDVQcQhn+VNDOYmpSWaoqBlUSfmowjEA+iEAEGDRGztAwGCDcXEA60tXEiCrq8vREMEBLIyRLCxMWSHMzExnbRvQ2Sy7vN0zvVtNfU2tLY3rPgLdnDvca4VQS/Cpk3ABwSLQkYAQwT/P309vcI7OvXr94jBQMJ/nskkGA/BQBRLNDncAIAiDcG6LsxAWOLiQzmeURBKWSLCQbv/1F0eDGinJUKR47YY1IEgQASKk7Yc7ACRwZm7mHweRJoz59BJUogisKCUaFMR0x4SlJBVBFTk8pZivTR0K73rN5wqlXEAq5Fy3IYgHbEzQ0nLy4QSoCjXLoom96VOJEeCosK5n4kkFfqXjl94wa+l1gvAcGICbewAOAxY8l/Ky/QhAGz4cUkGxu2HNozhwMGBnCUqUdBg9UuW9eUynqSwLHIBujePef1ZGQZXcM+OFuEBeBhi3OYgLyqcuaxbT9vLkf4SeqyWxSQpKGB2gQpm1KdWbu72rPRzR9Ne2Nu9Kzr/1Jqj0yD/fvqP4aXOt5sW/5qsXXVcv1Nsp8IBUAmgswGF3llGgeU1YVXXKTN1FlhWFXW3gIE+DVChApysACHHo7Q4A35lLichh+ROBmLKAzgYmYEYDAhCgxKGOOMn4WR4kkDaoBBOxJtdNKQxFmg5JIWIBnQc07GaORfUY4AEkdV6jHlCEISSZ5yTXpp1pbGZbkWmcuZmQCaE6iJ0FhjMaDjTMsgZaNEHFRAQVp3bqXnZED1qYcECOz5V6BhSWCoVJQIKuKQi2KFKEkEFAqoAo7uYSmO3jk61wUUMKmknJ4SGimBmAa0qVQBhAAAIfkEBQoAGwAsBwAEAM4ACwAABf/gJm5FmRlEqhJC+bywgK5pO4rHI0D3pii22+Mg6/0Ej96weCMAk7cDkXf7lZTTnrMl7eaYoy10JN0ZFdco0XAuvKI6qkgVFJXYNwjkIBcNBgR8TQoGfRsJCRuCYYQQiI+ICosiCoGOkIiKfSl8mJkHZ4U9kZMbKaI3pKGXmJKrngmug4WwkhA0lrCBWgYFCCMQFwoQDRHGxwwGCBLMzRLEx8iGzMMO0cYNeCMKzBDW19lnF9DXDIY/48Xg093f0Q3s1dcR8OLe8+Y91OTv5wrj7o7B+7VNQqABIoRVCMBggsOHE36kSoCBIcSH3EbFangxogJYFi8CkJhqQciLJEf/LDDJEeJIBT0GsOwYUYJGBS0fjpQAMidGmyVP6sx4Y6VQhzs9VUwkwqaCCh0tmKoFtSMDmBOf9phg4SrVrROuasRQAaxXpVUhdsU6IsECZlvX3kwLUWzRt0BHOLTbNlbZG3vZinArge5Dvn7wbqtQkSYAAgtKmnSsYKVKo2AfW048uaPmG386i4Q8EQMBAIAnfB7xBxBqvapJ9zX9WgRS2YMpnvYMGdPK3aMjt/3dUcNI4blpj7iwkMFWDXDvSmgAlijrt9RTR78+PS6z1uAJZIe93Q8g5zcsWCi/4Y+C8bah5zUv3vv89uft30QP23punGCx5954oBBwnwYaNCDY/wYrsYeggnM9B2Fpf8GG2CEUVWhbWAtGouEGDy7Y4IEJVrbSiXghqGKIo7z1IVcXIkKWWR361QOLWWnIhwERpLaaCCee5iMBGJQmJGyPFTnbkfHVZGRtIGrg5HALEJAZbu39BuUEUmq1JJQIPtZilY5hGeSWsSk52G9XqsmgljdIcABytq13HyIM6RcUA+r1qZ4EBF3WHWB29tBgAzRhEGhig8KmqKFv8SeCeo+mgsF7YFXa1qWSbkDpom/mqR1PmHCqJ3fwNRVXjC7S6CZhFVCQ2lWvZiirhQq42SACt25IK2hv8TprriUV1usGgeka7LFcNmCldMLi6qZMgFLgpw16Cipb7bC1knXsBiEAACH5BAUKABsALAcABADOAAsAAAX/4FZsJPkUmUGsLCEUTywXglFuSg7fW1xAvNWLF6sFFcPb42C8EZCj24EJdCp2yoegWsolS0Uu6fmamg8n8YYcLU2bXSiRaXMGvqV6/KAeJAh8VgZqCX+BexCFioWAYgqNi4qAR4ORhRuHY408jAeUhAmYYiuVlpiflqGZa5CWkzc5fKmbbhIpsAoQDRG8vQwQCBLCwxK6vb5qwhfGxxENahvCEA7NzskSy7vNzzzK09W/PNHF1NvX2dXcN8K55cfh69Luveol3vO8zwi4Yhj+AQwmCBw4IYclDAAJDlQggVOChAoLKkgFkSCAHDwWLKhIEOONARsDKryogFPIiAUb/95gJNIiw4wnI778GFPhzBKFOAq8qLJEhQpiNArjMcHCmlTCUDIouTKBhApELSxFWiGiVKY4E2CAekPgUphDu0742nRrVLJZnyrFSqKQ2ohoSYAMW6IoDpNJ4bLdILTnAj8KUF7UeENjAKuDyxIgOuGiOI0EBBMgLNew5AUrDTMGsFixwBIaNCQuAXJB57qNJ2OWm2Aj4skwCQCIyNkhhtMkdsIuodE0AN4LJDRgfLPtn5YDLdBlraAByuUbBgxQwICxMOnYpVOPej074OFdlfc0TqC62OIbcppHjV4o+LrieWhfT8JC/I/T6W8oCl29vQ0XjLdBaA3s1RcPBO7lFvpX8BVoG4O5jTXRQRDuJ6FDTzEWF1/BCZhgbyAKE9qICYLloQYOFtahVRsWYlZ4KQJHlwHS/IYaZ6sZd9tmu5HQm2xi1UaTbzxYwJk/wBF5g5EEYOBZeEfGZmNdFyFZmZIR4jikbLThlh5kUUVJGmRT7sekkziRWUIACABk3T4qCsedgO4xhgGcY7q5pHJ4klBBTQRJ0CeHcoYHHUh6wgfdn9uJdSdMiebGJ0zUPTcoS286FCkrZxnYoYYKWLkBowhQoBeaOlZAgVhLidrXqg2GiqpQpZ4apwSwRtjqrB3muoF9BboaXKmshlqWqsWiGt2wphJkQbAU5hoCACH5BAUKABsALAcABADOAAsAAAX/oGFw2WZuT5oZROsSQnGaKjRvilI893MItlNOJ5v5gDcFrHhKIWcEYu/xFEqNv6B1N62aclysF7fsZYe5aOx2yL5aAUGSaT1oTYMBwQ5VGCAJgYIJCnx1gIOBhXdwiIl7d0p2iYGQUAQBjoOFSQR/lIQHnZ+Ue6OagqYzSqSJi5eTpTxGcjcSChANEbu8DBAIEsHBChe5vL13G7fFuscRDcnKuM3H0La3EA7Oz8kKEsXazr7Cw9/Gztar5uHHvte47MjktznZ2w0G1+D3BgirAqJmJMAQgMGEgwgn5Ei0gKDBhBMALGRYEOJBb5QcWlQo4cbAihZz3GgIMqFEBSM1/4ZEOWPAgpIIJXYU+PIhRG8ja1qU6VHlzZknJNQ6UanCjQkWCIGSUGEjAwVLjc44+DTqUQtPPS5gejUrTa5TJ3g9sWCr1BNUWZI161StiQUDmLYdGfesibQ3XMq1OPYthrwuA2yU2LBs2cBHIypYQPPlYAKFD5cVvNPtW8eVGbdcQADATsiNO4cFAPkvHpedPzc8kUcPgNGgZ5RNDZG05reoE9s2vSEP79MEGiQGy1qP8LA4ZcdtsJE48ONoLTBtTV0B9LsTnPceoIDBDQvS7W7vfjVY3q3eZ4A339J4eaAmKqU/sV58HvJh2RcnIBsDUw0ABqhBA5aV5V9XUFGiHfVeAiWwoFgJJrIXRH1tEMiDFV4oHoAEGlaWhgIGSGBO2nFomYY3mKjVglidaNYJGJDkWW2xxTfbjCbVaOGNqoX2GloR8ZeTaECS9pthRGJH2g0b3Agbk6hNANtteHD2GJUucfajCQBy5OOTQ25ZgUPvaVVQmbKh9510/qQpwXx3SQdfk8tZJOd5b6JJFplT3ZnmmX3qd5l1eg5q00HrtUkUn0AKaiGjClSAgKLYZcgWXwocGRcCFGCKwSB6ceqphwmYRUFYT/1WKlOdUpipmxW0mlCqHjYkAaeoZlqrqZ4qd+upQKaapn/AmgAegZ8KUtYtFAQQAgAh+QQFCgAbACwHAAQAzgALAAAF/+C2PUcmiCiZGUTrEkKBis8jQEquKwU5HyXIbEPgyX7BYa5wTNmEMwWsSXsqFbEh8DYs9mrgGjdK6GkPY5GOeU6ryz7UFopSQEzygOGhJBjoIgMDBAcBM0V/CYqLCQqFOwobiYyKjn2TlI6GKC2YjJZknouaZAcQlJUHl6eooJwKooobqoewrJSEmyKdt59NhRKFMxLEEA4RyMkMEAjDEhfGycqAG8TQx9IRDRDE3d3R2ctD1RLg0ttKEnbY5wZD3+zJ6M7X2RHi9Oby7u/r9g38UFjTh2xZJBEBMDAboogAgwkQI07IMUORwocSJwCgWDFBAIwZOaJIsOBjRogKJP8wTODw5ESVHVtm3AhzpEeQElOuNDlTZ0ycEUWKWFASqEahGwYUPbnxoAgEdlYSqDBkgoUNClAlIHbSAoOsqCRQnQHxq1axVb06FWFxLIqyaze0Tft1JVqyE+pWXMD1pF6bYl3+HTqAWNW8cRUFzmih0ZAAB2oGKukSAAGGRHWJgLiR6AylBLpuHKKUMlMCngMpDSAa9QIUggZVVvDaJobLeC3XZpvgNgCmtPcuwP3WgmXSq4do0DC6o2/guzcseECtUoO0hmcsGKDgOt7ssBd07wqesAIGZC1YIBa7PQHvb1+SFo+++HrJSQfB33xfav3i5eX3Hnb4CTJgegEq8tH/YQEOcIJzbm2G2EoYRLgBXFpVmFYDcREV4HIcnmUhiGBRouEMJGJGzHIspqgdXxK0yCKHRNXoIX4uorCdTyjkyNtdPWrA4Up82EbAbzMRxxZRR54WXVLDIRmRcag5d2R6ugl3ZXzNhTecchpMhIGVAKAYpgJjjsSklBEd99maZoo535ZvdamjBEpusJyctg3h4X8XqodBMx0tiNeg/oGJaKGABpogS40KSqiaEgBqlQWLUtqoVQnytekEjzo0hHqhRorppOZt2p923M2AAV+oBtpAnnPNoB6HaU6mAAIU+IXmi3j2mtFXuUoHKwXpzVrsjcgGOauKEjQrwq157hitGq2NoWmjh7z6Wmxb0m5w66+2VRAuXN/yFUAIACH5BAUKABsALAcABADOAAsAAAX/4CZuRiaM45MZqBgIRbs9AqTcuFLE7VHLOh7KB5ERdjJaEaU4ClO/lgKWjKKcMiJQ8KgumcieVdQMD8cbBeuAkkC6LYLhOxoQ2PF5Ys9PKPBMen17f0CCg4VSh32JV4t8jSNqEIOEgJKPlkYBlJWRInKdiJdkmQlvKAsLBxdABA4RsbIMBggtEhcQsLKxDBC2TAS6vLENdJLDxMZAubu8vjIbzcQRtMzJz79S08oQEt/guNiyy7fcvMbh4OezdAvGrakLAQwyABsELQkY9BP+//ckyPDD4J9BfAMh1GsBoImMeQUN+lMgUJ9CiRMa5msxoB9Gh/o8GmxYMZXIgxtR/yQ46S/gQAURR0pDwYDfywoyLPip5AdnCwsMFPBU4BPFhKBDi444quCmDKZOfwZ9KEGpCKgcN1jdALSpPqIYsabS+nSqvqplvYqQYAeDPgwKwjaMtiDl0oaqUAyo+3TuWwUAMPpVCfee0cEjVBGQq2ABx7oTWmQk4FglZMGN9fGVDMCuiH2AOVOu/PmyxM630gwM0CCn6q8LjVJ8GXvpa5Uwn95OTC/nNxkda1/dLSK475IjCD6dHbK1ZOa4hXP9DXs5chJ00UpVm5xo2qRpoxptwF2E4/IbJpB/SDz9+q9b1aNfQH08+p4a8uvX8B53fLP+ycAfemjsRUBgp1H20K+BghHgVgt1GXZXZpZ5lt4ECjxYR4ScUWiShEtZqBiIInRGWnERNnjiBglw+JyGnxUmGowsyiiZg189lNtPGACjV2+S9UjbU0JWF6SPvEk3QZEqsZYTk3UAaRSUnznJI5LmESCdBVSyaOWUWLK4I5gDUYVeV1T9l+FZClCAUVA09uSmRHBCKAECFEhW51ht6rnmWBXkaR+NjuHpJ40D3DmnQXt2F+ihZxlqVKOfQRACACH5BAUKABwALAcABADOAAsAAAX/ICdyUCkUo/g8mUG8MCGkKgspeC6j6XEIEBpBUeCNfECaglBcOVfJFK7YQwZHQ6JRZBUqTrSuVEuD3nI45pYjFuWKvjjSkCoRaBUMWxkwBGgJCXspQ36Bh4EEB0oKhoiBgyNLjo8Ki4QElIiWfJqHnISNEI+Ql5J9o6SgkqKkgqYihamPkW6oNBgSfiMMDQkGCBLCwxIQDhHIyQwQCGMKxsnKVyPCF9DREQ3MxMPX0cu4wt7J2uHWx9jlKd3o39MiuefYEcvNkuLt5O8c1ePI2tyELXGQwoGDAQf+iEC2xByDCRAjTlAgIUWCBRgCPJQ4AQBFXAs0coT40WLIjRxL/47AcHLkxIomRXL0CHPERZkpa4q4iVKiyp0tR/7kwHMkTUBBJR5dOCEBAVcKKtCAyOHpowXCpk7goABqBZdcvWploACpBKkpIJI1q5OD2rIWE0R1uTZu1LFwbWL9OlKuWb4c6+o9i3dEgw0RCGDUG9KlRw56gDY2qmCByZBaASi+TACA0TucAaTteCcy0ZuOK3N2vJlx58+LRQyY3Xm0ZsgjZg+oPQLi7dUcNXi0LOJw1pgNtB7XG6CBy+U75SYfPTSQAgZTNUDnQHt67wnbZyvwLgKiMN3oCZB3C76tdewpLFgIP2C88rbi4Y+QT3+8S5USMICZXWj1pkEDeUU3lOYGB3alSoEiMIjgX4WlgNF2EibIwQIXauWXSRg2SAOHIU5IIIMoZkhhWiJaiFVbKo6AQEgQXrTAazO1JhkBrBG3Y2Y6EsUhaGn95hprSN0oWpFE7rhkeaQBchGOEWnwEmc0uKWZj0LeuNV3W4Y2lZHFlQCSRjTIl8uZ+kG5HU/3sRlnTG2ytyadytnD3HrmuRcSn+0h1dycexIK1KCjYaCnjCCVqOFFJTZ5GkUUjESWaUIKU2lgCmAKKQIUjHapXRKE+t2og1VgankNYnohqKJ2CmKplso6GKz7WYCgqxeuyoF8u9IQAgA7",
                        msg: null,
                        msgText: "<em>Loading the next set of posts...</em>",
                        selector: null,
                        speed: "fast",
                        start: n
                },
                state: {
                        isDuringAjax: false,
                        isInvalidPage: false,
                        isDestroyed: false,
                        isDone: false,
                        isPaused: false,
                        isBeyondMaxPage: false,
                        currPage: 1
                },
                debug: false,
                behavior: n,
                binder: t(e),
                nextSelector: "div.navigation a:first",
                navSelector: "div.navigation",
                contentSelector: null,
                extraScrollPx: 150,
                itemSelector: "div.post",
                animate: false,
                pathParse: n,
                dataType: "html",
                appendCallback: true,
                bufferPx: 40,
                errorCallback: function () {},
                infid: 0,
                pixelsFromNavToBottom: n,
                path: n,
                prefill: false,
                maxPage: n
        };
        t.infinitescroll.prototype = {
                _binding: function (t) {
                        var r = this,
                                i = r.options;
                        i.v = "2.0b2.120520";
                        if ( !! i.behavior && this["_binding_" + i.behavior] !== n) {
                                this["_binding_" + i.behavior].call(this);
                                return
                        }
                        if (t !== "bind" && t !== "unbind") {
                                this._debug("Binding value  " + t + " not valid");
                                return false
                        }
                        if (t === "unbind") {
                                this.options.binder.unbind("smartscroll.infscr." + r.options.infid)
                        } else {
                                this.options.binder[t]("smartscroll.infscr." + r.options.infid, function () {
                                        r.scroll()
                                })
                        }
                        this._debug("Binding", t)
                },
                _create: function (i, s) {
                        var o = t.extend(true, {}, t.infinitescroll.defaults, i);
                        this.options = o;
                        var u = t(e);
                        var a = this;
                        if (!a._validate(i)) {
                                return false
                        }
                        var f = t(o.nextSelector).attr("href");
                        if (!f) {
                                this._debug("Navigation selector not found");
                                return false
                        }
                        o.path = o.path || this._determinepath(f);
                        o.contentSelector = o.contentSelector || this.element;
                        o.loading.selector = o.loading.selector || o.contentSelector;
                        o.loading.msg = o.loading.msg || t('<div id="infscr-loading"><img alt="Loading..." src="' + o.loading.img + '" /><div>' + o.loading.msgText + "</div></div>");
                        (new Image).src = o.loading.img;
                        if (o.pixelsFromNavToBottom === n) {
                                o.pixelsFromNavToBottom = t(document).height() - t(o.navSelector).offset().top;
                                this._debug("pixelsFromNavToBottom: " + o.pixelsFromNavToBottom)
                        }
                        var l = this;
                        o.loading.start = o.loading.start ||
                        function () {
                                t(o.navSelector).hide();
                                o.loading.msg.appendTo(o.loading.selector).show(o.loading.speed, t.proxy(function () {
                                        this.beginAjax(o)
                                }, l))
                        };
                        o.loading.finished = o.loading.finished ||
                        function () {
                                if (!o.state.isBeyondMaxPage) o.loading.msg.fadeOut(o.loading.speed)
                        };
                        o.callback = function (e, r, i) {
                                if ( !! o.behavior && e["_callback_" + o.behavior] !== n) {
                                        e["_callback_" + o.behavior].call(t(o.contentSelector)[0], r, i)
                                }
                                if (s) {
                                        s.call(t(o.contentSelector)[0], r, o, i)
                                }
                                if (o.prefill) {
                                        u.bind("resize.infinite-scroll", e._prefill)
                                }
                        };
                        if (i.debug) {
                                if (Function.prototype.bind && (typeof console === "object" || typeof console === "function") && typeof console.log === "object") {
                                        ["log", "info", "warn", "error", "assert", "dir", "clear", "profile", "profileEnd"].forEach(function (e) {
                                                console[e] = this.call(console[e], console)
                                        }, Function.prototype.bind)
                                }
                        }
                        this._setup();
                        if (o.prefill) {
                                this._prefill()
                        }
                        return true
                },
                _prefill: function () {
                        function s() {
                                return r.options.contentSelector.height() <= i.height()
                        }
                        var r = this;
                        var i = t(e);
                        this._prefill = function () {
                                if (s()) {
                                        r.scroll()
                                }
                                i.bind("resize.infinite-scroll", function () {
                                        if (s()) {
                                                i.unbind("resize.infinite-scroll");
                                                r.scroll()
                                        }
                                })
                        };
                        this._prefill()
                },
                _debug: function () {
                        if (true !== this.options.debug) {
                                return
                        }
                        if (typeof console !== "undefined" && typeof console.log === "function") {
                                if (Array.prototype.slice.call(arguments).length === 1 && typeof Array.prototype.slice.call(arguments)[0] === "string") {
                                        console.log(Array.prototype.slice.call(arguments).toString())
                                } else {
                                        console.log(Array.prototype.slice.call(arguments))
                                }
                        } else if (!Function.prototype.bind && typeof console !== "undefined" && typeof console.log === "object") {
                                Function.prototype.call.call(console.log, console, Array.prototype.slice.call(arguments))
                        }
                },
                _determinepath: function (t) {
                        var r = this.options;
                        if ( !! r.behavior && this["_determinepath_" + r.behavior] !== n) {
                                return this["_determinepath_" + r.behavior].call(this, t)
                        }
                        if ( !! r.pathParse) {
                                this._debug("pathParse manual");
                                return r.pathParse(t, this.options.state.currPage + 1)
                        } else if (t.match(/^(.*?)\b2\b(.*?$)/)) {
                                t = t.match(/^(.*?)\b2\b(.*?$)/).slice(1)
                        } else if (t.match(/^(.*?)2(.*?$)/)) {
                                if (t.match(/^(.*?page=)2(\/.*|$)/)) {
                                        t = t.match(/^(.*?page=)2(\/.*|$)/).slice(1);
                                        return t
                                }
                                t = t.match(/^(.*?)2(.*?$)/).slice(1)
                        } else {
                                if (t.match(/^(.*?page=)1(\/.*|$)/)) {
                                        t = t.match(/^(.*?page=)1(\/.*|$)/).slice(1);
                                        return t
                                } else {
                                        this._debug("Sorry, we couldn't parse your Next (Previous Posts) URL. Verify your the css selector points to the correct A tag. If you still get this error: yell, scream, and kindly ask for help at infinite-scroll.com.");
                                        r.state.isInvalidPage = true
                                }
                        }
                        this._debug("determinePath", t);
                        return t
                },
                _error: function (t) {
                        var r = this.options;
                        if ( !! r.behavior && this["_error_" + r.behavior] !== n) {
                                this["_error_" + r.behavior].call(this, t);
                                return
                        }
                        if (t !== "destroy" && t !== "end") {
                                t = "unknown"
                        }
                        this._debug("Error", t);
                        if (t === "end" || r.state.isBeyondMaxPage) {
                                this._showdonemsg()
                        }
                        r.state.isDone = true;
                        r.state.currPage = 1;
                        r.state.isPaused = false;
                        r.state.isBeyondMaxPage = false;
                        this._binding("unbind")
                },
                _loadcallback: function (i, s, o) {
                        var u = this.options,
                                a = this.options.callback,
                                f = u.state.isDone ? "done" : !u.appendCallback ? "no-append" : "append",
                                l;
                        if ( !! u.behavior && this["_loadcallback_" + u.behavior] !== n) {
                                this["_loadcallback_" + u.behavior].call(this, i, s);
                                return
                        }
                        switch (f) {
                        case "done":
                                this._showdonemsg();
                                return false;
                        case "no-append":
                                if (u.dataType === "html") {
                                        s = "<div>" + s + "</div>";
                                        s = t(s).find(u.itemSelector)
                                }
                                break;
                        case "append":
                                var c = i.children();
                                if (c.length === 0) {
                                        return this._error("end")
                                }
                                l = document.createDocumentFragment();
                                while (i[0].firstChild) {
                                        l.appendChild(i[0].firstChild)
                                }
                                this._debug("contentSelector", t(u.contentSelector)[0]);
                                t(u.contentSelector)[0].appendChild(l);
                                s = c.get();
                                break
                        }
                        u.loading.finished.call(t(u.contentSelector)[0], u);
                        if (u.animate) {
                                var h = t(e).scrollTop() + t(u.loading.msg).height() + u.extraScrollPx + "px";
                                t("html,body").animate({
                                        scrollTop: h
                                }, 800, function () {
                                        u.state.isDuringAjax = false
                                })
                        }
                        if (!u.animate) {
                                u.state.isDuringAjax = false
                        }
                        a(this, s, o);
                        if (u.prefill) {
                                this._prefill()
                        }
                },
                _nearbottom: function () {
                        var i = this.options,
                                s = 0 + t(document).height() - i.binder.scrollTop() - t(e).height();
                        if ( !! i.behavior && this["_nearbottom_" + i.behavior] !== n) {
                                return this["_nearbottom_" + i.behavior].call(this)
                        }
                        this._debug("math:", s, i.pixelsFromNavToBottom);
                        return s - i.bufferPx < i.pixelsFromNavToBottom
                },
                _pausing: function (t) {
                        var r = this.options;
                        if ( !! r.behavior && this["_pausing_" + r.behavior] !== n) {
                                this["_pausing_" + r.behavior].call(this, t);
                                return
                        }
                        if (t !== "pause" && t !== "resume" && t !== null) {
                                this._debug("Invalid argument. Toggling pause value instead")
                        }
                        t = t && (t === "pause" || t === "resume") ? t : "toggle";
                        switch (t) {
                        case "pause":
                                r.state.isPaused = true;
                                break;
                        case "resume":
                                r.state.isPaused = false;
                                break;
                        case "toggle":
                                r.state.isPaused = !r.state.isPaused;
                                break
                        }
                        this._debug("Paused", r.state.isPaused);
                        return false
                },
                _setup: function () {
                        var t = this.options;
                        if ( !! t.behavior && this["_setup_" + t.behavior] !== n) {
                                this["_setup_" + t.behavior].call(this);
                                return
                        }
                        this._binding("bind");
                        return false
                },
                _showdonemsg: function () {
                        var r = this.options;
                        if ( !! r.behavior && this["_showdonemsg_" + r.behavior] !== n) {
                                this["_showdonemsg_" + r.behavior].call(this);
                                return
                        }
                        r.loading.msg.find("img").hide().parent().find("div").html(r.loading.finishedMsg).animate({
                                opacity: 1
                        }, 2e3, function () {
                                t(this).parent().fadeOut(r.loading.speed)
                        });
                        r.errorCallback.call(t(r.contentSelector)[0], "done")
                },
                _validate: function (n) {
                        for (var r in n) {
                                if (r.indexOf && r.indexOf("Selector") > -1 && t(n[r]).length === 0) {
                                        this._debug("Your " + r + " found no elements.");
                                        return false
                                }
                        }
                        return true
                },
                bind: function () {
                        this._binding("bind")
                },
                destroy: function () {
                        this.options.state.isDestroyed = true;
                        this.options.loading.finished();
                        return this._error("destroy")
                },
                pause: function () {
                        this._pausing("pause")
                },
                resume: function () {
                        this._pausing("resume")
                },
                beginAjax: function (r) {
                        var i = this,
                                s = r.path,
                                o, u, a, f;
                        r.state.currPage++;
                        if (r.maxPage != n && r.state.currPage > r.maxPage) {
                                r.state.isBeyondMaxPage = true;
                                this.destroy();
                                return
                        }
                        o = t(r.contentSelector).is("table, tbody") ? t("<tbody/>") : t("<div/>");
                        u = typeof s === "function" ? s(r.state.currPage) : s.join(r.state.currPage);
                        i._debug("heading into ajax", u);
                        a = r.dataType === "html" || r.dataType === "json" ? r.dataType : "html+callback";
                        if (r.appendCallback && r.dataType === "html") {
                                a += "+callback"
                        }
                        switch (a) {
                        case "html+callback":
                                i._debug("Using HTML via .load() method");
                                o.load(u + " " + r.itemSelector, n, function (t) {
                                        i._loadcallback(o, t, u)
                                });
                                break;
                        case "html":
                                i._debug("Using " + a.toUpperCase() + " via $.ajax() method");
                                t.ajax({
                                        url: u,
                                        dataType: r.dataType,
                                        complete: function (t, n) {
                                                f = typeof t.isResolved !== "undefined" ? t.isResolved() : n === "success" || n === "notmodified";
                                                if (f) {
                                                        i._loadcallback(o, t.responseText, u)
                                                } else {
                                                        i._error("end")
                                                }
                                        }
                                });
                                break;
                        case "json":
                                i._debug("Using " + a.toUpperCase() + " via $.ajax() method");
                                t.ajax({
                                        dataType: "json",
                                        type: "GET",
                                        url: u,
                                        success: function (e, t, s) {
                                                f = typeof s.isResolved !== "undefined" ? s.isResolved() : t === "success" || t === "notmodified";
                                                if (r.appendCallback) {
                                                        if (r.template !== n) {
                                                                var a = r.template(e);
                                                                o.append(a);
                                                                if (f) {
                                                                        i._loadcallback(o, a)
                                                                } else {
                                                                        i._error("end")
                                                                }
                                                        } else {
                                                                i._debug("template must be defined.");
                                                                i._error("end")
                                                        }
                                                } else {
                                                        if (f) {
                                                                i._loadcallback(o, e, u)
                                                        } else {
                                                                i._error("end")
                                                        }
                                                }
                                        },
                                        error: function () {
                                                i._debug("JSON ajax request failed.");
                                                i._error("end")
                                        }
                                });
                                break
                        }
                },
                retrieve: function (r) {
                        r = r || null;
                        var i = this,
                                s = i.options;
                        if ( !! s.behavior && this["retrieve_" + s.behavior] !== n) {
                                this["retrieve_" + s.behavior].call(this, r);
                                return
                        }
                        if (s.state.isDestroyed) {
                                this._debug("Instance is destroyed");
                                return false
                        }
                        s.state.isDuringAjax = true;
                        s.loading.start.call(t(s.contentSelector)[0], s)
                },
                scroll: function () {
                        var t = this.options,
                                r = t.state;
                        if ( !! t.behavior && this["scroll_" + t.behavior] !== n) {
                                this["scroll_" + t.behavior].call(this);
                                return
                        }
                        if (r.isDuringAjax || r.isInvalidPage || r.isDone || r.isDestroyed || r.isPaused) {
                                return
                        }
                        if (!this._nearbottom()) {
                                return
                        }
                        this.retrieve()
                },
                toggle: function () {
                        this._pausing()
                },
                unbind: function () {
                        this._binding("unbind")
                },
                update: function (n) {
                        if (t.isPlainObject(n)) {
                                this.options = t.extend(true, this.options, n)
                        }
                }
        };
        t.fn.infinitescroll = function (n, r) {
                var i = typeof n;
                switch (i) {
                case "string":
                        var s = Array.prototype.slice.call(arguments, 1);
                        this.each(function () {
                                var e = t.data(this, "infinitescroll");
                                if (!e) {
                                        return false
                                }
                                if (!t.isFunction(e[n]) || n.charAt(0) === "_") {
                                        return false
                                }
                                e[n].apply(e, s)
                        });
                        break;
                case "object":
                        this.each(function () {
                                var e = t.data(this, "infinitescroll");
                                if (e) {
                                        e.update(n)
                                } else {
                                        e = new t.infinitescroll(n, r, this);
                                        if (!e.failed) {
                                                t.data(this, "infinitescroll", e)
                                        }
                                }
                        });
                        break
                }
                return this
        };
        var r = t.event,
                i;
        r.special.smartscroll = {
                setup: function () {
                        t(this).bind("scroll", r.special.smartscroll.handler)
                },
                teardown: function () {
                        t(this).unbind("scroll", r.special.smartscroll.handler)
                },
                handler: function (e, n) {
                        var r = this,
                                s = arguments;
                        e.type = "smartscroll";
                        if (i) {
                                clearTimeout(i)
                        }
                        i = setTimeout(function () {
                                t(r).trigger("smartscroll", s)
                        }, n === "execAsap" ? 0 : 100)
                }
        };
        t.fn.smartscroll = function (e) {
                return e ? this.bind("smartscroll", e) : this.trigger("smartscroll", ["execAsap"])
        }
})(window, jQuery)




































/*
 * jQuery Easing v1.3 - http://gsgd.co.uk/sandbox/jquery/easing/
 *
 */
jQuery.easing["jswing"] = jQuery.easing["swing"];
jQuery.extend(jQuery.easing, {
        def: "easeOutQuad",
        swing: function (a, b, c, d, e) {
                return jQuery.easing[jQuery.easing.def](a, b, c, d, e)
        },
        easeInQuad: function (a, b, c, d, e) {
                return d * (b /= e) * b + c
        },
        easeOutQuad: function (a, b, c, d, e) {
                return -d * (b /= e) * (b - 2) + c
        },
        easeInOutQuad: function (a, b, c, d, e) {
                if ((b /= e / 2) < 1) return d / 2 * b * b + c;
                return -d / 2 * (--b * (b - 2) - 1) + c
        },
        easeInCubic: function (a, b, c, d, e) {
                return d * (b /= e) * b * b + c
        },
        easeOutCubic: function (a, b, c, d, e) {
                return d * ((b = b / e - 1) * b * b + 1) + c
        },
        easeInOutCubic: function (a, b, c, d, e) {
                if ((b /= e / 2) < 1) return d / 2 * b * b * b + c;
                return d / 2 * ((b -= 2) * b * b + 2) + c
        },
        easeInQuart: function (a, b, c, d, e) {
                return d * (b /= e) * b * b * b + c
        },
        easeOutQuart: function (a, b, c, d, e) {
                return -d * ((b = b / e - 1) * b * b * b - 1) + c
        },
        easeInOutQuart: function (a, b, c, d, e) {
                if ((b /= e / 2) < 1) return d / 2 * b * b * b * b + c;
                return -d / 2 * ((b -= 2) * b * b * b - 2) + c
        },
        easeInQuint: function (a, b, c, d, e) {
                return d * (b /= e) * b * b * b * b + c
        },
        easeOutQuint: function (a, b, c, d, e) {
                return d * ((b = b / e - 1) * b * b * b * b + 1) + c
        },
        easeInOutQuint: function (a, b, c, d, e) {
                if ((b /= e / 2) < 1) return d / 2 * b * b * b * b * b + c;
                return d / 2 * ((b -= 2) * b * b * b * b + 2) + c
        },
        easeInSine: function (a, b, c, d, e) {
                return -d * Math.cos(b / e * (Math.PI / 2)) + d + c
        },
        easeOutSine: function (a, b, c, d, e) {
                return d * Math.sin(b / e * (Math.PI / 2)) + c
        },
        easeInOutSine: function (a, b, c, d, e) {
                return -d / 2 * (Math.cos(Math.PI * b / e) - 1) + c
        },
        easeInExpo: function (a, b, c, d, e) {
                return b == 0 ? c : d * Math.pow(2, 10 * (b / e - 1)) + c
        },
        easeOutExpo: function (a, b, c, d, e) {
                return b == e ? c + d : d * (-Math.pow(2, -10 * b / e) + 1) + c
        },
        easeInOutExpo: function (a, b, c, d, e) {
                if (b == 0) return c;
                if (b == e) return c + d;
                if ((b /= e / 2) < 1) return d / 2 * Math.pow(2, 10 * (b - 1)) + c;
                return d / 2 * (-Math.pow(2, -10 * --b) + 2) + c
        },
        easeInCirc: function (a, b, c, d, e) {
                return -d * (Math.sqrt(1 - (b /= e) * b) - 1) + c
        },
        easeOutCirc: function (a, b, c, d, e) {
                return d * Math.sqrt(1 - (b = b / e - 1) * b) + c
        },
        easeInOutCirc: function (a, b, c, d, e) {
                if ((b /= e / 2) < 1) return -d / 2 * (Math.sqrt(1 - b * b) - 1) + c;
                return d / 2 * (Math.sqrt(1 - (b -= 2) * b) + 1) + c
        },
        easeInElastic: function (a, b, c, d, e) {
                var f = 1.70158;
                var g = 0;
                var h = d;
                if (b == 0) return c;
                if ((b /= e) == 1) return c + d;
                if (!g) g = e * .3;
                if (h < Math.abs(d)) {
                        h = d;
                        var f = g / 4
                } else var f = g / (2 * Math.PI) * Math.asin(d / h);
                return -(h * Math.pow(2, 10 * (b -= 1)) * Math.sin((b * e - f) * 2 * Math.PI / g)) + c
        },
        easeOutElastic: function (a, b, c, d, e) {
                var f = 1.70158;
                var g = 0;
                var h = d;
                if (b == 0) return c;
                if ((b /= e) == 1) return c + d;
                if (!g) g = e * .3;
                if (h < Math.abs(d)) {
                        h = d;
                        var f = g / 4
                } else var f = g / (2 * Math.PI) * Math.asin(d / h);
                return h * Math.pow(2, -10 * b) * Math.sin((b * e - f) * 2 * Math.PI / g) + d + c
        },
        easeInOutElastic: function (a, b, c, d, e) {
                var f = 1.70158;
                var g = 0;
                var h = d;
                if (b == 0) return c;
                if ((b /= e / 2) == 2) return c + d;
                if (!g) g = e * .3 * 1.5;
                if (h < Math.abs(d)) {
                        h = d;
                        var f = g / 4
                } else var f = g / (2 * Math.PI) * Math.asin(d / h);
                if (b < 1) return -.5 * h * Math.pow(2, 10 * (b -= 1)) * Math.sin((b * e - f) * 2 * Math.PI / g) + c;
                return h * Math.pow(2, -10 * (b -= 1)) * Math.sin((b * e - f) * 2 * Math.PI / g) * .5 + d + c
        },
        easeInBack: function (a, b, c, d, e, f) {
                if (f == undefined) f = 1.70158;
                return d * (b /= e) * b * ((f + 1) * b - f) + c
        },
        easeOutBack: function (a, b, c, d, e, f) {
                if (f == undefined) f = 1.70158;
                return d * ((b = b / e - 1) * b * ((f + 1) * b + f) + 1) + c
        },
        easeInOutBack: function (a, b, c, d, e, f) {
                if (f == undefined) f = 1.70158;
                if ((b /= e / 2) < 1) return d / 2 * b * b * (((f *= 1.525) + 1) * b - f) + c;
                return d / 2 * ((b -= 2) * b * (((f *= 1.525) + 1) * b + f) + 2) + c
        },
        easeInBounce: function (a, b, c, d, e) {
                return d - jQuery.easing.easeOutBounce(a, e - b, 0, d, e) + c
        },
        easeOutBounce: function (a, b, c, d, e) {
                if ((b /= e) < 1 / 2.75) {
                        return d * 7.5625 * b * b + c
                } else if (b < 2 / 2.75) {
                        return d * (7.5625 * (b -= 1.5 / 2.75) * b + .75) + c
                } else if (b < 2.5 / 2.75) {
                        return d * (7.5625 * (b -= 2.25 / 2.75) * b + .9375) + c
                } else {
                        return d * (7.5625 * (b -= 2.625 / 2.75) * b + .984375) + c
                }
        },
        easeInOutBounce: function (a, b, c, d, e) {
                if (b < e / 2) return jQuery.easing.easeInBounce(a, b * 2, 0, d, e) * .5 + c;
                return jQuery.easing.easeOutBounce(a, b * 2 - e, 0, d, e) * .5 + d * .5 + c
        }
})