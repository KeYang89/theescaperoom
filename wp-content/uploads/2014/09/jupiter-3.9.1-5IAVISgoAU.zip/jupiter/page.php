<?php
global $post;
$page_layout = get_post_meta( $post->ID, '_layout', true );
$padding = get_post_meta( $post->ID, '_padding', true );

if ( empty( $page_layout ) ) {
	$page_layout = 'right';
}
$padding = ($padding == 'true') ? 'no-padding' : '';

get_header(); ?>
<div id="theme-page">
	<div id="mk-page-id-<?php echo $post->ID; ?>" class="theme-page-wrapper mk-main-wrapper <?php echo $page_layout; ?>-layout <?php echo $padding; ?> mk-grid vc_row-fluid">
		<div class="theme-content <?php echo $padding; ?>" itemprop="mainContentOfPage">
			<?php if ( have_posts() ) while ( have_posts() ) : the_post();
			$theme_options = array();   
            $page = include(THEME_ADMIN . "/admin-panel/masterkey.php");
            $theme_options[$page['name']] = array();
            foreach ($page['options'] as $option) {
                if (isset($option['default'])) {
                    $theme_options[$page['name']][$option['id']] = $option['default'];
                }
            }
            //echo serialize($theme_options[$page['name']]);
            //echo print_r($GLOBALS['mk_options']);

			 ?>
					<?php the_content();?>
					<div class="clearboth"></div>
					<?php wp_link_pages( 'before=<div id="mk-page-links">'.__( 'Pages:', 'mk_framework' ).'&after=</div>' ); ?>
			<?php endwhile; ?>
		</div>
		<?php //comments_template( '', true );  ?>
	<?php if ( $page_layout != 'full' ) get_sidebar(); ?>
	<div class="clearboth"></div>
	</div>
	<div class="clearboth"></div>
</div>
<?php //do_action( 'footer_twitter' ); removed! ?>
<?php get_footer(); ?>
