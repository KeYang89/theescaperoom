== Changelog ==

= 1.1 Nov 5 2012 =
* Make sure wp-smiley images appear
* Add styling for HTML5 email inputs
* Make sure attribute escaping occurs after printing
* PNG image compression
* Remove loading of $locale.php
* Google Fonts fix to check is_ssl()
* Add Jetpack compatibility file
* Updated screenshot for HiDPI support
* Use wp_get_theme() with fallback for older WP versions