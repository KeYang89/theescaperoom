<?php
/**
 * @package ChaosTheory
 */
?>
	<div id="footer">
		<a href="http://wordpress.org/" title="<?php esc_attr_e( 'A Semantic Personal Publishing Platform', 'chaostheory' ); ?>" rel="generator"><?php printf( __( 'Proudly powered by %s', 'chaostheory' ), 'WordPress' ); ?></a> <?php printf( __( 'Theme: %1$s by %2$s.', 'theme-name' ), 'ChaosTheory', '<a href="http://theme.wordpress.com/" rel="designer">Automattic</a>' ); ?>
	</div><!-- #footer -->

</div><!-- #wrapper -->

<?php wp_footer(); ?>

</body>
</html>