
Martable WordPress Theme, Copyright 2014 niftyThemes
Martable is distributed under the terms of the GNU GPL

Third Party Images:

http://pixabay.com/en/coffee-cup-coffee-beans-coffee-cup-171653/
Copyright : Christoph
License : CC0

http://pixabay.com/en/belts-belt-skin-wood-193226/
Copyright : sardenacarlo
License : CC0

http://pixabay.com/en/boots-footwear-protection-lace-ups-210545/
Copyright : Bluesnap
License : CC0

http://pixabay.com/en/luggage-travel-spare-wheel-holiday-12/
Copyright : Hans
License : CC0

FontAwesome : 
Copyright - Dave Gandy 
License - SIL OFL 1.1 - http://scripts.sil.org/OFL 

martable is based on _s
_s copyright : Automattic
_s License : GPL - http://underscores.me/

TinyNav :
Copyright (c) 2011-2014 Viljami Salminen, http://viljamis.com/
License : MIT - https://github.com/viljamis/TinyNav.js