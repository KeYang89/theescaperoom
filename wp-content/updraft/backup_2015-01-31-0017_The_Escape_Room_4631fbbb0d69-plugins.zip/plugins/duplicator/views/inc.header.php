<?php function duplicator_header($title) { ?>
<!-- !!DO NOT CHANGE OR EDIT PRODUCT NAME!!
If your interested in Private Label Rights please contact us at the URL below to discuss
customizations to product labeling: lifeinthegrid.com	-->

<div class="dup-header" style="margin:0px 0px -4px 0px">
	<div style='float:left;'><img src="<?php echo DUPLICATOR_PLUGIN_URL  ?>assets/img/logo.png" style='text-align:top; height:32px; width:32px'  /></div> 
	<div style='float:left;text-align:center; margin:-3px 0px 0px 0px;'>
		<b style='text-align:center; width:100%; font-size:16px'>Duplicator &raquo; <?php echo $title ?> </b>
		<i style='font-size:0.8em; display:block; margin:-3px 0px 0px 0px'><?php _e("By", 'wpduplicator') ?> <a href='http://lifeinthegrid.com/duplicator' target='_blank'>lifeinthegrid.com</a></i>
	</div> 
	<br style='clear:both' />
</div>
<?php } ?>



