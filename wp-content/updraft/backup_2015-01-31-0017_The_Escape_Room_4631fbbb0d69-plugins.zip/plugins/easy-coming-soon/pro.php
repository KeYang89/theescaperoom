<style>
.span6 h3{
font: 33px/29px "Helvetica Neue","Helvetica Neue",Helvetica,Arial,sans-serif;
color: #000;
-webkit-font-smoothing: antialiased;
}
.span6 p{
font-size: 20px;
font-family: "Source Sans Pro",sans-serif;
color: #707070;
line-height:1.8;
}

/* =Tooltips style
========================================================================*/

.icon1 {
	display: inline-block;
	width: 13px;
	height: 13px;
	position: relative;
	padding: 0 0px 0 0;
	vertical-align: middle;
	
	background: url(<?php echo plugins_url('images/icons1.png',__FILE__) ?>) no-repeat;
}

.tooltip1 {
	display: none;
	width: 200px;
	position: absolute;
	padding: 10px;
	margin: 4px 0 0 4px;
	top: 0;
	left: 16px;
	border: 1px solid #76B6D7;
	border-radius: 0 8px 8px 8px;
	background: #bedffe;
	font-size: 13px;
	box-shadow: 0 1px 2px -1px #21759B;
	z-index: 999;
}

/* Icons Sprite Position */

.help {
	background-position: 0 0;
}

.warning {
	background-position: -20px 0;
}

.error {
	background-position: -40px 0;
}

/* Tooltip Colors */

.help .tooltip1 {
	border-color: #76B6D7;
	background-color: #bedffe;
	box-shadow-color: #21759B;
}

.warning .tooltip1 {
	border-color: #cca863;
	background-color: #ffff70;
	box-shadow-color: #ac8c4e;
}

.error .tooltip1 {
	border-color: #b50d0d;
	background-color: #e44d4e;
	box-shadow-color: #810606;
}

.icon1:hover .tooltip1 {
	display: block;
	box-shadow: 0 10px 20px -1px rgba(0,0,0,0.5);
	
	
}
</style>
 <div class="block ui-tabs-panel ui-widget-content ui-corner-bottom" id="coming_soon_pro" aria-labelledby="ui-id-1" style="display: none;" >
<div class="row" style="margin-left:10px;background:#fff;text-align:center">
	
	<div class="span12" style="width:90%;margin-top: auto;text-align:center">
		<h3 style="font-size: 45px;
font-style: normal;
font-weight: 900;
line-height:1.1;
color: #000;
letter-spacing: -1px;
text-align: center;
">Coming Soon Pro Features</h3>
		<p style="font-size: 22px;
font-style: normal;
font-weight: 300;
color: #707070;
text-align: center;">The premium version allows you to capture Visitor Email address, integrates with various AutoResponders , Comes with 2 different Template and provide loads of Design Customization Options. <br><br>
<a class="btn btn-danger  btn-large" href="http://webriti.com/easy-coming-soon-pro-detail-page/" target="_new">Upgrade To Pro Version</a>
<a class="btn btn-success  btn-large" href="http://webriti.com/easy-coming-soon-pro-detail-page/" target="_new">View Live demo</a>  
</p>
	</div>
			
	
			
		
 </div>
 
 <!-- Email Capture Feature Start -->
 
 
  <div class="row" style="margin-left:10px;background:#ededed;padding-top:70px;padding-bottom:70px;">
	
	
	<div class="span6" style="width:45%">
		<img src="<?php echo plugins_url('/images/img/subscriber.png',__FILE__);?>" alt="" style="width:100%"> 
	</div>
	<div class="span6" style="width:45%;margin-top: auto;margin-left:5%; font-size:15px;">
		<h3>Email Capture Field</h3>
		<p>Collect email address of your visitors with an email Capture Field. The Captured Email address are stored in your Wordpress website.</p>
	</div>
			
	
			
		
 </div>
 
 
  <!-- Email Capture Feature End -->
 
 
 
 
 
 
 
<div class="row" style="margin-left:10px;background: #f7f7f7;padding-top: 70px;padding-bottom: 70px;">
	
	<div class="span6" style="width:45%;margin-top: auto;">
		<h3>Newsletter Integration</h3>
		<p>Premium version integrates with popular newsletter services like <ul style="list-style-type: disc;margin-left:5%;font-size:15px"><li> Mailchimp</li><li>Aweber</li><li>Madmimi</li><li>Constant Contact</li><li>Campaign Monitor</li><li>FeedBurner</li></ul></p>
	</div>
			
	<div class="span6" style="width:45%">
		<img src="<?php echo plugins_url('/images/img/mailchimp snap.png',__FILE__);?>" alt="" style="width:100%">
	</div>
			
		
 </div>
 

 
 <div class="row" style="margin-left:10px;background: #ededed;padding-top: 70px;padding-bottom: 70px;">
	
	<div class="span6" style="width:45%">
		<img src="<?php echo plugins_url('/images/img/responsive.png',__FILE__);?>" alt="" style="width:100%">
	</div>
			
	<div class="span6" style="width:45%;margin-top: auto;">
		<h3>Responsive Design</h3>
	<p>Create a Responsive Landing Page Mode. Easy coming soon support Bootstrap Based landing page which display perfectly on mobile and tablet device.</p>
			</div>
	
		
 </div>
 
  

 
  <div class="row" style="margin-left:10px;background:#f7f7f7;padding-top:70px;padding-bottom:70px;">
	
	
	
	<div class="span6" style="width:45%;margin-top: auto;margin-left:5%">
		<h3>4 additional Design Templates</h3>
		<p>The premium version comes with 4 extra templates.  Both templates are completely customizable.</p>
	</div>
	<div class="span6" style="width:45%">
		<img src="<?php echo plugins_url('/images/img/laptop1.png',__FILE__);?>" alt="" style="width:100%"> 
	</div>
			
	
			
		
 </div>
 
  <div class="row" style="margin-left:10px;background:#ededed;padding-top:70px;padding-bottom:70px;">
	
	<div class="span6" style="width:45%">
		<img src="<?php echo plugins_url('/images/img/design2.png',__FILE__);?>" alt="" style="width:100%"> 
	</div>
	
	<div class="span6" style="width:45%;margin-top: auto;margin-left:5%">
		<h3>Powerful Design Settings</h3>
		<p>Make your maintenance page look Sexy!!! The premium version comes with loads of design settings like : <ul style="list-style-type: disc;margin-left:5%;font-size:15px"><li>Video Back-Grounds</li><li>Background Slideshow</li><li>Google Font integration</li><li>Text color Customization</li><li>Custom Css</li></ul></p>
	</div>
			
	
			
		
 </div>
 
  <div class="row" style="margin-left:10px;background: #f7f7f7;padding-top: 70px;padding-bottom: 70px;">
	
	<div class="span6" style="width:45%;margin-top: auto;">
		<h3>Landing Page Mode</h3>
		<p>Design and Publish a Landing Page on your Wordpress Website. The premium version enables you add a landing page to your existing wordpress website. </p>
	</div>
			
	<div class="span6" style="width:45%">
		<img src="<?php echo plugins_url('/images/img/multiple-mode.png',__FILE__);?>" alt="" style="width:100%">
	</div>
			
		
 </div>
 
 
  <div class="row" style="margin-left:10px;background:#ededed;padding-top:70px;padding-bottom:70px;">
	
	
	<div class="span6" style="width:45%">
		<img src="<?php echo plugins_url('/images/img/users_lock.png',__FILE__);?>" alt="" style="width:70%;margin-left:5%"> 
	</div>
	<div class="span6" style="width:45%;margin-top:auto;margin-left:5%">
		<h3>Access Controls</h3>
		<p>Powerful Access Control feature lets you decide which users can view the Live Website.  Whitelist IP address and User Roles. Assign Coming Soon Page to a particualr Wordpress Page.</p>
	</div>
			
	
			
		
 </div>
 
 
  

 
  <div class="row" style="margin-left:10px;background:#f7f7f7;padding-top:70px;padding-bottom:70px;">
	
	
	
	<div class="span6" style="width:45%;margin-top: auto;margin-left:5%">
		<h3>Social Media Icons Support</h3>
		<p>Quickly add links to your social profiles. The plugin supports adding links to Facebook, Twitter, Google+, Pinterest, Youtube, Tumblr, Viemo etc..</p>
	</div>
	<div class="span6" style="width:45%">
		<img src="<?php echo plugins_url('/images/img/social.jpg',__FILE__);?>" alt="" style="width:100%"> 
	</div>
	
			
	
</div>
  <div class="row" style="margin-left:10px;background:#ededed;padding-top:70px;padding-bottom:70px;">
	
	<div class="span6" style="width:45%">
		<img src="<?php echo plugins_url('/images/img/browsericons.png',__FILE__);?>" alt="" style="width:100%"> 
	</div>
	<div class="span6" style="width:45%;margin-top: auto;margin-left:5%">
		<h3>All Browser Support</h3>
		<p>Plugin Tested with all popular browsers like  <ul style="list-style-type: disc;margin-left:5%;font-size:15px"><li> IE 9 +</li><li> Google Chrome</li><li> Mozilla Firefox </li><li> Apple Safari</li></ul></p>
	</div>
	
	
			
	
</div>


 
  <div class="row" style="margin-left:10px;background: #f7f7f7;padding-top: 70px;padding-bottom: 70px;">
	
	
			
	<div class="span6" style="width:45%;margin-top: auto;">
		<h3>Translation Ready</h3>
		<p>Quickly translate the plugin in the language of your choice.</p>
	</div>
	
	<div class="span6" style="width:45%">
		<img src="<?php echo plugins_url('/images/img/language.png',__FILE__);?>" alt="" style="width:100%">
	</div>
			
	
		
 </div>
 
  <div class="row" style="margin-left:10px;background:#fff;text-align:center">
	
	<div class="span12" style="width:90%;margin-top: auto;text-align:center">
		<h3 style="font-size: 45px;
font-style: normal;
font-weight: 900;
line-height:1.1;
color: #000;
letter-spacing: -1px;
text-align: center;
">Upgarde to Coming Soon Pro Here</h3>
		<p style="font-size: 22px;
font-style: normal;
font-weight: 300;
color: #707070;
text-align: center;">
<a class="btn btn-danger  btn-large" href="http://webriti.com/easy-coming-soon-pro-detail-page/" target="_new">Upgrade To Pro Version</a>&nbsp;
<a class="btn btn-success  btn-large" href="http://webriti.com/easy-coming-soon-pro-detail-page/" target="_new">View Live demo</a> 
</p>
	</div>
			
	
			
		
	</div>
	<br>
	<h3 style="font-size: 35px;
font-style: normal;
font-weight: 400;
line-height:1.1;
color: #000;
letter-spacing: -1px;
text-align: center;
">Comparison Table of Free And Pro Version</h3>
	<br>
	 <table class="table table-hover table-bordered" style="font-size:15px;margin-bottom:0px;" >
                <thead class="alert alert-info">
                <tr>
                   <th></th>
                    <th style="text-align: center; font-size: 16px;">Features</th>
                    <th style="text-align: center; font-size: 16px;">Free</th>
                    <th style="text-align: center; font-size: 16px;">Premium</th>
                </tr>
                </thead>
                <tbody>
    
    
                <tr style="height:6px;">
                    <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Plugin is work with any wordpress theme easily.');?></span></span></td>
                    <td><p style="font-size:16px"><strong>Works With Any Wordpress Theme</strong></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
    
					<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Plugin template is compatible with all devices. It have completely resposive feature.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Responsive Design</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
                
                <tr>
                    <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Defalut template is availale in both pro and free .');?></span></span></td>
                    <td><p style="font-size:16px"><b>Free Coming Soon Page Template</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Easily customizable admin panel and very user friendly.');?></span></span></td>
                    <td><p style="font-size:16px"><b> User-friendly Setup</b> </p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
    
                <tr>
                    <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Default fonts are availabel in both.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Default fonts</b> </p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
    
    
                <tr>
					<td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Buddy Press Supportive.','sis_spa');?></span></span></td>
                    <td><p style="font-size:16px"><b>BuddyPress Support</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
    
    
                <tr>
                    <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Visible only non loggeed user, if you are not login then you are not able to view regular site.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Visible only non logged user</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
    
    
                <tr>
                    <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Easily collect user notify mail.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Easily collect visitor emails</b> </p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
    
    
                
    
    
                <tr>
                    <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Google Analytics supportive.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Google Analytics Support</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
                
                <tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Get social support.','sis_spa');?></span></span></td>
                    <td><p style="font-size:16px"><b>Social Follow Icons</b></p></td>
                    <td style="text-align: center;"><p>Facebook, Twitter, Google+</p></td>
                    <td style="text-align: center;">Twitter, Facebook, Linkedin, Google+, Youtube, Email, Pinterest, Yahoo  etc.</td>
                </tr>
				
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Google fonts api are integreted with coming soon.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Google Fonts Support</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/cross.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Get our fast and friendly support.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Multisite Support</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/cross.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				
				
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('laguage Translation is available in premium.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Language Translation Support</b></p></td>
                   <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/cross.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('limit access with clients who want to view regular sites.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Limit Access with Client View</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/cross.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Multiple page template is available for coming soon page.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Multiple Page Templates</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/cross.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Add user whitelist who access the site after login.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Add User Whitelist</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/cross.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Add ip access for user.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Access By Ip</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/cross.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('page landing mode is available that mean you will able to add coming soon template for single site page .');?></span></span></td>
                    <td><p style="font-size:16px"><b>Single Page View Access</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/cross.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Add fullscreen background slideshow.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Background Image SlideShow</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/cross.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Add youtube video background.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Youtube Video background</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/cross.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Mailchimp Integration for Email Marketing & Data Capture.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Mailchimp Support</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/cross.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Compaign Monitor for Email Marketing & Data Capture.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Compaign Monitor</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/cross.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Constant Contact for Email Marketing & Data Capture.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Constant Contact</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/cross.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Madmimi Integration for Email Marketing & Data Capture.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Madmimi Support</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/cross.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Aweber Integration for Email Marketing & Data Capture.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Aweber Support</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/cross.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('feedburner Integration for Email Marketing & Data Capture.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Feedburner Support</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/cross.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				
				
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Add countdown timer for coming soon page.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Countdown Timer</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/cross.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				
				
				
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('progress bar enable');?></span></span></td>
                    <td><p style="font-size:16px"><b>Progress Bar</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/cross.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('SEO supportive. Add meta title, description and favicon image. ');?></span></span></td>
                    <td><p style="font-size:16px"><b>Custom Faviceon, Meta Title and Description </b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/cross.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Get multiple mode of coming soon like Maintanance mode,Landing mode etc.');?></span></span></td>
                    <td><p style="font-size:16px"><b>Enable Multiple Mode of Coming Soon</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/cross.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				<tr>
                   <td><span class="icon1 help" style="float:right">
					<span class="tooltip1"><?php  _e('Company logo and credit image insertig option.','sis_spa');?></span></span></td>
                    <td><p style="font-size:16px"><b>Company Logo and Credit Links</b></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/cross.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                    <td style="text-align: center;"><p><img src="<?php echo plugins_url('/images/icon_check.png',__FILE__); ?>" style="vertical-align: middle;"/></p></td>
                </tr>
				
			
    
                </tbody>
				
            </table>
	<br>
	<div style="text-align: center;">
	<a class="btn btn-danger  btn-large" href="http://webriti.com/easy-coming-soon-pro-detail-page/" target="_new">Upgrade To Pro Version</a>&nbsp;
	<a class="btn btn-success  btn-large" href="http://webriti.com/easy-coming-soon-pro-detail-page/" target="_new">View Live demo</a>
	</div> 
	<br>
 </div>
 

 
 